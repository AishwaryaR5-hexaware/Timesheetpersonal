import axios from "axios";
import { getToken } from "./MsalConfig";
import { loginRequest } from "../authConfig";
import { serviceConfig } from "./serviceConfig";
//import log from 'loglevel';

const PROFILE_INFO =serviceConfig.profile.profileInfo;
const PROFILE_PHOTO =serviceConfig.profile.profilePhoto+`$value`;

export async function getProfileInfo() {
  const accessToken = await getToken(loginRequest.scopes);
  const config = {
    method: "get",
    url: PROFILE_INFO,
    headers: { Authorization: `Bearer ${accessToken}` },
  };
  try {
    //log.info('Sending request to retrieve profile info...');
    const data = await axios(config);
    // console.log("response.data", data.data);
    //log.info('Profile info retrieved successfully');
    return data.data;
  } catch (error) {
    //log.error('Error occurred while retrieving profile info:', error);
    // console.log(error);
  }
}

// export async function getProfilePhoto() {
//   const accessToken = await getToken(loginRequest.scopes);
//   // console.log("accesstoken",accessToken)
//   // console.log("PROFILE_PHOTO",PROFILE_PHOTO)
//   const config = {
//     method: "get",
//     url:PROFILE_PHOTO,
//     headers: { Authorization: `Bearer ${accessToken}` },
//     responseType: "blob",
//   };
//   try {
//    // log.info('Sending request to retrieve profile photo...');
//     const data = await axios(config);
//     // console.log("data", data.data);
//    // log.info('Profile info retrieved successfully');
//     const url = window.URL || window.webkitURL;
//     const blobUrl = url.createObjectURL(data.data);
//     // console.log("response.data", blobUrl);
//     return blobUrl;
//   } catch (error) {
//    // log.error('Error occurred while retrieving profile photo:', error);
//     // console.log(error);
//   }
// }
