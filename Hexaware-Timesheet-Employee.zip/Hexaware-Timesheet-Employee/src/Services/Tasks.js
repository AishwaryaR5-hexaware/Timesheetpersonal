import axios from "axios";
import { getProfileInfo } from "./Profile";
import { getAuthToken } from "./AuthToken";
import { serviceConfig } from "./serviceConfig";
import { useContext } from "react";
//import { UserContext } from "../App";
import log from "loglevel";
import appInsights from "../mobile/HandlerFunctions/appInsights";
const GET_WEEKLY_TASKS_URL = serviceConfig.routes.weeklyTasksUrl;
const GET_TASK_NAMES_URL = serviceConfig.routes.taskNamesUrl;
const GET_SUMMARY_TASKS_URL = serviceConfig.routes.summaryTasksUrl;
const COMMENT_URL = serviceConfig.routes.commentUrl;
const UPDATE_TASK_URL = serviceConfig.routes.updateTaskUrl;
const GET_TIMEZONE_URL = serviceConfig.routes.timezoneUrl;

export const getEmployeeId = async () => {
  const environment = process.env.REACT_APP_ENVIRONMENT;
  if (environment === "dev") {
    const storedEmpId = localStorage.getItem("empId");
    return storedEmpId;
  } else {
    const profileData = await getProfileInfo();
    return profileData.userPrincipalName.split("@")[0];
  }
  // const profileData = await getProfileInfo();
  // const empId = process.env.REACT_APP_EMPLOYEE_ID;
  // const storedEmpId = localStorage.getItem('empId');
  // return storedEmpId;
  //  return profileData.userPrincipalName.split("@")[0]
  // const profileData = await getProfileInfo();
  // const empId = process.env.REACT_APP_EMPLOYEE_ID;

  //  return profileData.userPrincipalName.split("@")[0]
};
// export function formatDate(date) {

//   const year = date.getFullYear();
//   const month = ("0" + (date.getMonth() + 1)).slice(-2);
//   const day = date.getDate();
//   return `${year}-${month}-${day}`;
// }
//This function will generate access token
export const getAccessToken = async () => {

  const token = await getAuthToken();
  return token.access_token;
};

export async function getWeeklyTasks(weekStartDate, weekEndDate) {

  const accessToken = await getAccessToken();
  const config = {
    method: "get",
    url: GET_WEEKLY_TASKS_URL,
    headers: { Authorization: `Bearer ${accessToken}` },
    params: {
      emp_id: await getEmployeeId(),
      week_start_date: weekStartDate,
      week_end_date: weekEndDate,
    },
  };
  try {
    //log.info('Sending request to retrieve weekly tasks...');
    const data = await axios(config);
    //log.info('Weekly tasks retrieved successfully');
    return data.data;
  } catch (error) {
    log.error("Error occurred while retrieving weekly tasks:", error);
    return error.response;
  }
}

export async function getTaskNames(month, year) {

  const accessToken = await getAccessToken();
  const config = {
    method: "get",
    url: GET_TASK_NAMES_URL,
    headers: { Authorization: `Bearer ${accessToken}` },
    params: {
      emp_id: await getEmployeeId(),
      ts_month: month,
      ts_year: year,
    },
  };
  try {
    //log.info('Sending request to retrieve task names...');
    const data = await axios(config);
    //log.info('Task names retrieved successfully');
    return data.data;
  } catch (error) {
    log.error("Error occurred while retrieving task names:", error);
    return error.response;
  }
}
export async function addComment(jsonData) {

  const accessToken = await getAccessToken();
  const config = {
    method: "post",
    url: COMMENT_URL,
    headers: { Authorization: `Bearer ${accessToken}` },
    data: jsonData,
  };
  try {
    //log.info('Sending request to add comment...');
    const data = await axios(config);
    //log.info('Comment added successfully');
    return data.data;
  } catch (error) {
    log.error("Error occurred while adding comment:", error);
    return error.response;
  }
}

//test
export async function getSummaryDayWise(weeks, projectId) {
//console.log("weeks",weeks)
  const accessToken = await getAccessToken();
  const employeeId = await getEmployeeId();
  const requests = Object.keys(weeks).map((week) => {
    // const formatedStartDate = formatDate(weeks[week].startDate);
    // const formatedEndDate = formatDate(weeks[week].endDate);
    const formatedStartDate = weeks[week].startDate;
    const formatedEndDate = weeks[week].endDate;
    const config = {
      method: "get",
      url: GET_SUMMARY_TASKS_URL,
      headers: { Authorization: `Bearer ${accessToken}` },
      params: {
        employee_id: employeeId,
        start_date: formatedStartDate,
        end_date: formatedEndDate,
        proj_id: projectId,
      },
    };
    return axios(config);
  });

  try {
    // log.info('Sending requests to retrieve summary tasks...');
    const responses = await Promise.all(requests);
    const data = responses.map((response) => response.data);
    // log.info('Summary tasks retrieved successfully');
    return data;
  } catch (error) {
    log.error("Error occurred while retrieving summary tasks:", error);
    return error.response;
  }
}

export async function updateTask(jsonData) {
  const accessToken = await getAccessToken();
  const config = {
    method: "put",
    url: UPDATE_TASK_URL,
    headers: { Authorization: `Bearer ${accessToken}` },
    data: jsonData,
  };
  try {
    //log.info('Sending request to update task...');
    const data = await axios(config);
    //log.info('Task updated successfully');
    return data;
  } catch (error) {
    log.error("Error occurred while updating task:", error);
    return error.response;
  }
}

export async function getTimeZone() {
  const accessToken = await getAccessToken();
  const config = {
    method: "get",
    url: GET_TIMEZONE_URL,
    headers: { Authorization: `Bearer ${accessToken}` },
    params: {
      emp_id: await getEmployeeId(),
    },
  };
  try {
    //log.info('Sending request to retrieve weekly tasks...');
    const data = await axios(config);
    //log.info('Weekly tasks retrieved successfully');
    return data.data;
  } catch (error) {
    // log.error("Error occurred while retrieving weekly timezone:", error);
    // return error.response;
    return "Asia/Calcutta"
  }
}
//log.setLevel('debug');
