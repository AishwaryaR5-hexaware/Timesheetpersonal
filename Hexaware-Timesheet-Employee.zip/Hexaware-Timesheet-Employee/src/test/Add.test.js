import React from 'react';
import Add from '../mobile/Screens/Add'
import { render, screen, fireEvent } from '@testing-library/react';
import { MemoryRouter } from "react-router-dom"
import { CssBaseline, ThemeProvider } from "@mui/material";
import theme from "../theme";
import '@testing-library/jest-dom';
import userEvent from '@testing-library/user-event';

jest.mock('crypto');
jest.mock('../Services/MsalConfig', () => ({
    msalInstance: {
        getActiveAccount: jest.fn(),
        acquireTokenSilent: jest.fn().mockResolvedValue({ accessToken: '' }),
    },
}));

jest.mock('../index.js', () => ({
    getActiveAccount: jest.fn(),
    getAllAccounts: jest.fn(),
    setActiveAccount: jest.fn(),
    enableAccountStorageEvents: jest.fn(),
    addEventCallback: jest.fn(),
    acquireTokenSilent: jest.fn().mockResolvedValue({ accessToken: '' }),
}));

const getAPI = {



    "2023-05-21": [

        {

            "employee_id": "2000077250",

            "timesheet_tasks_id": 551337,

            "timesheet_date": "2023-05-21",

            "project_name": "InnovationLab - Research & Development.",

            "project_id": "PRJ-8370",

            "timesheet_task_type": "BILLING",

            "timesheet_task_hours": 0,

            "timesheet_task_minutes": 0,

            "standard_hours": 0,

            "standard_minutes": 0,

            "is_wfh": 0,

            "is_holiday": 0,

            "hex_status": "",

            "submitted_by": "",

            "submitted_by_name": "",

            "approved_by": "",

            "approved_by_name": "",

            "source": "WEB",

            "primary_project": "Y"

        }

    ],

    "2023-05-22": [

        {

            "employee_id": "2000077250",

            "timesheet_tasks_id": 551338,

            "timesheet_date": "2023-05-22",

            "project_name": "InnovationLab - Research & Development.",

            "project_id": "PRJ-8370",

            "timesheet_task_type": "BILLING",

            "timesheet_task_hours": 8,

            "timesheet_task_minutes": 45,

            "standard_hours": 8,

            "standard_minutes": 45,

            "is_wfh": 0,

            "is_holiday": 0,

            "hex_status": "",

            "submitted_by": "",

            "submitted_by_name": "",

            "approved_by": "",

            "approved_by_name": "",

            "source": "WEB",

            "primary_project": "Y"

        }

    ],

    "2023-05-23": [

        {

            "employee_id": "2000077250",

            "timesheet_tasks_id": 551339,

            "timesheet_date": "2023-05-23",

            "project_name": "InnovationLab - Research & Development.",

            "project_id": "PRJ-8370",

            "timesheet_task_type": "BILLING",

            "timesheet_task_hours": 8,

            "timesheet_task_minutes": 45,

            "standard_hours": 8,

            "standard_minutes": 45,

            "is_wfh": 0,

            "is_holiday": 0,

            "hex_status": "",

            "submitted_by": "",

            "submitted_by_name": "",

            "approved_by": "",

            "approved_by_name": "",

            "source": "WEB",

            "primary_project": "Y"

        }

    ],

    "2023-05-24": [

        {

            "employee_id": "2000077250",

            "timesheet_tasks_id": 551340,

            "timesheet_date": "2023-05-24",

            "project_name": "InnovationLab - Research & Development.",

            "project_id": "PRJ-8370",

            "timesheet_task_type": "BILLING",

            "timesheet_task_hours": 8,

            "timesheet_task_minutes": 45,

            "standard_hours": 8,

            "standard_minutes": 45,

            "is_wfh": 0,

            "is_holiday": 0,

            "hex_status": "",

            "submitted_by": "",

            "submitted_by_name": "",

            "approved_by": "",

            "approved_by_name": "",

            "source": "WEB",

            "primary_project": "Y"

        }

    ],

    "2023-05-25": [

        {

            "employee_id": "2000077250",

            "timesheet_tasks_id": 551341,

            "timesheet_date": "2023-05-25",

            "project_name": "InnovationLab - Research & Development.",

            "project_id": "PRJ-8370",

            "timesheet_task_type": "BILLING",

            "timesheet_task_hours": 8,

            "timesheet_task_minutes": 45,

            "standard_hours": 8,

            "standard_minutes": 45,

            "is_wfh": 0,

            "is_holiday": 0,

            "hex_status": "",

            "submitted_by": "",

            "submitted_by_name": "",

            "approved_by": "",

            "approved_by_name": "",

            "source": "WEB",

            "primary_project": "Y"

        }

    ],

    "2023-05-26": [

        {

            "employee_id": "2000077250",

            "timesheet_tasks_id": 551342,

            "timesheet_date": "2023-05-26",

            "project_name": "InnovationLab - Research & Development.",

            "project_id": "PRJ-8370",

            "timesheet_task_type": "BILLING",

            "timesheet_task_hours": 8,

            "timesheet_task_minutes": 45,

            "standard_hours": 8,

            "standard_minutes": 45,

            "is_wfh": 0,

            "is_holiday": 0,

            "hex_status": "",

            "submitted_by": "",

            "submitted_by_name": "",

            "approved_by": "",

            "approved_by_name": "",

            "source": "WEB",

            "primary_project": "Y"

        }

    ],

    "2023-05-27": [

        {

            "employee_id": "2000077250",

            "timesheet_tasks_id": 551343,

            "timesheet_date": "2023-05-27",

            "project_name": "InnovationLab - Research & Development.",

            "project_id": "PRJ-8370",

            "timesheet_task_type": "BILLING",

            "timesheet_task_hours": 0,

            "timesheet_task_minutes": 0,

            "standard_hours": 0,

            "standard_minutes": 0,

            "is_wfh": 0,

            "is_holiday": 0,

            "hex_status": "",

            "submitted_by": "",

            "submitted_by_name": "",

            "approved_by": "",

            "approved_by_name": "",

            "source": "WEB",

            "primary_project": "Y"

        }

    ]




};

const primaryProject = {



    "project_name": "InnovationLab - Research & Development.",

    "project_id": "PRJ-8370",

    "employee_id": "2000077250",

    "is_wfh": 0,

    "standard_hours": 8,

    "standard_minutes": 45




};

const state = {

    totalHours: 8,

    totalMinutes: 45,

    flag: 0,

    projectDetails: {},

    projectDate: "2023-05-22",

    primaryProject: primaryProject,

    getAPI: getAPI,

    projectIndex: 0,

};


it("should render Add", () => {


    const { getByText } = render(
        <ThemeProvider theme={theme}>
            <CssBaseline />
            <MemoryRouter initialEntries={[{ path: "/add", state: state }]} initialIndex={0}>
                <Add />
            </MemoryRouter>
        </ThemeProvider>

    );
});

// test('selects a project from the dropdown', () => {
//     render(
//         <ThemeProvider theme={theme}>
//             <CssBaseline />
//             <MemoryRouter initialEntries={[{ path: "/add", state: state }]} initialIndex={0}>
//                 <Add />
//             </MemoryRouter>
//         </ThemeProvider>

//     );

//     // Find the dropdown element
//     const dropdown = screen.getByRole('button', { name: /choose a task type\/project/i });

//     // Open the dropdown
//     fireEvent.mouseDown(dropdown);

//     // Select a project
//     const projectOption = screen.getByRole('option', { name: /choose a task type\/project/i });
//     fireEvent.click(projectOption);

//     // Assert that the selected project is displayed in the dropdown
//     expect(dropdown).toHaveTextContent(/project name/i);
//   });


it('adds hours to the slider', async () => {
    render(<ThemeProvider theme={theme}>
        <CssBaseline />
        <MemoryRouter initialEntries={[{ path: "/add", state: state }]} initialIndex={0}>
            <Add />
        </MemoryRouter>
    </ThemeProvider>
    );

    // Find the slider element
    const sliders = screen.getAllByRole("slider");

    const slider = sliders[0];

    // Increase the slider value by 1
    fireEvent.change(slider, { target: { value: '1' } });

    // Assert that the slider value has been updated
    expect(slider).toHaveValue('1');
});

it('adds minutes to the slider', async () => {
    render(<ThemeProvider theme={theme}>
        <CssBaseline />
        <MemoryRouter initialEntries={[{ path: "/add", state: state }]} initialIndex={0}>
            <Add />
        </MemoryRouter>
    </ThemeProvider>
    );

    // Find the slider element
    const sliders = screen.getAllByRole("slider");

    const slider = sliders[1];

    // Increase the slider value by 1
    fireEvent.change(slider, { target: { value: '1' } });

    // Assert that the slider value has been updated
    expect(slider).toHaveValue('1');
});

test('adds a comment', () => {
    render(<ThemeProvider theme={theme}>
        <CssBaseline />
        <MemoryRouter initialEntries={[{ path: "/add", state: state }]} initialIndex={0}>
            <Add />
        </MemoryRouter>
    </ThemeProvider>
    );

    // Find the comment text field
    const commentField = screen.getByRole('textbox');

    // Type a comment
    fireEvent.change(commentField, { target: { value: 'This is a comment.' } });

    // Assert that the comment field value has been updated
    expect(commentField).toHaveValue('This is a comment.');
});


// test("Clicking Add button with a selected project should call handleComment and addNewTask functions", () => {
//     const handleComment = jest.fn();
//     const addNewTask = jest.fn();

//     render(<ThemeProvider theme={theme}>
//         <CssBaseline />
//         <MemoryRouter initialEntries={[{ path: "/add", state: state }]} initialIndex={0}>
//             <Add handleComment={handleComment} addNewTask={addNewTask} />
//         </MemoryRouter>
//     </ThemeProvider>
//     );
//     const buttons = screen.getAllByRole("button");
//     const addButton = buttons[1];
//     fireEvent.click(addButton);

//     expect(handleComment).toHaveBeenCalledTimes(1);
//     expect(addNewTask).toHaveBeenCalledTimes(1);
// });


test("Clicking Add button without selecting a project should show an error message", () => {
    const handleComment = jest.fn();
    const addNewTask = jest.fn();

    render(<ThemeProvider theme={theme}>
        <CssBaseline />
        <MemoryRouter initialEntries={[{ path: "/add", state: state }]} initialIndex={0}>
            <Add handleComment={handleComment} addNewTask={addNewTask} />
        </MemoryRouter>
    </ThemeProvider>
    );

    const addButton = screen.getByRole("button", { name: /Add/i });
    userEvent.click(addButton);

    const { getByText } = render(<ThemeProvider theme={theme}>
        <CssBaseline />
        <MemoryRouter initialEntries={[{ path: "/add", state: state }]} initialIndex={0}>
            <Add handleComment={handleComment} addNewTask={addNewTask} />
        </MemoryRouter>
    </ThemeProvider>
    );

    expect(handleComment).not.toHaveBeenCalled();
    expect(addNewTask).not.toHaveBeenCalled();
    //const text= getByText(/Field is required./i)
    //expect(text).toBeInTheDocument();
    //expect(screen.getByText(/Field is required./i)).toBeInTheDocument();
});

// test("Clicking Cancel button should navigate to the home page", () => {
//     const navigate = jest.fn();
    
//     render(<ThemeProvider theme={theme}>
//         <CssBaseline />
//         <MemoryRouter initialEntries={[{ path: "/add", state: state }]} initialIndex={0}>
//             <Add navigate={navigate}/>
//         </MemoryRouter>
//     </ThemeProvider>
//     );
//     //render(<Add navigate={navigate} />);
    
//     const cancelButton = screen.getByRole("button", { name: /Cancel/i });
//     userEvent.click(cancelButton);
    
//     expect(navigate).toHaveBeenCalledTimes(1);
//     expect(navigate).toHaveBeenCalledWith("/home");
//   });
  