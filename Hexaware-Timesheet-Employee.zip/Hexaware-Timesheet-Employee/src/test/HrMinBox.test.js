import React from "react";
import HrMinBox from "../mobile/DrawerComponent/HrMinBox";
import { CssBaseline, ThemeProvider } from "@mui/material";
import theme from "../theme";
import "@testing-library/jest-dom";
import { screen, render, fireEvent } from "@testing-library/react";

describe("HrMinBox Component", () => {
  test("renders the component without errors", () => {
    render(
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <HrMinBox />
      </ThemeProvider>
    );
    // No errors thrown means the component rendered successfully
  });
  it("displays the value with a leading zero when it is less than 10", () => {
    const value = 5;
    const width = 200;
    const { getByText } = render(
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <HrMinBox value={value} width={width} />
      </ThemeProvider>
    );

    // Check if the value is correctly formatted with a leading zero
    expect(getByText("05")).toBeInTheDocument();
  });

  it("displays the value as is when it is greater than or equal to 10", () => {
    const value = 15;
    const width = 200;
    const { getByText } = render(
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <HrMinBox value={value} width={width} />
      </ThemeProvider>
    );

    // Check if the value is displayed as is without a leading zero
    expect(getByText("15")).toBeInTheDocument();
  });
});
