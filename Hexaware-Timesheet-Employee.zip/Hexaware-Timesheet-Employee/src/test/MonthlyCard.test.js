import React from "react";
import MonthlyCard, {
  getNumberSuffix,
  formatDate,
  statusChange,
} from "../mobile/MonthlyScreenComponent/MonthlyCard";
import { CssBaseline, ThemeProvider } from "@mui/material";
import theme from "../theme";
import "@testing-library/jest-dom";
import { screen, render, fireEvent } from "@testing-library/react";

// describe("getNumberSuffix", () => {
//   it("returns the correct suffix for numbers ending in 1", () => {
//     expect(getNumberSuffix(1)).toBe("st");
//     expect(getNumberSuffix(21)).toBe("st");
//     expect(getNumberSuffix(101)).toBe("st");
//   });

//   it("returns the correct suffix for numbers ending in 2", () => {
//     expect(getNumberSuffix(2)).toBe("nd");
//     expect(getNumberSuffix(22)).toBe("nd");
//     expect(getNumberSuffix(102)).toBe("nd");
//   });

//   it("returns the correct suffix for numbers ending in 3", () => {
//     expect(getNumberSuffix(3)).toBe("rd");
//     expect(getNumberSuffix(23)).toBe("rd");
//     expect(getNumberSuffix(103)).toBe("rd");
//   });

//   it("returns the correct suffix for numbers ending in 4-9, 0, or multiples of 10", () => {
//     expect(getNumberSuffix(4)).toBe("th");
//     expect(getNumberSuffix(9)).toBe("th");
//     expect(getNumberSuffix(10)).toBe("th");
//     expect(getNumberSuffix(20)).toBe("th");
//     expect(getNumberSuffix(100)).toBe("th");
//   });
// });
describe("formatDate", () => {
  it("formats the date correctly", () => {
    const inputDate = "2023-05-01";
    const expectedOutput = "01 May";

    expect(formatDate(inputDate)).toBe(expectedOutput);
  });

  it("formats dates with different days and months", () => {
    const testCases = [
      { inputDate: "2023-06-02", expectedOutput: "02 Jun" },
      { inputDate: "2023-07-03", expectedOutput: "03 Jul" },
      { inputDate: "2023-08-04", expectedOutput: "04 Aug" },
      { inputDate: "2023-09-21", expectedOutput: "21 Sep" },
      { inputDate: "2023-10-22", expectedOutput: "22 Oct" },
    ];

    testCases.forEach(({ inputDate, expectedOutput }) => {
      expect(formatDate(inputDate)).toBe(expectedOutput);
    });
  });
});

describe("statusChange", () => {
  it("returns correct object properties for 'due for submission' status", () => {
    const weekStatus = "due for submission";
    const expectedOutput = {
      backgroundColor: "#797EF6",
      png: "./Missed.png",
      text: "Due For Submission",
      dividerColor: "#00DE66",
    };

    expect(statusChange(weekStatus)).toEqual(expectedOutput);
  });

  it("returns correct object properties for 'submitted' status", () => {
    const weekStatus = "submitted";
    const expectedOutput = {
      backgroundColor: "#1B7BEC",
      png: "./Approve.png",
      text: "Submitted",
      dividerColor: "#00DE66",
    };

    expect(statusChange(weekStatus)).toEqual(expectedOutput);
  });
  it("returns correct object properties for 'defaulted' status", () => {
    const weekStatus = "defaulted";
    const expectedOutput = {
      backgroundColor: "#797EF6",
      png: "./Missed.png",
      text: "Defaulted",
      dividerColor: "#00DE66",
    };

    expect(statusChange(weekStatus)).toEqual(expectedOutput);
  });
  it("returns correct object properties for 'rejected' status", () => {
    const weekStatus = "rejected";
    const expectedOutput = {
      backgroundColor: "#1E2F98",
      png: "./Reject.png",
      text: "Rejected",
      dividerColor: "#F48116",
    };

    expect(statusChange(weekStatus)).toEqual(expectedOutput);
  });

  it("returns correct object properties for 'approved' status", () => {
    const weekStatus = "approved";
    const expectedOutput = {
      backgroundColor: "#1B7BEC",
      png: "./Approve.png",
      text: "Approved",
      dividerColor: "#00DE66",
    };

    expect(statusChange(weekStatus)).toEqual(expectedOutput);
  });

  // it("returns correct object properties for other status values", () => {
  //   const weekStatus = "some other status";
  //   const expectedOutput = {
  //     backgroundColor: "#797EF6",
  //     png: "./Missed.png",
  //     text: "Due For Submission",
  //     dividerColor: "#00DE66",
  //   };

  //   expect(statusChange(weekStatus)).toEqual(expectedOutput);
  // });
});

describe("MonthlyCard", () => {
  const week = 1;
  const cardDetails = {
    status: "submitted",
    start_date: "2023-05-01",
    end_date: "2023-05-07",
    total_filled_hours: "40",
    total_filled_minutes: "30",
    total_billable_hours: "45",
    total_billable_minutes: "15",
  };

  it("renders the week number correctly", () => {
    render(<MonthlyCard week={week} cardDetails={cardDetails} />);
    const weekNumber = screen.getByText(/Week 1/i);
    expect(weekNumber).toBeInTheDocument();
  });

  it("renders the formatted date correctly", () => {
    render(<MonthlyCard week={week} cardDetails={cardDetails} />);
    const startDate = screen.getByText(/01 May/i);
    const endDate = screen.getByText(/07 May/i);
    expect(startDate).toBeInTheDocument();
    expect(endDate).toBeInTheDocument();
  });

  it("renders the total filled hours correctly", () => {
    render(<MonthlyCard week={week} cardDetails={cardDetails} />);
    const totalFilledHours = screen.getByText(/40:30/i);
    expect(totalFilledHours).toBeInTheDocument();
  });

  it("renders the total billable hours correctly", () => {
    render(<MonthlyCard week={week} cardDetails={cardDetails} />);
    const totalBillableHours = screen.getByText(/45:15/i);
    expect(totalBillableHours).toBeInTheDocument();
  });

  it("renders the status text correctly", () => {
    render(<MonthlyCard week={week} cardDetails={cardDetails} />);
    const statusText = screen.getByText(/Submitted/i);
    expect(statusText).toBeInTheDocument();
  });
  it("displays the formatted total_filled_hours in the card", () => {
    const cardDetails = {
      status: "submitted",
      start_date: "2023-05-01",
      end_date: "2023-05-07",
      total_filled_hours: 9,
      total_filled_minutes: 30,
      total_billable_hours: 40,
      total_billable_minutes: 15,
    };

    render(<MonthlyCard week={1} cardDetails={cardDetails} />);

    const formattedHours = screen.getByText(/09:/);
    expect(formattedHours).toBeInTheDocument();

    //     const formattedMinutes = screen.getByText(/30:/);
    //   expect(formattedMinutes).toBeInTheDocument();

    const formattedBillableHours = screen.getByText(/40:/);
    expect(formattedBillableHours).toBeInTheDocument();

    // const formattedBillableMinutes = screen.getByText('15:', { exact: false });
    // expect(formattedBillableMinutes).toBeInTheDocument();
  });
});
