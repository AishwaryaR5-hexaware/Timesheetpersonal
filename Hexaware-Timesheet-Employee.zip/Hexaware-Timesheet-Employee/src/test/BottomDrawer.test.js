import React from 'react';
import BottomDrawer from '../mobile/HomeScreenComponent/BottomDrawer'
import { render, screen, fireEvent } from '@testing-library/react';
import { MemoryRouter } from "react-router-dom"
import { CssBaseline, ThemeProvider } from "@mui/material";
import theme from "../theme";
import '@testing-library/jest-dom';

jest.mock('../Services/MsalConfig', () => ({
    msalInstance: {
        getActiveAccount: jest.fn(),
        acquireTokenSilent: jest.fn().mockResolvedValue({ accessToken: '' }),
    },
}));

jest.mock('../index.js', () => ({
    getActiveAccount: jest.fn(),
    getAllAccounts: jest.fn(),
    setActiveAccount: jest.fn(),
    enableAccountStorageEvents: jest.fn(),
    addEventCallback: jest.fn(),
    acquireTokenSilent: jest.fn().mockResolvedValue({ accessToken: '' }),
}));

const getAPI = {



    "2023-05-21": [

        {

            "employee_id": "2000077250",

            "timesheet_tasks_id": 551337,

            "timesheet_date": "2023-05-21",

            "project_name": "InnovationLab - Research & Development.",

            "project_id": "PRJ-8370",

            "timesheet_task_type": "BILLING",

            "timesheet_task_hours": 0,

            "timesheet_task_minutes": 0,

            "standard_hours": 0,

            "standard_minutes": 0,

            "is_wfh": 0,

            "is_holiday": 0,

            "hex_status": "",

            "submitted_by": "",

            "submitted_by_name": "",

            "approved_by": "",

            "approved_by_name": "",

            "source": "WEB",

            "primary_project": "Y"

        }

    ],

    "2023-05-22": [

        {

            "employee_id": "2000077250",

            "timesheet_tasks_id": 551338,

            "timesheet_date": "2023-05-22",

            "project_name": "InnovationLab - Research & Development.",

            "project_id": "PRJ-8370",

            "timesheet_task_type": "BILLING",

            "timesheet_task_hours": 8,

            "timesheet_task_minutes": 45,

            "standard_hours": 8,

            "standard_minutes": 45,

            "is_wfh": 0,

            "is_holiday": 0,

            "hex_status": "",

            "submitted_by": "",

            "submitted_by_name": "",

            "approved_by": "",

            "approved_by_name": "",

            "source": "WEB",

            "primary_project": "Y"

        }

    ],

    "2023-05-23": [

        {

            "employee_id": "2000077250",

            "timesheet_tasks_id": 551339,

            "timesheet_date": "2023-05-23",

            "project_name": "InnovationLab - Research & Development.",

            "project_id": "PRJ-8370",

            "timesheet_task_type": "BILLING",

            "timesheet_task_hours": 8,

            "timesheet_task_minutes": 45,

            "standard_hours": 8,

            "standard_minutes": 45,

            "is_wfh": 0,

            "is_holiday": 0,

            "hex_status": "",

            "submitted_by": "",

            "submitted_by_name": "",

            "approved_by": "",

            "approved_by_name": "",

            "source": "WEB",

            "primary_project": "Y"

        }

    ],

    "2023-05-24": [

        {

            "employee_id": "2000077250",

            "timesheet_tasks_id": 551340,

            "timesheet_date": "2023-05-24",

            "project_name": "InnovationLab - Research & Development.",

            "project_id": "PRJ-8370",

            "timesheet_task_type": "BILLING",

            "timesheet_task_hours": 8,

            "timesheet_task_minutes": 45,

            "standard_hours": 8,

            "standard_minutes": 45,

            "is_wfh": 0,

            "is_holiday": 0,

            "hex_status": "",

            "submitted_by": "",

            "submitted_by_name": "",

            "approved_by": "",

            "approved_by_name": "",

            "source": "WEB",

            "primary_project": "Y"

        }

    ],

    "2023-05-25": [

        {

            "employee_id": "2000077250",

            "timesheet_tasks_id": 551341,

            "timesheet_date": "2023-05-25",

            "project_name": "InnovationLab - Research & Development.",

            "project_id": "PRJ-8370",

            "timesheet_task_type": "BILLING",

            "timesheet_task_hours": 8,

            "timesheet_task_minutes": 45,

            "standard_hours": 8,

            "standard_minutes": 45,

            "is_wfh": 0,

            "is_holiday": 0,

            "hex_status": "",

            "submitted_by": "",

            "submitted_by_name": "",

            "approved_by": "",

            "approved_by_name": "",

            "source": "WEB",

            "primary_project": "Y"

        }

    ],

    "2023-05-26": [

        {

            "employee_id": "2000077250",

            "timesheet_tasks_id": 551342,

            "timesheet_date": "2023-05-26",

            "project_name": "InnovationLab - Research & Development.",

            "project_id": "PRJ-8370",

            "timesheet_task_type": "BILLING",

            "timesheet_task_hours": 8,

            "timesheet_task_minutes": 45,

            "standard_hours": 8,

            "standard_minutes": 45,

            "is_wfh": 0,

            "is_holiday": 0,

            "hex_status": "",

            "submitted_by": "",

            "submitted_by_name": "",

            "approved_by": "",

            "approved_by_name": "",

            "source": "WEB",

            "primary_project": "Y"

        }

    ],

    "2023-05-27": [

        {

            "employee_id": "2000077250",

            "timesheet_tasks_id": 551343,

            "timesheet_date": "2023-05-27",

            "project_name": "InnovationLab - Research & Development.",

            "project_id": "PRJ-8370",

            "timesheet_task_type": "BILLING",

            "timesheet_task_hours": 0,

            "timesheet_task_minutes": 0,

            "standard_hours": 0,

            "standard_minutes": 0,

            "is_wfh": 0,

            "is_holiday": 0,

            "hex_status": "",

            "submitted_by": "",

            "submitted_by_name": "",

            "approved_by": "",

            "approved_by_name": "",

            "source": "WEB",

            "primary_project": "Y"

        }

    ]




};

test('renders without crashing', () => {
    render(
        <ThemeProvider theme={theme}>
            <CssBaseline />
            <BottomDrawer
                getAPI={getAPI}
                loading={false}
                isSubmitted={jest.fn()}
                handleNextWeekDisable={jest.fn()} />
        </ThemeProvider>
    );
});

test('updates status when rejected item is found', () => {
    const getAPI1 = {
        project1: [
            { hex_status: 'accepted' },
            { hex_status: 'rejected' },
            { hex_status: 'pending' },
        ],
        project2: [
            { hex_status: 'pending' },
            { hex_status: 'accepted' },
        ],
    };

    const { getByText } = render(
        <ThemeProvider theme={theme}>
            <CssBaseline />
            <BottomDrawer
                getAPI={getAPI1}
                loading={false}
                isSubmitted={jest.fn()}
                handleNextWeekDisable={jest.fn()} />
        </ThemeProvider>
    );
    const rejectedStatusButton = getByText('Rejected');
    fireEvent.click(rejectedStatusButton);
    expect(rejectedStatusButton).toHaveClass('MuiTypography-root MuiTypography-body8 css-13az3ol-MuiTypography-root');
});


test("submit button is enabled when loading is false", () => {
    render(<ThemeProvider theme={theme}>
        <CssBaseline />
        <BottomDrawer
            getAPI={getAPI}
            loading={false}
            isSubmitted={jest.fn()}
            handleNextWeekDisable={jest.fn()} />
    </ThemeProvider>);
    const submitButton = screen.getByRole("button", { name: "Submit" });
    expect(submitButton).toBeEnabled();
});

test("handleSubmit is called when submit button is clicked", () => {
    const handleSubmit = jest.fn();
    BottomDrawer.prototype.handleSubmit = jest.fn();
    render(<ThemeProvider theme={theme}>
        <CssBaseline />
        <BottomDrawer
            getAPI={getAPI}
            loading={false}
            isSubmitted={jest.fn()}
            handleNextWeekDisable={jest.fn()} 
            handleSubmit={handleSubmit}
            />
    </ThemeProvider>);
    const submitButton = screen.getByRole("button", { name: "Submit" });
    fireEvent.click(submitButton);
    //const aka= BottomDrawer.handleSubmit();
    expect(submitButton).toBeEnabled();
    //expect(BottomDrawer.prototype.handleSubmit).toHaveBeenCalled();
    //expect(handleSubmit).toHaveBeenCalled();
  });
  

