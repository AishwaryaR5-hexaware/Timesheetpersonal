import { getWeeklyTasks } from "../Services/Tasks";
import {getAllTasks} from "../mobile/HandlerFunctions/getAllTasks";
jest.mock('../Services/Tasks');
jest.mock('crypto');
jest.mock('../Services/MsalConfig', () => ({
  msalInstance: {
    getActiveAccount: jest.fn(),
    acquireTokenSilent: jest.fn().mockResolvedValue({ accessToken: 'Xebra3DV_ugCUP6CBrYc8g' }),
  },
}));

jest.mock('../index.js', () => ({
  getActiveAccount: jest.fn(),
  getAllAccounts: jest.fn(),
  setActiveAccount: jest.fn(),
  enableAccountStorageEvents: jest.fn(),
  addEventCallback: jest.fn(),
  acquireTokenSilent: jest.fn().mockResolvedValue({ accessToken: 'Xebra3DV_ugCUP6CBrYc8g' }),
}));
describe('getAllTasks', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should return "Empty" if jsonData is empty', async () => {
    const startDate = '2023-06-01';
    const endDate = '2023-06-07';
    const mockData = { items: [] };
    getWeeklyTasks.mockResolvedValue(mockData);

    const result = await getAllTasks(startDate, endDate);

    expect(getWeeklyTasks).toHaveBeenCalledWith(startDate, endDate);
    expect(result).toBe('Empty');
  });

  it('should group tasks by date', async () => {
    const startDate = '2023-06-01';
    const endDate = '2023-06-07';
    const mockData = {
      items: [
        { timesheet_date: '2023-06-01', task: 'Task 1' },
        { timesheet_date: '2023-06-01', task: 'Task 2' },
        { timesheet_date: '2023-06-02', task: 'Task 3' },
      ],
    };
    getWeeklyTasks.mockResolvedValue(mockData);

    const result = await getAllTasks(startDate, endDate);

    expect(getWeeklyTasks).toHaveBeenCalledWith(startDate, endDate);
    expect(result).toEqual({
      keyValuePairs: {
        '2023-06-01': [
          { timesheet_date: '2023-06-01', task: 'Task 1' },
          { timesheet_date: '2023-06-01', task: 'Task 2' },
        ],
        '2023-06-02': [{ timesheet_date: '2023-06-02', task: 'Task 3' }],
      },
    });
  });
});
