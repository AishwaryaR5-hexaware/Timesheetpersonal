import { handleDropDown } from "../mobile/HandlerFunctions/handleDropDown";
import { getTaskNames } from "../Services/Tasks";

// Mock the getTaskNames function
jest.mock("../Services/Tasks", () => ({
  getTaskNames: jest.fn(),
}));
jest.mock('crypto');
jest.mock('../Services/MsalConfig', () => ({
    msalInstance: {
        getActiveAccount: jest.fn(),
        acquireTokenSilent: jest.fn().mockResolvedValue({ accessToken: '' }),
    },
}));

jest.mock('../index.js', () => ({
    getActiveAccount: jest.fn(),
    getAllAccounts: jest.fn(),
    setActiveAccount: jest.fn(),
    enableAccountStorageEvents: jest.fn(),
    addEventCallback: jest.fn(),
    acquireTokenSilent: jest.fn().mockResolvedValue({ accessToken: '' }),
}));

describe("handleDropDown", () => {
//   beforeEach(() => {
//     // Clear the mock implementation before each test
//     getTaskNames.mockClear();
//   });


  it("should return project and category drop-down lists", async () => {
    // Mock the response from getTaskNames function
    const mockData = {
      projects: ["Project 1", "Project 2", "Project 3"],
      categories: [
        { CategoryName: "Category 1" },
        { CategoryName: "Category 2" },
        { CategoryName: "Category 3" },
      ],
    };
    getTaskNames.mockResolvedValue(mockData);

    // Define the expected results
    const expectedProjects = mockData.projects;
    const expectedCategories = mockData.categories.map(
      (category) => category.CategoryName
    );

    // Call the handleDropDown function
    const [projectDropDownList, categoryDropDownList] = await handleDropDown(
      "June",
      2023
    );

    // Verify the results
    expect(getTaskNames).toHaveBeenCalledWith("June", 2023);
    expect(projectDropDownList).toEqual(expectedProjects);
    expect(categoryDropDownList).toEqual(expectedCategories);
  });

  it("should return empty project and category drop-down lists if getTaskNames returns no data", async () => {
    // Mock an empty response from getTaskNames function
    getTaskNames.mockResolvedValue({
      projects: [],
      categories: [],
    });

    // Call the handleDropDown function
    // const [projectDropDownList, categoryDropDownList] = await handleDropDown(
    //   "June",
    //   2023
    // );
    const result = await handleDropDown(
      "June",
      2023
    );
    expect(result).toBe('No Projects');
    // Verify the results
    expect(getTaskNames).toHaveBeenCalledWith("June", 2023);
   // expect(projectDropDownList).toEqual([]);
   // expect(categoryDropDownList).toEqual([]);
  });

  it("should throw an error if getTaskNames function throws an error", async () => {
    // Mock an error thrown by getTaskNames function
    const errorMessage = "Unable to fetch task names";
    getTaskNames.mockRejectedValue(new Error(errorMessage));

    // Call the handleDropDown function
    await expect(handleDropDown("June", 2023)).rejects.toThrow(errorMessage);

    // Verify that getTaskNames was called
    expect(getTaskNames).toHaveBeenCalledWith("June", 2023);
  });
});
