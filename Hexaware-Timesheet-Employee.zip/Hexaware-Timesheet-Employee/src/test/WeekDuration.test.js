import React from "react";
import { render, fireEvent } from "@testing-library/react";
import WeekDuration, {formatDate, formatDateMonthlySummary} from "../mobile/MonthlyScreenComponent/WeekDuration";
import { CssBaseline, ThemeProvider } from "@mui/material";
import theme from "../theme";
import '@testing-library/jest-dom';

describe("formatDate", () => {
  it("should format the date correctly", () => {
    const date = new Date("2023-06-05");
    const formattedDate = formatDate(date);
    expect(formattedDate).toBe("Jun 5");
  });
});

describe("formatDateMonthlySummary", () => {
  it("should format the date correctly for monthly summary", () => {
    const date = new Date("2023-06-05");
    const formattedDate = formatDateMonthlySummary(date);
    expect(formattedDate).toBe("June 2023");
  });
});


describe("WeekDuration component", () => {
  const weeks = {
    week1: {
      startDate: new Date("2023-06-01"),
      endDate: new Date("2023-06-07"),
    },
    week2: {
      startDate: new Date("2023-06-08"),
      endDate: new Date("2023-06-14"),
    },
    week3: {
      startDate: new Date("2023-06-15"),
      endDate: new Date("2023-06-21"),
    },
  };

  const updateCurrentWeekMock = jest.fn();

  it("should render the component correctly", () => {
    const { getByText} = render(
        <ThemeProvider theme={theme}>
            <CssBaseline />
      <WeekDuration
        flag="mainScreen"
        weeks={weeks}
        currentWeek="week1"
        updateCurrentWeek={updateCurrentWeekMock}
      />
        </ThemeProvider>
    );

    expect(getByText("Jun 1 - Jun 7")).toBeInTheDocument();
  });



  it("should render correctly for mainScreen flag", () => {
    const { getByText, getAllByRole } = render(
      <ThemeProvider theme={theme}>
        <CssBaseline />
      <WeekDuration
        flag="mainScreen"
        weeks={weeks}
        currentWeek="week2"
        updateCurrentWeek={updateCurrentWeekMock}
      />
        </ThemeProvider>
    );

    // Check if the previous button is disabled
    const buttons = getAllByRole("button");

    // Check if the previous button is rendered
    const previousButton = buttons[0];
    expect(previousButton).toBeInTheDocument();
  
    // Check if the next button is enabled
    const nextButton = buttons[1];
    expect(nextButton).toBeEnabled();
  
    // Check if the current week date is displayed correctly
    const currentWeekDate = getByText("Jun 8 - Jun 14");
    expect(currentWeekDate).toBeInTheDocument();
  });


  it("should call updateCurrentWeek with the correct week key when clicking the next button", () => {
    const { getAllByRole } = render(
      <ThemeProvider theme={theme}>
        <CssBaseline />
      <WeekDuration
        flag="mainScreen"
        weeks={weeks}
        currentWeek="week2"
        updateCurrentWeek={updateCurrentWeekMock}
      />
        </ThemeProvider>
    );
    const buttons = getAllByRole("button");
    const nextButton = buttons[1];
    expect(nextButton).toBeEnabled();
    fireEvent.click(nextButton);
  
    expect(updateCurrentWeekMock).toHaveBeenCalledWith("week3");
  });

});
