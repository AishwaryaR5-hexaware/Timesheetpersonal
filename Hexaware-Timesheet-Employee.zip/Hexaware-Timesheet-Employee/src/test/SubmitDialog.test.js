import React from "react";
import { render } from "@testing-library/react";
import SubmitDialog,{statusChange} from "../mobile/HomeScreenComponent/SubmitDialog";
import { CssBaseline, ThemeProvider } from "@mui/material";
import theme from "../theme";
import '@testing-library/jest-dom';

describe("submitDialog", () => {
  it("renders the dialog with the correct props", () => {
    const open = true;
    const handleClose = jest.fn();
    const responseMessage = {
      status: "success",
      reason: "Submission successful",
    };

    const { getByText, getByAltText } = render(
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <SubmitDialog open={open} handleClose={handleClose} responseMessage={responseMessage} />
    </ThemeProvider>
    );

    // Assert the presence of the elements with the expected text
    expect(getByText("success")).toBeInTheDocument();
    expect(getByText("Submission successful")).toBeInTheDocument();

    // // Assert the presence of the image with the correct alt attribute
    const image = getByAltText("submit");
    expect(image).toBeInTheDocument();
    expect(image.getAttribute("src")).toContain("Approve.png");

    // // Assert that the handleClose function is not called initially
    expect(handleClose).not.toHaveBeenCalled();
  });

  // Add more test cases for different scenarios if needed
});
describe('statusChange', () => {
  test('should return "./Missed.png" when status is "warning"', () => {
    const result = statusChange("warning");
    expect(result).toBe("./Missed.png");
  });

  test('should return "./Approve.png" when status is "success"', () => {
    const result = statusChange("success");
    expect(result).toBe("./Approve.png");
  });

  test('should return "./Reject.png" when status is "rejected"', () => {
    const result = statusChange("rejected");
    expect(result).toBe("./Reject.png");
  });

  test('should return "./Missed.png" when status is not "warning", "success", or "rejected"', () => {
    const result = statusChange("invalid");
    expect(result).toBe("./Missed.png");
  });

  test('should be case insensitive for status values', () => {
    const result1 = statusChange("WARNING");
    const result2 = statusChange("SUCCESS");
    const result3 = statusChange("REJECTED");

    expect(result1).toBe("./Missed.png");
    expect(result2).toBe("./Approve.png");
    expect(result3).toBe("./Reject.png");
  });
});