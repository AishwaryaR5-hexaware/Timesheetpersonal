import axios from "axios";
import { serviceConfig } from "../Services/serviceConfig";
import log from "loglevel";
import { getAuthToken } from "../Services/AuthToken";
import "@testing-library/jest-dom";
jest.mock("axios");
jest.mock("../Services/serviceConfig");
jest.mock("loglevel");
describe("getAuthToken", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it("should send an authentication request with the correct data and headers", async () => {
    const mockResponse = { data: "authToken" };
    axios.mockResolvedValueOnce(mockResponse);

    await getAuthToken();

    expect(axios).toHaveBeenCalledWith({
      method: "post",
      url: serviceConfig.routes.authUrl,
      headers: {
        Authorization: `Basic ${process.env.REACT_APP_ORACLE_AUTH_TOKEN}`,
        "Content-Type": "application/json",
      },
      data: JSON.stringify({
        client_id: process.env.REACT_APP_ORACLE_CLIENT_ID,
        client_secret: process.env.REACT_APP_ORACLE_CLIENT_SECRET,
        grant_type: "client_credentials",
      }),
    });
  });

  it("should log the info message before sending the authentication request", async () => {
    const mockResponse = { data: "authToken" };
    axios.mockResolvedValueOnce(mockResponse);

    await getAuthToken();

    expect(log.info).toHaveBeenCalledWith("Sending authentication request...");
  });

  it("should log the info message after a successful authentication request", async () => {
    const mockResponse = { data: "authToken" };
    axios.mockResolvedValueOnce(mockResponse);

    await getAuthToken();

    expect(log.info).toHaveBeenCalledWith("Authentication request successful");
  });
});
