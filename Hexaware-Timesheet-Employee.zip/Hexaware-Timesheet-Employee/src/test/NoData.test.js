import React from "react";
import { render } from "@testing-library/react";
import NoData from "../mobile/HomeScreenComponent/NoData";
import { CssBaseline, ThemeProvider } from "@mui/material";
import theme from "../theme";
import '@testing-library/jest-dom';

// describe("NoData", () => {
//   it("renders the component with the correct content", () => {
//     const { getByText, getByAltText } = render(<NoData />);

//     // Assert the presence of the elements with the expected text
//     expect(getByAltText('No data found')).toBeVisible();
//     expect(getByText("Oops!")).toBeInTheDocument();
//     expect(getByText("You have no task allocations for this week!")).toBeInTheDocument();
//   });

//   // Add more test cases if needed
// });

describe("NoData Component", () => {
  test("renders the component without errors", () => {
    render(
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <NoData />
      </ThemeProvider>
    );
    // No errors thrown means the component rendered successfully
  });

  test("displays the correct image", () => {
    const { getByText, getByAltText } = render(
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <NoData />
      </ThemeProvider>
    );
    const image = getByAltText("No data found");
    expect(image).toBeInTheDocument();
    expect(image.getAttribute("src")).toContain("Missed.png");
    //expect(image.src).toContain("success icon.png");
  });

  test("displays the correct title", () => {
    const { getByText } = render(
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <NoData />
      </ThemeProvider>
    );
    const title = getByText("Oops!");
    expect(title).toBeInTheDocument();
  });

  test("displays the correct message", () => {
    const messageProp='You have no task allocations for this week!'
    const { getByText } = render(
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <NoData message={messageProp} />
      </ThemeProvider>
    );
    const message = getByText("You have no task allocations for this week!");
    expect(message).toBeInTheDocument();
  });
});
