import {
    getLastSundayOfMonth,
    getFirstSundayOfMonth,
    formatDate,
    getCurrentMonthWeeks,
  } from "../mobile/HandlerFunctions/CurrentMonthWeek";
  
  describe("getLastSundayOfMonth", () => {
    it("should return the last Sunday of the month when the month ends on a Sunday", () => {
      const year = 2023;
      const month = 0; // January (0-based index)
      const lastSunday = getLastSundayOfMonth(year, month);
      expect(lastSunday.getFullYear()).toEqual(2023);
      expect(lastSunday.getMonth()).toEqual(0);
      expect(lastSunday.getDate()).toEqual(29);
    });
  
    it("should return the last Sunday of the month when the month ends on a weekday", () => {
      const year = 2023;
      const month = 1; // February (0-based index)
      const lastSunday = getLastSundayOfMonth(year, month);
      expect(lastSunday.getFullYear()).toEqual(2023);
      expect(lastSunday.getMonth()).toEqual(1);
      expect(lastSunday.getDate()).toEqual(26);
    });
  });
  
  describe("getFirstSundayOfMonth", () => {
    it("should return the first Sunday of the month when the month starts with a Sunday", () => {
      const year = 2023;
      const month = 2; // March (0-based index)
      const firstSunday = getFirstSundayOfMonth(year, month);
      expect(firstSunday.getFullYear()).toEqual(2023);
      expect(firstSunday.getMonth()).toEqual(2);
      expect(firstSunday.getDate()).toEqual(5);
    });
  
    it("should return the first Sunday of the month when the month starts with a weekday", () => {
      const year = 2023;
      const month = 3; // April (0-based index)
      const firstSunday = getFirstSundayOfMonth(year, month);
      expect(firstSunday.getFullYear()).toEqual(2023);
      expect(firstSunday.getMonth()).toEqual(3);
      expect(firstSunday.getDate()).toEqual(2);
    });
  });
  
  describe("formatDate", () => {
    it("should format the date in the correct format for a single-digit day", () => {
      const date = new Date(2023, 5, 1);
      const formattedDate = formatDate(date);
      expect(formattedDate).toEqual("Jun 1 2023");
    });
  });
  
  // describe("getCurrentMonthWeeks", () => {
  
  //   it("should return the correct weeks and current week for a month with multiple weeks", () => {
  //     const { weeks, todayDate, todayWeek } = getCurrentMonthWeeks();
  //     const expectedWeeks = {
  //       week1: {
  //         startDate: expect.any(Date),
  //         endDate: expect.any(Date),
  //       },
  //       week2: {
  //         startDate: expect.any(Date),
  //         endDate: expect.any(Date),
  //       },
  //       week3: {
  //         startDate: expect.any(Date),
  //         endDate: expect.any(Date),
  //       },
  //       week4: {
  //         startDate: expect.any(Date),
  //         endDate: expect.any(Date),
  //       },
  //       week5: {
  //         startDate: expect.any(Date),
  //         endDate: expect.any(Date),
  //       },
  //     };
  
  //     expect(weeks).toEqual(expectedWeeks);
  //     expect(todayDate instanceof Date).toBe(true);
  //     expect(typeof todayWeek).toBe("string");
  //     expect(Object.keys(weeks)).toContain(todayWeek);
  //   });
  // });
  