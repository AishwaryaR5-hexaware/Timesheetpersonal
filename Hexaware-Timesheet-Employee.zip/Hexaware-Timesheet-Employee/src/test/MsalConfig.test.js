import { getToken } from '../Services/MsalConfig';
import { msalInstance } from '../index';
import log from 'loglevel';

jest.mock('../index', () => ({
  msalInstance: {
    getActiveAccount: jest.fn(),
    acquireTokenSilent: jest.fn(),
    acquireTokenRedirect: jest.fn(),
  },
}));

jest.mock('loglevel', () => ({
  setLevel: jest.fn(),
  info: jest.fn(),
  error: jest.fn(),
}));

describe('getToken', () => {
  beforeEach(() => {
    msalInstance.getActiveAccount.mockClear();
    msalInstance.acquireTokenSilent.mockClear();
    msalInstance.acquireTokenRedirect.mockClear();
    log.info.mockClear();
    log.error.mockClear();
  });

  test('should throw an error if no active account is available', async () => {
    msalInstance.getActiveAccount.mockReturnValueOnce(null);

    try {
      await getToken(['scope1', 'scope2']);
    } catch (error) {
      expect(error).toEqual(new Error('No active account! Verify a user has been signed in and setActiveAccount has been called.'));
      expect(log.error).toHaveBeenCalledWith('No active account! Verify a user has been signed in and setActiveAccount has been called.');
    }
  });

  test('should acquire token silently if an active account is available', async () => {
    const response = { accessToken: 'token' };
    msalInstance.getActiveAccount.mockReturnValueOnce({ /* mock account */ });
    msalInstance.acquireTokenSilent.mockResolvedValueOnce(response);
  
    const token = await getToken(['scope1', 'scope2']);
  
    expect(token).toBe(response.accessToken);
    expect(log.info).toHaveBeenCalledWith('getToken called');
    expect(log.info).toHaveBeenCalledWith('Acquiring token silently...');
    expect(log.info).toHaveBeenCalledWith('Token acquired successfully');
    expect(log.error).not.toHaveBeenCalled();
    expect(msalInstance.acquireTokenRedirect).not.toHaveBeenCalled();
  });
  
  test('should acquire token using redirect if an error occurs while acquiring token silently', async () => {
    msalInstance.getActiveAccount.mockReturnValueOnce({ /* mock account */ });
    msalInstance.acquireTokenSilent.mockRejectedValueOnce(new Error('Token acquisition error'));
  
    await getToken(['scope1', 'scope2']);
  
    expect(log.info).toHaveBeenCalledWith('getToken called');
    expect(log.info).toHaveBeenCalledWith('Acquiring token silently...');
    expect(log.error).toHaveBeenCalledWith('Error occurred while acquiring token silently:', new Error('Token acquisition error'));
    expect(log.info).toHaveBeenCalledWith('Acquiring token using redirect...');
    expect(msalInstance.acquireTokenRedirect).toHaveBeenCalledWith({ account: { /* mock account */ }, scopes: ['scope1', 'scope2'] });
  });
  
});
