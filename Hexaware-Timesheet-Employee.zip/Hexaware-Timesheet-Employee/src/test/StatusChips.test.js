import React from "react";
import { render } from "@testing-library/react";
import StatusChips from "../mobile/HandlerFunctions/StatusChips";
import { CssBaseline, ThemeProvider } from "@mui/material";
import theme from "../theme";
import "@testing-library/jest-dom";
describe("StatusChips", () => {
  it("should render Submitted chip correctly", () => {
    const { getByText } = render(
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <StatusChips status="Submitted" />
      </ThemeProvider>
    );
    const chipElement = getByText("Submitted");
    expect(chipElement).toBeInTheDocument();
  });

  it("should render Not Submitted chip correctly", () => {
    const { getByText } = render(
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <StatusChips status="Not Submitted" />
      </ThemeProvider>
    );
    const chipElement = getByText("Not-Submitted");
    expect(chipElement).toBeInTheDocument();
  });
  
  it("should render Auto Submitted chip correctly", () => {
    const { getByText } = render(
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <StatusChips status="Auto Submitted" />
      </ThemeProvider>
    );
    const chipElement = getByText("Auto-Submitted");
    expect(chipElement).toBeInTheDocument();
  });

  it("should render Approved chip correctly", () => {
    const { getByText } = render(
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <StatusChips status="Approved" />
      </ThemeProvider>
    );
    const chipElement = getByText("Approved");
    expect(chipElement).toBeInTheDocument();
  });

  it("should render Rejected chip correctly", () => {
    const { getByText } = render(
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <StatusChips status="Rejected" />
      </ThemeProvider>
    );
    const chipElement = getByText("Rejected");
    expect(chipElement).toBeInTheDocument();
  });

  it("should render default chip correctly", () => {
    const { getByText } = render(
      <ThemeProvider theme={theme}>
        <CssBaseline />
        <StatusChips status="Default Status" />
      </ThemeProvider>
    );
    const chipElement = getByText("Not-Submitted");
    expect(chipElement).toBeInTheDocument();
  });
});
