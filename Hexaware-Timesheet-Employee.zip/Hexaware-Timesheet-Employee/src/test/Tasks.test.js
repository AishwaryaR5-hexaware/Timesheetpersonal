import axios from "axios";
import { formatDate,getAccessToken,getEmployeeId,getWeeklyTasks } from '../Services/Tasks';
import { getAuthToken } from '../Services/AuthToken';
import { getProfileInfo } from '../Services/Profile';
jest.mock('crypto');
jest.mock('../Services/MsalConfig', () => ({
  msalInstance: {
    getActiveAccount: jest.fn(),
    acquireTokenSilent: jest.fn().mockResolvedValue({ accessToken: 'Xebra3DV_ugCUP6CBrYc8g' }),
  },
}));

jest.mock('../index.js', () => ({
  getActiveAccount: jest.fn(),
  getAllAccounts: jest.fn(),
  setActiveAccount: jest.fn(),
  enableAccountStorageEvents: jest.fn(),
  addEventCallback: jest.fn(),
  acquireTokenSilent: jest.fn().mockResolvedValue({ accessToken: 'Xebra3DV_ugCUP6CBrYc8g' }),
}));

describe('formatDate', () => {
  it('should return the correctly formatted date', () => {
    const date = new Date('2023-05-25');
    const formattedDate = formatDate(date);
    expect(formattedDate).toEqual('2023-05-25');
  });

  it('should return the correctly formatted date when the month is a single digit', () => {
    const date = new Date('2023-1-03');
    const formattedDate = formatDate(date);
    expect(formattedDate).toEqual('2023-01-3');
  });

  it('should return the correctly formatted date when the day is a single digit', () => {
    const date = new Date('2023-12-05');
    const formattedDate = formatDate(date);
    expect(formattedDate).toEqual('2023-12-5');
  });

  it('should handle invalid date', () => {
    const date = new Date('invalid-date');
    const formattedDate = formatDate(date);
    expect(formattedDate).toEqual('NaN-aN-NaN');
  });
});

jest.mock('../Services/AuthToken');
describe('getAccessToken', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });
  it('should return the access token obtained from getAuthToken', async () => {
    const mockAccessToken = 'mockAccessToken';
    getAuthToken.mockResolvedValueOnce({ access_token: mockAccessToken });

    const result = await getAccessToken();

    expect(result).toEqual(mockAccessToken);
  });

  it('should call getAuthToken function', async () => {
    const mockAccessToken = 'mockAccessToken';
    getAuthToken.mockResolvedValueOnce({ access_token: mockAccessToken });

    await getAccessToken();

    expect(getAuthToken).toHaveBeenCalledTimes(1);
  });

  it('should throw an error if getAuthToken throws an error', async () => {
    const mockError = new Error('Authentication error');
    getAuthToken.mockRejectedValueOnce(mockError);

    await expect(getAccessToken()).rejects.toThrowError('Authentication error');
  });
});
jest.mock('../Services/Profile');
describe('getEmployeeId', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    process.env.REACT_APP_ENVIRONMENT = 'dev'; // Setting environment to 'dev' for initial tests
    localStorage.clear(); // Clearing localStorage before each test
  });

  afterAll(() => {
    delete process.env.REACT_APP_ENVIRONMENT; // Resetting the environment after all tests
  });

  it('should return the stored employee ID from localStorage when environment is "dev"', async () => {
    const mockStoredEmpId = '123456';
    localStorage.setItem('empId', mockStoredEmpId);

    const result = await getEmployeeId();

    expect(result).toEqual(mockStoredEmpId);
  });

  it('should call getProfileInfo function and return the employee ID from userPrincipalName when environment is not "dev"', async () => {
    const mockProfileData = { userPrincipalName: 'john.doe@example.com' };
    getProfileInfo.mockResolvedValueOnce(mockProfileData);

    process.env.REACT_APP_ENVIRONMENT = 'prod'; // Setting environment to 'prod' for this test

    const result = await getEmployeeId();

    expect(getProfileInfo).toHaveBeenCalledTimes(1);
    expect(result).toEqual('john.doe');
  });

  it('should return null when environment is "dev" but no employee ID is stored in localStorage', async () => {
    const result = await getEmployeeId();

    expect(result).toBeNull();
  });

  it('should throw an error if getProfileInfo throws an error when environment is not "dev"', async () => {
    const mockError = new Error('Profile info error');
    getProfileInfo.mockRejectedValueOnce(mockError);

    process.env.REACT_APP_ENVIRONMENT = 'prod'; // Setting environment to 'prod' for this test

    await expect(getEmployeeId()).rejects.toThrowError('Profile info error');
  });
});

