import axios from "axios";
import { getProfileInfo } from "../Services/Profile"; // Replace "yourFile" with the actual file name
import { getToken } from "../Services/MsalConfig";
import { loginRequest } from "../authConfig";
import { serviceConfig } from "../Services/serviceConfig";

jest.mock("axios");
jest.mock("../Services/MsalConfig", () => ({
  getToken: jest.fn(),
}));
jest.mock("../authConfig", () => ({
  loginRequest: {
    scopes: "mockScopes",
  },
}));
jest.mock("../Services/serviceConfig", () => ({
  serviceConfig: {
    profile: {
      profileInfo: "mockProfileInfo",
      profilePhoto: "mockProfilePhoto",
    },
  },
}));

describe("getProfileInfo", () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  it("should retrieve profile info successfully", async () => {
    const accessToken = "mockAccessToken";
    const data = {
      "@odata.context": "",
      businessPhones: [],
      displayName: "Jaisingh Dhande",
      givenName: "Jaisingh",
      jobTitle: "Associate Software Engineer",
      mail: "JaisinghD@hexaware.com",
      mobilePhone: null,
      officeLocation: null,
      preferredLanguage: null,
      surname: "Dhande",
      userPrincipalName: "2000077250@hexaware.com",
      id: "",
    };
    axios.mockResolvedValueOnce({ data });
    getToken.mockResolvedValueOnce(accessToken);
    const result = await getProfileInfo();

    expect(getToken).toHaveBeenCalledWith("mockScopes");
    expect(axios).toHaveBeenCalledWith({
      method: "get",
      url: "mockProfileInfo",
      headers: { Authorization: `Bearer ${accessToken}` },
    });
    expect(result).toEqual(data);
  });

  it("should handle error while retrieving profile info", async () => {
    const accessToken = "mockAccessToken";
    const error = new Error("Failed to retrieve profile info");
    axios.mockRejectedValueOnce(error);
    getToken.mockResolvedValueOnce(accessToken);

    const result = await getProfileInfo();

    expect(getToken).toHaveBeenCalledWith("mockScopes");
    expect(axios).toHaveBeenCalledWith({
      method: "get",
      url: "mockProfileInfo",
      headers: { Authorization: `Bearer ${accessToken}` },
    });
    expect(result).toBeUndefined();
    // You can also add assertions to check how the error is handled
  });
});
