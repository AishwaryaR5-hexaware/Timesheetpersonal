import React from "react";
import ConfirmDialog from "../mobile/HomeScreenComponent/ConfirmDialog";
import { CssBaseline, ThemeProvider } from "@mui/material";
import theme from "../theme";
import "@testing-library/jest-dom";
import { render, fireEvent } from "@testing-library/react";

describe("ConfirmDialog Component", () => {
    test("renders the component without errors", () => {
      render(
        <ThemeProvider theme={theme}>
        <CssBaseline />
       <ThemeProvider theme={theme}>
        <CssBaseline />
        <ConfirmDialog
          confirmDialogOpen={true}
          handleSubmit={() => {}}
          handleConfirmDialog={() => {}}
        />
        </ThemeProvider>
        </ThemeProvider>
      );
      // No errors thrown means the component rendered successfully
    });
  
    test("displays the correct image", () => {
      const { getByAltText } = render(
       <ThemeProvider theme={theme}>
        <CssBaseline />
        <ConfirmDialog
          confirmDialogOpen={true}
          handleSubmit={() => {}}
          handleConfirmDialog={() => {}}
        />
        </ThemeProvider>
      );
      const image = getByAltText("submit");
      expect(image).toBeInTheDocument();
      expect(image.getAttribute("src")).toContain("Missed.png");
      
    });
  
    test("displays the correct message", () => {
      const { getByText } = render(
       <ThemeProvider theme={theme}>
        <CssBaseline />
        <ConfirmDialog
          confirmDialogOpen={true}
          handleSubmit={() => {}}
          handleConfirmDialog={() => {}}
        />
        </ThemeProvider>
      );
      const message = getByText(
        "The net hours filled are greater than standard hours, do you want to continue?"
      );
      expect(message).toBeInTheDocument();
    });
  
    test("calls the handleSubmit function when 'Yes, Submit' button is clicked", () => {
      const handleSubmit = jest.fn();
      const { getByText } = render(
        <ThemeProvider theme={theme}>
        <CssBaseline />
        <ConfirmDialog
          confirmDialogOpen={true}
          handleSubmit={handleSubmit}
          handleConfirmDialog={() => {}}
        />
        </ThemeProvider>
      );
      const submitButton = getByText("Yes, Submit");
      fireEvent.click(submitButton);
      expect(handleSubmit).toHaveBeenCalledTimes(1);
    });
  
    test("calls the handleConfirmDialog function when 'Cancel' button is clicked", () => {
      const handleConfirmDialog = jest.fn();
      const { getByText } = render(
        <ThemeProvider theme={theme}>
        <CssBaseline />
        <ConfirmDialog
          confirmDialogOpen={true}
          handleSubmit={() => {}}
          handleConfirmDialog={handleConfirmDialog}
        />
        </ThemeProvider>
      );
      const cancelButton = getByText("Cancel");
      fireEvent.click(cancelButton);
      expect(handleConfirmDialog).toHaveBeenCalledTimes(1);
    });
  });