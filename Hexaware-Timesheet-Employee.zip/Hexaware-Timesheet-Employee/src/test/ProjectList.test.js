import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import ProjectList from "../mobile/HomeScreenComponent/ProjectList";
import { CssBaseline, ThemeProvider } from "@mui/material";
import theme from "../theme";
import { MemoryRouter } from "react-router-dom"
import '@testing-library/jest-dom';

const appInsightsEnv = process.env.REACT_APP_APPINSIGHTS
jest.mock('../Services/MsalConfig', () => ({
    msalInstance: {
        getActiveAccount: jest.fn(),
        acquireTokenSilent: jest.fn().mockResolvedValue({ accessToken: '' }),
    },
}));

jest.mock('../index.js', () => ({
    getActiveAccount: jest.fn(),
    getAllAccounts: jest.fn(),
    setActiveAccount: jest.fn(),
    enableAccountStorageEvents: jest.fn(),
    addEventCallback: jest.fn(),
    acquireTokenSilent: jest.fn().mockResolvedValue({ accessToken: '' }),
}));

const getAPI = {



    "2023-05-21": [

        {

            "employee_id": "2000077250",

            "timesheet_tasks_id": 551337,

            "timesheet_date": "2023-05-21",

            "project_name": "InnovationLab - Research & Development.",

            "project_id": "PRJ-8370",

            "timesheet_task_type": "BILLING",

            "timesheet_task_hours": 0,

            "timesheet_task_minutes": 0,

            "standard_hours": 0,

            "standard_minutes": 0,

            "is_wfh": 0,

            "is_holiday": 0,

            "hex_status": "",

            "submitted_by": "",

            "submitted_by_name": "",

            "approved_by": "",

            "approved_by_name": "",

            "source": "WEB",

            "primary_project": "Y"

        }

    ],

    "2023-05-22": [

        {

            "employee_id": "2000077250",

            "timesheet_tasks_id": 551338,

            "timesheet_date": "2023-05-22",

            "project_name": "InnovationLab - Research & Development.",

            "project_id": "PRJ-8370",

            "timesheet_task_type": "BILLING",

            "timesheet_task_hours": 8,

            "timesheet_task_minutes": 45,

            "standard_hours": 8,

            "standard_minutes": 45,

            "is_wfh": 0,

            "is_holiday": 0,

            "hex_status": "",

            "submitted_by": "",

            "submitted_by_name": "",

            "approved_by": "",

            "approved_by_name": "",

            "source": "WEB",

            "primary_project": "Y"

        }

    ],

    "2023-05-23": [

        {

            "employee_id": "2000077250",

            "timesheet_tasks_id": 551339,

            "timesheet_date": "2023-05-23",

            "project_name": "InnovationLab - Research & Development.",

            "project_id": "PRJ-8370",

            "timesheet_task_type": "BILLING",

            "timesheet_task_hours": 8,

            "timesheet_task_minutes": 45,

            "standard_hours": 8,

            "standard_minutes": 45,

            "is_wfh": 0,

            "is_holiday": 0,

            "hex_status": "",

            "submitted_by": "",

            "submitted_by_name": "",

            "approved_by": "",

            "approved_by_name": "",

            "source": "WEB",

            "primary_project": "Y"

        }

    ],

    "2023-05-24": [

        {

            "employee_id": "2000077250",

            "timesheet_tasks_id": 551340,

            "timesheet_date": "2023-05-24",

            "project_name": "InnovationLab - Research & Development.",

            "project_id": "PRJ-8370",

            "timesheet_task_type": "BILLING",

            "timesheet_task_hours": 8,

            "timesheet_task_minutes": 45,

            "standard_hours": 8,

            "standard_minutes": 45,

            "is_wfh": 0,

            "is_holiday": 0,

            "hex_status": "",

            "submitted_by": "",

            "submitted_by_name": "",

            "approved_by": "",

            "approved_by_name": "",

            "source": "WEB",

            "primary_project": "Y"

        }

    ],

    "2023-05-25": [

        {

            "employee_id": "2000077250",

            "timesheet_tasks_id": 551341,

            "timesheet_date": "2023-05-25",

            "project_name": "InnovationLab - Research & Development.",

            "project_id": "PRJ-8370",

            "timesheet_task_type": "BILLING",

            "timesheet_task_hours": 8,

            "timesheet_task_minutes": 45,

            "standard_hours": 8,

            "standard_minutes": 45,

            "is_wfh": 0,

            "is_holiday": 0,

            "hex_status": "",

            "submitted_by": "",

            "submitted_by_name": "",

            "approved_by": "",

            "approved_by_name": "",

            "source": "WEB",

            "primary_project": "Y"

        }

    ],

    "2023-05-26": [

        {

            "employee_id": "2000077250",

            "timesheet_tasks_id": 551342,

            "timesheet_date": "2023-05-26",

            "project_name": "InnovationLab - Research & Development.",

            "project_id": "PRJ-8370",

            "timesheet_task_type": "BILLING",

            "timesheet_task_hours": 8,

            "timesheet_task_minutes": 45,

            "standard_hours": 8,

            "standard_minutes": 45,

            "is_wfh": 0,

            "is_holiday": 0,

            "hex_status": "",

            "submitted_by": "",

            "submitted_by_name": "",

            "approved_by": "",

            "approved_by_name": "",

            "source": "WEB",

            "primary_project": "Y"

        }

    ],

    "2023-05-27": [

        {

            "employee_id": "2000077250",

            "timesheet_tasks_id": 551343,

            "timesheet_date": "2023-05-27",

            "project_name": "InnovationLab - Research & Development.",

            "project_id": "PRJ-8370",

            "timesheet_task_type": "BILLING",

            "timesheet_task_hours": 0,

            "timesheet_task_minutes": 0,

            "standard_hours": 0,

            "standard_minutes": 0,

            "is_wfh": 0,

            "is_holiday": 0,

            "hex_status": "",

            "submitted_by": "",

            "submitted_by_name": "",

            "approved_by": "",

            "approved_by_name": "",

            "source": "WEB",

            "primary_project": "Y"

        }

    ]




};
const updateSetAPI = jest.fn();
const loading = false;
const isSubmitted = jest.fn();
const handleNextWeekDisable = jest.fn();

test("ProjectList component renders correctly", () => {
    render(<ThemeProvider theme={theme}>
        <CssBaseline />
        <MemoryRouter>
            <ProjectList />
        </MemoryRouter>
    </ThemeProvider>);
});



// it('renders project details correctly', () => {

//     const mockGetAPI = {
//         '2023-06-01': [
//             {
//                 timesheet_task_type: 'Task Type 1',
//                 project_name: 'Project 1',
//                 timesheet_task_hours: 2,
//                 timesheet_task_minutes: 30,
//                 is_wfh: 0,
//                 project_id:'PRJ',
//             },
//         ],
//     };

//     const mockUpdateSetAPI = jest.fn();
//     const mockHandleNextWeekDisable = jest.fn();

//     render(
//         <ThemeProvider theme={theme}>
//             <CssBaseline />
//             <MemoryRouter>
//                 <ProjectList
//                     getAPI={mockGetAPI}
//                     updateSetAPI={mockUpdateSetAPI}
//                     loading={false}
//                     isSubmitted={jest.fn()}
//                     handleNextWeekDisable={mockHandleNextWeekDisable}
//                 />
//             </MemoryRouter>
//         </ThemeProvider>
//     );

//     // Verify that project details are rendered correctly
//     // const projectType = screen.getByText('PRJ');
//     // expect(projectType).toBeInTheDocument();

//     const projectName = screen.getByText('Project 1');
//     expect(projectName).toBeInTheDocument();

//     const hoursMinutes = screen.getByText('02:30');
//     expect(hoursMinutes).toBeInTheDocument();

//     // const addAdditionalHoursButton = screen.getByText('+ Add additional hours');
//     // expect(addAdditionalHoursButton).toBeInTheDocument();
//     const addAdditionalHoursImage = screen.getByAltText('+');
//     expect(addAdditionalHoursImage).toBeInTheDocument();
// });

// it(' addAdditionalHoursButton button is enabled when isSubmitted is not called', () => {

//     const mockGetAPI = {
//         '2023-07-02': [
//             {
//                 timesheet_task_type: 'Task Type 1',
//                 project_name: 'Project 1',
//                 timesheet_task_hours: 2,
//                 timesheet_task_minutes: 30,
//                 is_wfh: 0,
//             },
//         ],
//     };

//     const mockUpdateSetAPI = jest.fn();
//     const mockHandleNextWeekDisable = jest.fn();

//     render(
//         <ThemeProvider theme={theme}>
//             <CssBaseline />
//             <MemoryRouter>
//                 <ProjectList
//                     getAPI={mockGetAPI}
//                     updateSetAPI={mockUpdateSetAPI}
//                     loading={false}
//                     isSubmitted={jest.fn()}
//                     handleNextWeekDisable={mockHandleNextWeekDisable}
//                 />
//             </MemoryRouter>
//         </ThemeProvider>
//     );

//     // const addAdditionalHoursButton = screen.getByText('+ Add additional hours');
//     // expect(addAdditionalHoursButton).toBeEnabled();
//     const addAdditionalHoursImage = screen.getByAltText('+');
//     expect(addAdditionalHoursImage).toBeInTheDocument();
// });

// it('disables addAdditionalHoursButton when isSubmitted is true', () => {

//     const mockGetAPI = {
//         '2023-06-01': [
//             {
//                 timesheet_task_type: 'Task Type 1',
//                 project_name: 'Project 1',
//                 timesheet_task_hours: 2,
//                 timesheet_task_minutes: 30,
//                 is_wfh: 0,
//             },
//         ],
//     };

//     const mockUpdateSetAPI = jest.fn();
//     const mockHandleNextWeekDisable = jest.fn();

//     const mockNextOrPrevMonthCheck = jest.fn();

//     render(
//         <ThemeProvider theme={theme}>
//             <CssBaseline />
//             <MemoryRouter>
//       <ProjectList
//         getAPI={mockGetAPI}
//         updateSetAPI={mockUpdateSetAPI}
//         loading={false}
//         isSubmitted={jest.fn().mockReturnValue(true)}
//         handleNextWeekDisable={mockHandleNextWeekDisable}
//         nextOrPrevMonthCheck={mockNextOrPrevMonthCheck}
//       />
//     </MemoryRouter>
//     </ThemeProvider>
//     );

//     // const addAdditionalHoursButton = screen.getByText('+ Add additional hours');
//     // expect(addAdditionalHoursButton).toBeDisabled();
//     const addAdditionalHoursImage = screen.getByAltText('+');
//     expect(addAdditionalHoursImage).toBeInTheDocument();
//   });

  