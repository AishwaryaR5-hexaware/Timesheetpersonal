import React, { useContext } from "react";
import { Box, Button, Grid, TextField, Typography } from "@mui/material";
const WebLogin = () => {

  return (
    <Box
    sx={{
      height: "100vh",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      backgroundColor: "#FFFFFF",
    }}
  >
    <Grid
      container
      direction="column"
      sx={{ width: "90%" }}
      justifyContent="space-between"
      alignItems="center"
    >
      <Grid item xs={12}>
        <img
          src="/splash screen illustration.png"
          style={{ width: "120px", height: "100px" }}
          alt="login"
        />
      </Grid>
      <Grid item xs={12} sx={{ marginBottom: "30px", marginTop: "30px" }}>
        <Typography
          sx={{
            fontFamily: "Poppins",
            fontSize: "20px",
            color: "#312E49",
            fontWeight: "600",
            textAlign: "center",
          }}
        >
          Organise your timesheet from anywhere
        </Typography>
      </Grid>
           <Grid item xs={12}>
        <Button
          onClick={() => {
            window.location.href ='https://g60773a4804e254-paasatpdev1.adb.eu-frankfurt-1.oraclecloudapps.com/ords/r/dhr/otl616/timesheet-bh';
          }}
          variant="contained"
          color="primary"
          sx={{
            // width: "100%",
            borderRadius: "6px",
            backgroundColor: "#1E2F98",
            fontFamily: "Poppins",
            fontSize: "14px",
            color: "#FFFFFF",
            fontWeight: "600",
            textTransform: "none",
          }}
        >
          Get Started
        </Button>
      </Grid>
    </Grid>
  </Box>
  )
}

export default WebLogin