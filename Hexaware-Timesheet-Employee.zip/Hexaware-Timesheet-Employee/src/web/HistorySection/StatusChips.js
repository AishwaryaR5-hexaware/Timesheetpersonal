import { Chip } from '@mui/material'
import React from 'react'

const StatusChips = ({status}) => {
    const styles = {
        chip:{
            color: '#fff',
            fontSize: '12px',
            padding: '2px 8px',
            borderRadius: '14px' 
        },
        submittedChip : {
            background: '#17A7C7',
        },
        notSubmittedChip : {
            background: '#F48116',
        },
        autoSubmittedChip : {
            background: '#6473CF',
        },
        approvedChip : {
            background: '#14B383',
        },
        rejectedChip : {
            background: '#ED7767',
        }
        
    }
    //create a switch case for the status which returns jsx
    switch (status) {
        case 'submitted':
            return <Chip label="Submitted" style={styles.submittedChip} sx={styles.chip} />
        case 'not-submitted':
            return <Chip label="Not-Submitted" style={styles.notSubmittedChip} sx={styles.chip}  />
        case 'auto-submitted':
            return <Chip label="Auto-Submitted" style={styles.autoSubmittedChip} sx={styles.chip} />
        case 'approved':
            return <Chip label="Approved" style={styles.approvedChip} sx={styles.chip} />
        case 'rejected':
            return <Chip label="Rejected" style={styles.rejectedChip} sx={styles.chip} />
        default:
            return <Chip label="Not-Submitted" style={styles.notSubmittedChip} sx={styles.chip} />
    }
}

export default StatusChips