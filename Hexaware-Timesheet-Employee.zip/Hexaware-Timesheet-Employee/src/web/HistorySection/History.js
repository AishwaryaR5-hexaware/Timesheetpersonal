import React from 'react'
import { Grid, IconButton, Typography } from '@mui/material';
import ArrowBackIosNewIcon from '@mui/icons-material/ArrowBackIosNew';

import { useNavigate } from 'react-router-dom';
import TabSection from './TabSection';

const History = () => {

    const navigate = useNavigate();

    const styles = {
        icon: {
            color: '#1E2F98',
            fontSize: '24px',
        },
        heading: {
            color: '#181D3D',
            fontSize: '18px',
            fontWeight: '600',
        },
    }

    return (
        <Grid container mt={3} direction={'row'} >
            <Grid item ml={10} xs={12} mr={12}>
                <Grid container alignItems={'center'}>
                    <Grid item  >
                        <IconButton onClick={() => navigate('/')} >
                            <ArrowBackIosNewIcon style={styles.icon} />
                        </IconButton>
                    </Grid>
                    <Grid item >
                        <Typography style={styles.heading}>Timesheet History</Typography>
                    </Grid>
                </Grid>
            </Grid>
            <Grid item ml={10} xs={12} mr={12} mt={2}>
                <TabSection />
            </Grid>

        </Grid>
    )
}

export default History