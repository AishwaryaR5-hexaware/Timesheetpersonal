import React, { useState } from 'react';
import { Tabs, Tab, Box, Grid } from '@mui/material';
import { styled } from '@mui/material/styles';
import LogSection from './LogSection/LogSection';
import SummarySection from './SummarySection/SummarySection';

const StyledTabs = styled((props) => (
  <Tabs
    {...props}
    TabIndicatorProps={{ children: <span className="MuiTabs-indicatorSpan" /> }}
  />
))({
  '& .MuiTabs-indicator': {
    height: '4px',
    backgroundColor: '#1E2F98',
  },
  '& .MuiTabs-indicatorSpan': {
    width: '100%',
  },
});

const StyledTab = styled((props) => <Tab disableRipple {...props} />)(
  () => ({
    textTransform: 'none',
    fontWeight: 400,
    fontSize: '16px',
    color: '#1E2F98',
    '&.Mui-selected': {
      color: '#505470',
      fontWeight: 500,
    },
  })
);

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`tabpanel-${index}`}
      aria-labelledby={`tab-${index}`}
      {...other}
    >
      {value === index && (
        <div>
          <Grid container mt={3} >{children}</Grid>
        </div>
      )}
    </div>
  );
}

function TabSection() {
  const [value, setValue] = useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (
    <div>
      <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
        <StyledTabs value={value} onChange={handleChange} aria-label="Tab panel">
          <StyledTab label="Summary" id="StyledTab-0" />
          <StyledTab label="Logs" id="tab-1" />
        </StyledTabs>
      </Box>

      <TabPanel value={value} index={0}>
        <SummarySection />
      </TabPanel>
      <TabPanel value={value} index={1}>
        <LogSection />
      </TabPanel>
    </div>
  );
}

export default TabSection;
