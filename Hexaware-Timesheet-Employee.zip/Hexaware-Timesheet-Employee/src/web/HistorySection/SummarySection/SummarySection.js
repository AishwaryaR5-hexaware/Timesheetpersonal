import { Grid } from '@mui/material'
import React from 'react'
import SummaryTable from './SummaryTable'
import SelectButtons from './SelectButtons'

const SummarySection = () => {
    return (
        <Grid item container xs={12} justifyContent={'flex-start'}>
            <Grid item xs={12}>
                <SelectButtons />
            </Grid>
            <Grid item xs={12} mt={2} mb={2}>
                <SummaryTable />
            </Grid>
        </Grid>
    )
}

export default SummarySection