import React from 'react'
import { styled, Grid, Avatar, Typography } from '@mui/material';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import data from './data.json';
import StatusChips from '../StatusChips';

const styles = {
    avatarGrid: {
        width: 36,
        height: 36,
    },
    userName: {
        fontSize: '16px',
        fontWeight: '600',
        color: '#1E2F98',

    },
    userId: {
        fontSize: '12px',
        fontWeight: '400',
        color: '#181D3D',
    },
    durationCell: {
        width: '45%'
    },
    statusCell: {
        width: '12%'
    },
    subDateCell: {
        width: '12%'
    },
    netHoursCell: {
        width: '10%'
    },
    subByCell: {
        width: '12%'
    }
};

const StyledTableCell = styled(TableCell)(() => ({
    [`&.${tableCellClasses.head}`]: {
        fontSize: 16,
        color: '#505470',
        paddingTop: '18px',
        paddingBottom: '18px',
    },
    [`&.${tableCellClasses.body}`]: {
        fontSize: 14,
        color: '#737897',
    },
}));


const SummaryTable = () => {
    const rows = data.time_entries
    return (
        <TableContainer component={Paper}>
            <Table sx={{ minWidth: 700 }} size='small' >
                <TableHead style={{ backgroundColor: 'rgb(224, 229, 234)', }}>
                    <TableRow>
                        <StyledTableCell style={styles.durationCell} >
                            Duration
                        </StyledTableCell>
                        <StyledTableCell align="left" style={styles.netHoursCell}>Net Hours</StyledTableCell>
                        <StyledTableCell align="left" style={styles.subByCell}>Submitted By</StyledTableCell>
                        <StyledTableCell align="left" style={styles.subDateCell}>Submitted Date</StyledTableCell>
                        <StyledTableCell align="left" style={styles.statusCell}>Status</StyledTableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {rows.map((row) => (
                        <TableRow key={row.duration}>
                            <StyledTableCell> {row.duration} </StyledTableCell>
                            <StyledTableCell align="left">{row.net_hours}</StyledTableCell>
                            <StyledTableCell align="left">
                                <Grid container direction="row" alignItems={'center'} justifyContent={'flex-start'}>
                                    <Grid item xs={3}>
                                        <Avatar
                                            src="https://res.cloudinary.com/rounak-dev/image/upload/v1682593131/Girl_gbzuoy.jpg"
                                            style={styles.avatarGrid}
                                        >
                                        </Avatar>
                                    </Grid>
                                    <Grid item container direction='column' xs={9} >
                                        <Grid item>
                                            <Typography style={styles.userName}>Me</Typography>
                                        </Grid>
                                        <Grid item>
                                            <Typography style={styles.userId}>1000075358</Typography>
                                        </Grid>
                                    </Grid>
                                </Grid>
                            </StyledTableCell>
                            <StyledTableCell align="left" >
                                {row.submitted_date}
                            </StyledTableCell>
                            <StyledTableCell align="left" >
                                <StatusChips status={row.status} />
                            </StyledTableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </TableContainer>
    )
}

export default SummaryTable