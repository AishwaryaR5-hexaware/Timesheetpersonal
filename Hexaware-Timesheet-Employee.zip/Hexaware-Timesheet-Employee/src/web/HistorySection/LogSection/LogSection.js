import { Grid } from '@mui/material'
import React from 'react'
import SelectButtons from './SelectButtons'
import LogTable from './LogTable'

const LogSection = () => {
    return (
        <Grid item container xs={12} justifyContent={'flex-start'}>
            <Grid item xs={12}>
                <SelectButtons />
            </Grid>
            <Grid item xs={12} mt={2} mb={2}><LogTable /></Grid>
        </Grid>
    )
}

export default LogSection