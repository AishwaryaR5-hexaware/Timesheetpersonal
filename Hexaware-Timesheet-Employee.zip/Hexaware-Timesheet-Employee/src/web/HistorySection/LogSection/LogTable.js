import React from 'react'
import { styled, Grid, Avatar, Typography } from '@mui/material';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell, { tableCellClasses } from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import data from './data.json';
import StatusChips from '../StatusChips';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline';
import RemoveIcon from '@mui/icons-material/Remove';

const styles = {
    avatarGrid: {
        width: 36,
        height: 36,
    },
    userName: {
        fontSize: '16px',
        fontWeight: '600',
        color: '#1E2F98',
    },
    userId: {
        fontSize: '12px',
        fontWeight: '400',
        color: '#181D3D',
    },
    dateAndTime: {
        width: '12%'
    },
    timesheetDate: {
        width: '10%'
    },
    standardHours: {
        width: '10%'
    },
    overtimeHours: {
        width: '8%'
    },
    billedHours: {
        width: '8%'
    },
    unbilledHours: {
        width: '10%'
    },
    netHours: {
        width: '8%'
    },
    billingLoss: {
        width: '8%'
    },
    wfh: {
        width: '5%'
    },
    statusCell: {
        width: '8%'
    },
    updatedBy: {
        width: '13%'
    },
    wfhIcons: {
        color: '#505470'
    }
};

const StyledTableCell = styled(TableCell)(() => ({
    [`&.${tableCellClasses.head}`]: {
        fontSize: 16,
        color: '#505470',
        paddingTop: '18px',
        paddingBottom: '18px',
    },
    [`&.${tableCellClasses.body}`]: {
        fontSize: 14,
        color: '#737897',
    },
}));

const SummaryTable = () => {
    const rows = data.time_entries
    return (
        <TableContainer component={Paper}>
            <Table sx={{ minWidth: 700 }} size='small' >
                <TableHead style={{ backgroundColor: 'rgb(224, 229, 234)', }}>
                    <TableRow style={{ verticalAlign: 'top' }}>
                        <StyledTableCell style={styles.dateAndTime} >Date & Time</StyledTableCell>
                        <StyledTableCell align="left" style={styles.timesheetDate}>Timesheet Date</StyledTableCell>
                        <StyledTableCell align="left" style={styles.standardHours}>Standard Hours</StyledTableCell>
                        <StyledTableCell align="left" style={styles.billedHours}>Billed Hours</StyledTableCell>
                        <StyledTableCell align="left" style={styles.unbilledHours}>Unbilled Hours</StyledTableCell>
                        <StyledTableCell align="left" style={styles.netHours}>Net Hours</StyledTableCell>
                        <StyledTableCell align="left" style={styles.billingLoss}>Billing Loss</StyledTableCell>
                        <StyledTableCell align="left" style={styles.wfh}>WFH</StyledTableCell>
                        <StyledTableCell align="left" style={styles.statusCell}>Status</StyledTableCell>
                        <StyledTableCell align="left" style={styles.updatedBy}>Updated By</StyledTableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {rows.map((row, index) => (
                        <TableRow key={index}>
                            <StyledTableCell> {row.dateAndTime} </StyledTableCell>
                            <StyledTableCell align="left">{row.timesheetDate}</StyledTableCell>
                            <StyledTableCell align="left">{row.standardHours}</StyledTableCell>
                            <StyledTableCell align="left">{row.billedHours}</StyledTableCell>
                            <StyledTableCell align="left">{row.unbilledHours}</StyledTableCell>
                            <StyledTableCell align="left">{row.netHours}</StyledTableCell>
                            <StyledTableCell align="left">{row.billingLoss}</StyledTableCell>
                            {row.wfh ?
                                <StyledTableCell align="left">
                                    <CheckCircleOutlineIcon style={styles.wfhIcons} />
                                </StyledTableCell>
                                :
                                <StyledTableCell align="left">
                                    <RemoveIcon style={styles.wfhIcons} />
                                </StyledTableCell>
                            }
                            <StyledTableCell align="left" >
                                <StatusChips status={row.status} />
                            </StyledTableCell>
                            <StyledTableCell align="left">
                                <Grid container direction="row" alignItems={'center'} justifyContent={'flex-start'}>
                                    <Grid item xs={4}>
                                        <Avatar
                                            src={row.updatedBy.avatar}
                                            style={styles.avatarGrid}
                                        >
                                        </Avatar>
                                    </Grid>
                                    <Grid item container direction='column' xs={8} >
                                        <Grid item>
                                            <Typography style={styles.userName}>{row.updatedBy.name}</Typography>
                                        </Grid>
                                        <Grid item>
                                            <Typography style={styles.userId}>{row.updatedBy.empId}</Typography>
                                        </Grid>
                                    </Grid>
                                </Grid>
                            </StyledTableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </TableContainer>
    )
}

export default SummaryTable