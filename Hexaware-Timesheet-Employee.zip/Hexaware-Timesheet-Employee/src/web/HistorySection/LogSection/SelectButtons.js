import { FormControl, InputLabel, MenuItem, Select, Grid, InputBase, styled } from '@mui/material'
import React, { useState } from 'react'
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';

const CustomSelectInput = styled(InputBase)(({ theme }) => ({
    'label + &': {
        marginTop: theme.spacing(2.5),
    },
    '& .MuiInputBase-input': {
        backgroundColor: "#FFFFFF",
        color: '#1E2F98',
        border: "1px solid #1E2F98",
        borderRadius: '5px',
        position: 'relative',
        fontSize: 14,
        padding: '8px 16px',
        transition: theme.transitions.create(['border-color', 'box-shadow']),
        '&:focus': {
            border: "1px solid #1E2F98",
            borderRadius: '5px',
        },
    },
    '& .MuiSelect-icon': {
        color: '#1E2F98',
    },
}));

const SelectButtons = () => {
    const styles = {
        selectLabel: {
            color: '#181D3D',
            fontSize: '14px',
            fontWeight: 400
        }
    }

    const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    const [month, setMonth] = useState('January');
    const handleMonthChange = (event) => {
        setMonth(event.target.value);
    };

    const statuses = ['All', 'Submitted', 'Not-Submitted', 'Auto-Submitted', 'Approved', 'Rejected']
    const [status, setStatus] = useState('All');
    const handleStatusChange = (event) => {
        setStatus(event.target.value);
    };

    return (
        <Grid container alignItems="flex-start" >
            <Grid item>
                <FormControl sx={{ mr: 2 }} variant="standard">
                    <InputLabel id="label-month" style={styles.selectLabel}>Month</InputLabel>
                    <Select
                        labelId="label-month"
                        id="select-month"
                        value={month}
                        onChange={handleMonthChange}
                        input={<CustomSelectInput />}
                        IconComponent={KeyboardArrowDownIcon}
                    >
                        {months.map((month, index) => (
                            <MenuItem key={index} value={month}>{month}</MenuItem>
                        ))}
                    </Select>
                </FormControl>
            </Grid>
            <Grid item>
                <FormControl variant="standard">
                    <InputLabel id="label-duration" style={styles.selectLabel}>Status</InputLabel>
                    <Select
                        labelId="label-duration"
                        id="select-duration"
                        value={status}
                        onChange={handleStatusChange}
                        input={<CustomSelectInput />}
                        IconComponent={KeyboardArrowDownIcon}
                    >
                        {statuses.map((status, index) => (
                            <MenuItem key={index} value={status}>{status}</MenuItem>
                        ))}
                    </Select>
                </FormControl>
            </Grid>
        </Grid>
    )
}

export default SelectButtons

