import React from "react"
import { Grid, Typography, Button } from "@mui/material"

const TestButton = () => {
  const styles = {
    button: {
      borderRadius: "6px",
      backgroundColor: "#1E2F98",
      fontFamily: "Poppins",
      fontSize: "20px",
      color: "#FFFFFF",
      fontWeight: "600",
      textTransform: "none",
     // width: "150px",
      // height: "30px",
      padding: "10px 20px",
    //   display: "flex",
    //   alignItems: "center",
    //   justifyContent: "center",
      // marginTop:"45px",
      // marginLeft:"30%"
    //   position: "absolute",
    },
    splashScreen: {
      width: "350px",
      height: "300px"
      //   marginLeft:"46%",
      //   marginTop:"100px",
    },
    hexLogo: {
      width: "50px",
      height: "50px"
      //   marginLeft:"42%",
      //   marginTop:"150px",
    }
  }
  const handleButtonClick = () => {
    window.open(`${process.env.REACT_APP_WEB_URL}`)
  }

  return (
    <Grid >
      <Grid container>
        <Grid item xs={12} container justifyContent='center' mt={10}>
          <img src="./timelogo.png" style={styles.hexLogo} alt="login" />
        </Grid>
        <Grid item xs={12} container justifyContent='center' mt={5}>
          <img src="/splash screen illustration.png" style={styles.splashScreen}  />
        </Grid>
      </Grid>
      <Grid item xs={12} sx={{ marginBottom: "30px", marginTop: "30px" }}>
          <Typography
            sx={{
              fontFamily: "Poppins",
              fontSize: "28px",
              color: "#312E49",
              fontWeight: "600",
              textAlign: "center",
            }}
          >
            Organise your timesheet from anywhere
          </Typography>
        </Grid>
      <Grid xs={12} container justifyContent='center'mt={5}>
        <Typography style={styles.button} 
            color="primary">
         For timesheet submission, please use Timesheet app on Teams mobile.
        </Typography>
      </Grid>
    </Grid>
  )
}

export default TestButton

//<button onClick={handleButtonClick}>Get started</button>
