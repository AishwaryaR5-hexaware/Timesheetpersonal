import { React } from "react"
import { Grid, Typography, IconButton, Divider, TextField, Avatar, styled, InputAdornment } from "@mui/material"
import { Drawer } from "@mui/material"
import CloseIcon from "@mui/icons-material/Close"
import SendIcon from '@mui/icons-material/Send';
const Comments = ({ open, onClose }) => {
  const styles = {
    comments: {
      fontFamily: "Poppins",
      fontSize: "18px",
      fontWeight: "600",
      color: "#181D3D",
      marginLeft: "16px",
      marginTop: "24px",
      position: "absolute"
    },
    today: {
      fontFamily: "Poppins",
      fontSize: "16px",
      fontWeight: "500",
      color: "#181D3D",
      marginLeft: "4.57%",
      marginRight: "80.86%",
      marginTop: "30.8%",
      position: "absolute",
      color: "#505470"
    },
    commentCard: {
      padding: "3rem",
      backgroundColor: "#ffffff",
      borderRadius: "8px",
      border: "1px solid rgba(0, 0, 0, 0.05)",
      boxShadow: "0px 4px 12px -4px rgba(0, 0, 0, 0.15)",
      width: "318px",
      height: "174px",
      marginLeft: "16px",
      marginTop: "20px"
    },
    commentCard2: {
      padding: "3rem",
      backgroundColor: "rgba(8, 42, 70, 0.1)",

      borderRadius: "8px",
      border: "1px solid rgba(0, 0, 0, 0.05)",
      boxShadow: "0px 4px 12px -4px rgba(0, 0, 0, 0.15)",
      width: "318px",
      height: "152px",
      marginLeft: "16px",
      marginTop: "20px"
    },
    commentWhole: {
      marginTop: "110px",
      flexDirection: "column"
    },
    avatarGrid: {
      position: "absolute",
      marginTop: "-7%",
      marginLeft: "-8%"
    },
    commentAvatar: {
      marginTop: "-20%",
      marginLeft: "-20%"
    },
    profileGrid: {
      fontFamily: "Poppins",
      fontStyle: "normal",
      position: "absolute",
      marginLeft: "6%",
      marginTop: "-8%"
    },
    profileGrid2: {
      fontFamily: "Poppins",
      fontStyle: "normal",
      position: "absolute",
      marginLeft: "6%",
      marginTop: "-6%"
    },
    closeButton: {
      position: "absolute",
      color: "#1E2F98",
      width: "20px",
      height: "20px",
      left: "310px",
      marginTop: "58px"
    },
    commentBar: {
      border: "1px solid rgba(30, 47, 152, 0.2)",
      boxShadow: "0px 4px 16px rgba(0, 0, 0, 0.15)",
      borderRadius: "30px",
      boxSizing: "border-box",
      marginTop: "110px",
      position: "absolute",
      width: "275px",
      height:"50px",

      marginLeft: "16px"
    },
    otherComment: {
      marginTop: "17px",
      fontSize: "12px",
      fontWeight: "400",
      color: "#181D3D",
      marginLeft: "-50px",
      marginRight: "-60px"
    },
    timeAgo: {
      marginTop: "5px",
      fontSize: "12px",
      fontWeight: "400",
      color: "#646A92",
      marginLeft: "150px",
      marginRight: "-60px"
    },
    divider: {
      height: "20px",
      width: "0.5px",
      color: "#A2A2A633",
      marginLeft: "80px",
      marginTop: "-20px"
    },
    userName: {
      fontSize: "12px",
      fontWeight: "400",
      color: "#181D3D"
    },
    jobRole: {
      fontSize: "12px",
      fontWeight: "400",
      color: "#181D3D",
      marginLeft: "90px",
      marginTop: "-29px"
    },
    circle:{
      width: "40px",
      height: "40px",
      borderRadius: "50%",
      backgroundColor: "#1E2F98",
      marginLeft:"300px",
      marginTop:"117px"
    },
    sendIcon:{
      color: "#fff"
    }
  }
  const CssTextField = styled(TextField)({
    "& input:valid + fieldset": {
      borderColor: "white",
      borderWidth: 0
    },
    "& input:valid:focus + fieldset": {
      borderWidth: 0,
      borderColor: "white"
    },
    "& .MuiOutlinedInput-root": {
      "& fieldset": {
        height: "45px"
      }
    }
  })

  return (
    <Drawer
      anchor="right"
      open={open}
      onClose={onClose}
      PaperProps={{
        sx: {
          width: "350px"
        }
      }}>
      <Typography variant="h5" style={styles.comments}>
        Comments
      </Typography>
      <Grid container>
        <IconButton aria-label="close" onClick={onClose}>
          <CloseIcon style={styles.closeButton} />
        </IconButton>
      </Grid>
      <Typography variant="subtitle1" style={styles.today}>
        Today
      </Typography>
      <Grid container style={styles.commentWhole}>
        <Grid container style={styles.commentCard}>
          <Grid item container xs={6} md={8} style={styles.profile}>
            <Grid item xs={6} style={styles.avatarGrid}>
              <Avatar src="https://res.cloudinary.com/rounak-dev/image/upload/v1679896238/MicrosoftTeams-image_29_axdv5d.jpg" style={styles.avatar} />
            </Grid>
            <Grid item xs={6} style={styles.profileGrid} alignItems={"center"}>
              <Grid item>
                <Typography variant="subtitle1" fontSize={"16px"} fontWeight={"600"} color={"#1E2F98"}>
                  Bhavya
                </Typography>
              </Grid>
              <Grid container justifyContent={"space-between"} alignItems={"center"}>
                <Grid item>
                  <Typography variant="subtitle1" style={styles.userName}>
                    1000075358{" "}
                    <Grid>
                      {" "}
                      <Divider orientation="vertical" variant="middle" style={styles.divider} />
                    </Grid>
                  </Typography>
                  <Typography variant="subtitle1" style={styles.jobRole}>
                    Manager
                  </Typography>
                </Grid>
                <Grid item>
                  <Typography variant="body1" style={styles.otherComment}>
                    Please add to the training hours. And split the total hours for both projects
                  </Typography>
                </Grid>
                <Grid item>
                  <Typography variant="body2" style={styles.timeAgo}>
                    6 mins ago
                  </Typography>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
        <Grid container style={styles.commentCard2}>
          <Grid item container xs={6} md={8} style={styles.profile}>
            <Grid item xs={6} style={styles.avatarGrid}>
              <Avatar src="https://res.cloudinary.com/rounak-dev/image/upload/v1679896238/MicrosoftTeams-image_29_axdv5d.jpg" />
            </Grid>
            <Grid item xs={6} style={styles.profileGrid2} alignItems={"center"}>
              <Grid item>
                <Typography variant="subtitle1" fontSize={"16px"} fontWeight={"600"} color={"#1E2F98"}>
                  Me
                </Typography>
              </Grid>
              <Grid item>
                <Typography variant="body1" style={styles.otherComment}>
                  Updated the timesheet. Please approve for the entire week
                </Typography>
              </Grid>
              <Grid item>
                <Typography variant="body2" style={styles.timeAgo}>
                  A min ago
                </Typography>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
      <Grid container>
        <CssTextField
          fullWidth
          placeholder="Write a comment..."
          style={styles.commentBar}
          autoFocus="autoFocus"
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <Grid item xs={6} style={styles.commentAvatar}>
                  <Avatar src="https://res.cloudinary.com/rounak-dev/image/upload/v1679896238/MicrosoftTeams-image_29_axdv5d.jpg" />
                </Grid>
              </InputAdornment>
            )
          }}
        />
        <Grid item xs={1.4} alignContent={'center'} style={styles.circle}>
          <IconButton style={styles.sendIcon}>
            <SendIcon />
          </IconButton>
        </Grid>
      </Grid>
    </Drawer>
  )
}

export default Comments
