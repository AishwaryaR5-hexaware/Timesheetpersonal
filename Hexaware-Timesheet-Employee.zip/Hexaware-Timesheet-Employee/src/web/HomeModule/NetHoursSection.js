import { Grid, Typography } from '@mui/material'
import React from 'react'

const NetHoursSection = () => {
  const styles = {
    card: {
      backgroundColor: "rgba(8, 42, 70, 0.04)",
      borderRadius: '5px',
      padding: '20px',

    },
    heading: {
      color: '#181D3D',
      fontSize: '16px',
      fontWeight: '500',
    },
    netHour: {
      color: '#181D3D',
      fontSize: '16px',
      fontWeight: '400',
    }
  }
  const netHours = [0, 8.75, 8.75, 8.75, 8.75, 8.75, 0]
  return (
    <Grid container alignItems="center" justifyContent={'flex-start'} style={styles.card}  >
      <Grid item xs={4}>
        <Typography style={styles.heading}>Net Hours</Typography>
      </Grid>
      <Grid item xs={8} >
        <Grid container direction="row" justifyContent="space-between" alignItems="center" style={{paddingRight:'94px', paddingLeft:'62px'}}  >
          {netHours.map((netHour, index) => (
            <Grid item key={index}  style={{ textAlign: "center", padding:'8px' }} >
              <Typography style={styles.netHour}>{netHour}</Typography>
            </Grid>
          ))}
        </Grid>
      </Grid>
    </Grid>
  )
}

export default NetHoursSection