import { Grid } from '@mui/material';
import React from 'react'
import ButtonSection from './ButtonSection';
import DateSection from './DateSection/DateSection';
import ProjectAllocation from './ProjectSection/ProjectAllocation';
import NetHoursSection from './NetHoursSection';
import CommentsSection from '../CommentsSection/CommentsSection';

const Home = () => {
  return (
    <Grid container   >
     <Grid item container ml={11} mr={12} mt={4}><ButtonSection /></Grid>
     <Grid item container ml={11} mr={12} mt={4}><DateSection /></Grid>
     <Grid item container ml={11} mr={12} mt={2}><ProjectAllocation /></Grid>
     <Grid item container ml={11} mr={12} mt={2}><NetHoursSection /></Grid>
     <Grid item container ml={11} mr={12} mt={2}><CommentsSection /></Grid>
    </Grid>
  )
}

export default Home
