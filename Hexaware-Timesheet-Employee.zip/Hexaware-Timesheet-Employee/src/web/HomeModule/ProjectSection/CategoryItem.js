import { Button, Grid, Typography } from '@mui/material'
import React, { useState } from 'react'
import TimePicker from './TimePicker';

const CategoryItem = (props) => {

    const styles = {

        projectName: {
            fontSize: '16px',
            fontWeight: '500',
            color: '#737897',

        },
        timeButton: {
            backgroundColor: '#FFFFFF',
            border: '1px solid #719EC1',
            borderRadius: '10px',
        },
        menuHeading: {
            color: '#5E6384',
            fontSize: '14px',
        }
    }
    const [anchorEl, setAnchorEl] = React.useState(null);

    const open = Boolean(anchorEl);

    const handleClick = (event, day) => {
      //  console.log(day)
        setAnchorEl(event.currentTarget);
        setDay(day);
    };
    const handleClose = () => {
        setAnchorEl(null);
    };

    const [day, setDay] = React.useState('Monday');

    const week = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

    const [weekTime, setWeekTime] = useState({
        Monday: { hours: 0, minutes: 0 },
        Tuesday: { hours: 0, minutes: 0 },
        Wednesday: { hours: 0, minutes: 0 },
        Thursday: { hours: 0, minutes: 0 },
        Friday: { hours: 0, minutes: 0 },
        Saturday: { hours: 0, minutes: 0 },
        Sunday: { hours: 0, minutes: 0 }
    });

    return (
        <>
            <Grid container alignItems={'center'}  >
                <Grid item xs={4} >
                    <Typography style={styles.projectName}>{props.category}</Typography>
                </Grid>
                <Grid item xs={8} >
                    <Grid container justifyContent={'space-between'} style={{paddingRight:'72px', paddingLeft:'42px'}} >
                        {week.map((day) => (
                            <Grid item key={day}>
                                <Button
                                    onClick={(e) => handleClick(e, day)}
                                    style={styles.timeButton}
                                >
                                    <span style={{ color: '#797FA2' }}>
                                        {weekTime[day].hours} : {weekTime[day].minutes}
                                    </span>
                                </Button>
                            </Grid>
                        ))}
                    </Grid>
                </Grid>
            </Grid>
            <TimePicker
                anchorEl={anchorEl}
                open={open}
                handleClose={handleClose}
                day={day}
                weekTime={weekTime}
                setWeekTime={setWeekTime}
            />
        </>

    )
}

export default CategoryItem