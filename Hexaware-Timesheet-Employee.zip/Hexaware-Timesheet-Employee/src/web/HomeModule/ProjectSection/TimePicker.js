import { Button, Grid, IconButton, Menu, TextField, Typography } from '@mui/material'
import React from 'react'
import ArrowDropUpIcon from '@mui/icons-material/ArrowDropUp';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';


const TimePicker = (props) => {
    const styles = {
        menu: {
            backgroundColor: '#FFFFFF',
            borderRadius: '22px',
            boxShadow: '0px 4px 20px rgba(0, 0, 0, 0.25)',
            marginLeft: '10px',
            padding: '20px'

        },
        menuHeading: {
            color: '#5E6384',
            fontSize: '14px',
        },
        iconButtons: {
            color: '#1E2F98',
            fontSize: '48px',
            padding: '0px'
        },
        colon: {
            color: '#717694',
            fontSize: '50px',
        },
        inputField: {
            width: 48,
            textAlign: "center"
        },
        submitButton: {
            background: '#1E2F98',
            '&:hover': {
                background: '#0c1a50'
            },

            fontSize: '16px',
            padding: '8px 30px',
            textTransform: "none"

        },
    }

    const handleHourChange = (event) => {
        let inputValue = event.target.value;

        // Check if input is NaN and set hours to 0 if true
        if (isNaN(parseInt(inputValue))) {
            props.setWeekTime((weekTime) => {
                const updatedWeekTime = { ...weekTime };
                updatedWeekTime[props.day].hours = 0;

                return { ...weekTime, updatedWeekTime }
            })
        }
        else if (inputValue >= 0 && inputValue <= 23) {
            props.setWeekTime((weekTime) => {
                const updatedWeekTime = { ...weekTime };
                updatedWeekTime[props.day].hours = parseInt(inputValue);

                return { ...weekTime, updatedWeekTime }
            })
        }

    };

    const handleHourDecrement = () => {
        const currentHours = props.weekTime[props.day].hours;
        if (currentHours > 0) {
            props.setWeekTime((weekTime) => {
                const updatedWeekTime = { ...weekTime };
                updatedWeekTime[props.day].hours = currentHours - 1;
                return { ...weekTime, updatedWeekTime };
            });
        }
    };

    const handleHourIncrement = () => {
        const currentHours = props.weekTime[props.day].hours;
        if (currentHours < 23) {
            props.setWeekTime((weekTime) => {
                const updatedWeekTime = { ...weekTime };
                updatedWeekTime[props.day].hours = currentHours + 1;
                return { ...weekTime, updatedWeekTime };
            });
        }
    };

    const handleMinuteChange = (event) => {
        let inputValue = event.target.value;

        if (isNaN(parseInt(inputValue))) {
           // console.log("NaN");

            props.setWeekTime((weekTime) => {
                const updatedWeekTime = { ...weekTime };
                updatedWeekTime[props.day].minutes = 0;
                return { ...weekTime, updatedWeekTime };
            });
        } else if (inputValue >= 0 && inputValue <= 59) {
            props.setWeekTime((weekTime) => {
                const updatedWeekTime = { ...weekTime };
                updatedWeekTime[props.day].minutes = parseInt(inputValue);
                return { ...weekTime, updatedWeekTime };
            });
        }
    };

    const handleMinuteDecrement = () => {
        const currentHours = props.weekTime[props.day].minutes;
        if (currentHours >= 1) {
            props.setWeekTime((weekTime) => {
                const updatedWeekTime = { ...weekTime };
                updatedWeekTime[props.day].minutes = parseInt(updatedWeekTime[props.day].minutes) - 1;
                return { ...weekTime, updatedWeekTime };
            });
        }
    };

    const handleMinuteIncrement = () => {
        const currentHours = props.weekTime[props.day].minutes;
        if (currentHours <59) {
            props.setWeekTime((weekTime) => {
                const updatedWeekTime = { ...weekTime };
                updatedWeekTime[props.day].minutes = parseInt(updatedWeekTime[props.day].minutes) + 1;
                return { ...weekTime, updatedWeekTime };
            });
        }
    };


    return (
        <Menu
            id="basic-menu"
            anchorEl={props.anchorEl}
            open={props.open}
            onClose={props.handleClose}
            anchorOrigin={{
                vertical: 'center',
                horizontal: 'right',
            }}
            transformOrigin={{
                vertical: 'center',
                horizontal: 'left',
            }}
            PaperProps={{ style: styles.menu }}

        >
            <Grid container direction={'column'} alignItems={'center'} >
                <Grid item>
                    <Grid container justifyContent={'space-between'} >
                        <Grid item xs={5} ><Typography style={styles.menuHeading}>Hours</Typography></Grid>
                        <Grid item m={1} ></Grid>
                        <Grid item xs={5} ><Typography style={styles.menuHeading}>Minutes</Typography></Grid>
                    </Grid>
                </Grid>
                <Grid item>
                    <Grid container alignItems={'center'}>
                        <Grid item>
                            <Grid container direction='column' alignItems={'center'}>
                                <Grid item>
                                    <IconButton onClick={handleHourIncrement} style={{ padding: '0px' }} >
                                        <ArrowDropUpIcon style={styles.iconButtons} />
                                    </IconButton>
                                </Grid>
                                <Grid item>
                                    <TextField
                                        type="text"
                                        value={props.weekTime[props.day]?.hours}
                                        onChange={handleHourChange}
                                        inputProps={{ min: 1, max: 23 }}
                                        style={styles.inputField}
                                    />
                                </Grid>
                                <Grid item>
                                    <IconButton onClick={handleHourDecrement} style={{ padding: '0px' }}>
                                        <ArrowDropDownIcon style={styles.iconButtons} />
                                    </IconButton>
                                </Grid>
                            </Grid>
                        </Grid>
                        <Grid item m={1}><Typography style={styles.colon}>:</Typography></Grid>
                        <Grid item>
                            <Grid container direction='column' alignItems={'center'}>
                                <Grid item>
                                    <IconButton onClick={handleMinuteIncrement} style={{ padding: '0px' }} >
                                        <ArrowDropUpIcon style={styles.iconButtons} />
                                    </IconButton>
                                </Grid>
                                <Grid item>
                                    <TextField
                                        type="text"
                                        value={props.weekTime[props.day]?.minutes}
                                        onChange={handleMinuteChange}
                                        inputProps={{ min: 1, max: 59 }}
                                        style={styles.inputField}
                                    />
                                </Grid>
                                <Grid item>
                                    <IconButton onClick={handleMinuteDecrement} style={{ padding: '0px' }}>
                                        <ArrowDropDownIcon style={styles.iconButtons} />
                                    </IconButton>
                                </Grid>
                            </Grid>
                        </Grid>
                    </Grid>
                </Grid>
                <Grid item>
                    <Button
                        variant="contained"
                        color="primary"
                        style={styles.submitButton}
                        onClick={props.handleClose}
                    >
                        Done
                    </Button>
                </Grid>
            </Grid>
        </Menu>
    )
}

export default TimePicker