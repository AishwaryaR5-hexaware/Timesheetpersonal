import { Grid, Typography } from '@mui/material'
import { React } from 'react'
import CategoryItem from './CategoryItem'
// import { getTaskNames } from '../../../Services/Tasks'

const ProjectAllocation = () => {

    const styles = {
        card: {
            backgroundColor: "rgba(255, 255, 255, 0.7)",
            borderRadius: '5px',
            padding: '10px',
        },
        heading: {
            fontSize: '16px',
            color: '#505470',
        },
    }
    const categories = ['ANZ_Insurance_S_R_999945', 'Nimbus_Cloud_MG_3469', 'Training', 'Holiday', 'Others', 'Leave']

    // const [projectNames, setProjectNames] = useState([]);
    // useEffect(() => {
    //     async function fetchData() {
    //       const names = await getTaskNames();
    //       setProjectNames(names);
    //     }
    //     fetchData();
    //   }, []);

    return (
        <Grid container direction='column' >
            <Grid item>
                <Typography style={styles.heading}>Project Allocation</Typography>
            </Grid>
            <Grid item mt={2} >
                <Grid container style={styles.card} alignItems={'center'} direction={'row'} justifyContent={'flex-start'} >
                    {categories.map((category, index) => (
                        <Grid item xs={12} m={1} key={index}>
                            <CategoryItem category={category}></CategoryItem>
                        </Grid>
                    ))}
                </Grid>
            </Grid>
        </Grid>
    )
}

export default ProjectAllocation