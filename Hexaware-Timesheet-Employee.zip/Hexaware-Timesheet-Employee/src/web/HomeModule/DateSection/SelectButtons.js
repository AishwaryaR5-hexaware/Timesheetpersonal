import { FormControl, InputLabel, MenuItem, Select, Grid, InputBase, styled } from '@mui/material'
import React, { useState } from 'react'
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';

function formatDate(date) {
    const day = date.getDate();
    const month = date.toLocaleString('default', { month: 'short' });
    const year = date.getFullYear().toString().slice(-2);
    const suffix = getNumberSuffix(day);
    return `${day}${suffix} ${month} ${year}`;
  }
  
  function getNumberSuffix(number) {
    const suffixes = ['th', 'st', 'nd', 'rd'];
    const remainder = number % 100;
    const suffix = suffixes[(remainder - 20) % 10] || suffixes[remainder] || suffixes[0];
    return suffix;
  }

const CustomSelectInput = styled(InputBase)(({ theme }) => ({
    'label + &': {
        marginTop: theme.spacing(2.5),
    },
    '& .MuiInputBase-input': {
        backgroundColor: "#FFFFFF",
        color: '#1E2F98',
        border: "1px solid #1E2F98",
        borderRadius: '5px',
        position: 'relative',
        fontSize: 14,
        padding: '8px 16px',
        transition: theme.transitions.create(['border-color', 'box-shadow']),
        '&:focus': {
            border: "1px solid #1E2F98",
            borderRadius: '5px',
        },
    },
    '& .MuiSelect-icon': {
        color: '#1E2F98',
    },
}));

const SelectButtons = ({weeks, currentDate, currentWeek}) => {
    const styles = {
        selectLabel: {
            color: '#181D3D',
            fontSize: '14px'
        }
    }

    const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

    const [month, setMonth] = useState('January');
    const handleMonthChange = (event) => {
        setMonth(event.target.value);
    };
    const currentWeekDate = `${formatDate(weeks[currentWeek].startDate)} to ${formatDate(weeks[currentWeek].endDate)}`;
    //console.log(currentWeekDate)

    const [duration, setDuration] = useState();
    const handleDurationChange = (event) => {
        setDuration(event.target.value);
    };

    return (
        <Grid container alignItems="flex-start" sx={{ m: 2 }}>
            <Grid item>
                <FormControl sx={{ mr: 2 }} variant="standard">
                    <InputLabel id="label-month" style={styles.selectLabel}>Month</InputLabel>
                    <Select
                        labelId="label-month"
                        id="select-month"
                        value={month}
                        onChange={handleMonthChange}
                        input={<CustomSelectInput />}
                        IconComponent={KeyboardArrowDownIcon}
                    >
                        {months.map((month, index) => (
                            <MenuItem key={index} value={month}>{month}</MenuItem>
                        ))}
                    </Select>
                </FormControl>
            </Grid>
            <Grid item>
                <FormControl variant="standard">
                    <InputLabel id="label-duration" style={styles.selectLabel}>Duration</InputLabel>
                    <Select
                        labelId="label-duration"
                        id="select-duration"
                        value={duration}
                        onChange={handleDurationChange}
                        input={<CustomSelectInput />}
                        IconComponent={KeyboardArrowDownIcon}

                    >
                        {Object.entries(weeks).map(([key, value]) => (
                            <MenuItem key={key} value={key}>{`${formatDate(value.startDate)} to ${formatDate(value.endDate)}`}</MenuItem>
                        ))}
                    </Select>
                </FormControl>
            </Grid>
        </Grid>
    )
}

export default SelectButtons

