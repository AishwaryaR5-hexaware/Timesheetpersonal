import React, { useState } from "react";
import ArrowBackIosNewIcon from '@mui/icons-material/ArrowBackIosNew';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import { Card, Grid, IconButton, ToggleButton, Typography } from "@mui/material";

const DateCard = ({ dateNumber, dayName }) => {
  const styles = {
    card: {
      backgroundColor: '#E4EAFF',
      borderRadius: '10px',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      alignItems: 'center',
      padding: '10px 10px',
      // margin:'30px 10px',
      height: '60px',
      width: '60px'

    },
    dayNumber: {
      color: '#181D3D',
      fontSize: '20px',
      fontWeight: 'bold',
    },
    dayName: {
      color: '#5E6384',
      fontSize: '12px',
    },
  }

  return (
    <Card style={styles.card}>
      <Typography style={styles.dayNumber}>
        {dateNumber}
      </Typography>
      <Typography style={styles.dayName}>
        {dayName}
      </Typography>
    </Card>
  );
};

const WeekCarousel = () => {

  const styles = {
    iconButton: {
      borderRadius: '10px',
      border: '3px solid #1E2F98',
      backgroundColor: '#FFFFFF',
      color: '#1E2F98',
      padding: '6px'
    },
    defaultTime: {
      color: '#7A7D90',
      fontSize: '12px'
    },
    toggleButtonActive:{
      backgroundColor:'#676D93',
      border: "1px solid #797FA2",
      borderRadius: '5px',
      color: '#FFFFFF',
      fontSize: '12px',
      padding: '6px 10px 3px 10px'
    },
    toggleButtonInactive:{
      backgroundColor:'#FFFFFF',
      border: "1px solid #1E2F98",
      borderRadius: '5px',
      color: '#1E2F98',
      fontSize: '12px',
      padding: '6px 10px 3px 10px'
    }

  }

  const [currentDate, setCurrentDate] = useState(new Date());
  

  const getWeekDays = (date) => {
    const weekStart = new Date(date.getFullYear(), date.getMonth(), date.getDate() - date.getDay());
    const weekEnd = new Date(date.getFullYear(), date.getMonth(), date.getDate() - date.getDay() + 6);
    const days = [];
  
    for (let i = weekStart.getDate(); i <= weekEnd.getDate(); i++) {
      const day = new Date(date.getFullYear(), date.getMonth(), i);
      days.push(day);
    }
   // console.log(date.getFullYear(), date.getMonth(), date.getDate() , date.getDay());
  
    return days;
  };
  
  const handlePrevWeek = () => {
    const newDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate() - 7);
    setCurrentDate(newDate);
  };

  const handleNextWeek = () => {
    const newDate = new Date(currentDate.getFullYear(), currentDate.getMonth(), currentDate.getDate() + 7);
    setCurrentDate(newDate);
  };

  const weekDays = getWeekDays(currentDate);

  const weekDaysArray = weekDays.map((day) => ({
    dayNumber: day.getDate(),
    dayOfWeek: day.toLocaleString("default", { weekday: "short" }).replace(".", ""),
    defaultTime: '8.75'
  }));
  

  const [wfhToggle, setWfhToggle] = useState({
    'Sun':true,
    'Mon':false,
    'Tue':false,
    'Thu':false,
    'Fri':false,
    'Sat':false
  });

  const handleWfhToggleChange = (day) => {
    setWfhToggle((prevState) => ({
      ...prevState,
      [day]: !prevState[day]
    }));
  };
  

  return (
    <Grid container direction='row' alignItems='flex-start' justifyContent='space-between' m={2} >
      <Grid item mt={3}>
        <IconButton style={styles.iconButton} onClick={handlePrevWeek}>
          <ArrowBackIosNewIcon style={{ fontSize: '18px', }} />
        </IconButton>
      </Grid>
      <Grid item xs={10}>
        <Grid container justifyContent='space-between'>
          {weekDaysArray.map((day, index) => (
            <Grid item key={index}>
              <Grid container direction='column' alignItems='center'>
                <Grid item>
                  <DateCard dateNumber={day.dayNumber} dayName={day.dayOfWeek} />
                </Grid>
                <Grid item mt={1}>
                  <Typography style={styles.defaultTime}>{day.defaultTime}</Typography>
                </Grid>
                <Grid item mt={1}>
                  <ToggleButton value="check" selected={wfhToggle[day.dayOfWeek]} 
                  style={wfhToggle[day.dayOfWeek]?styles.toggleButtonActive:styles.toggleButtonInactive}
                    onClick={() => {handleWfhToggleChange(day.dayOfWeek) }}
                  >
                    WFH
                  </ToggleButton>
                </Grid>
                
              </Grid>
            </Grid>
          ))}
        </Grid>
      </Grid>
      <Grid item mt={3}>
        <IconButton style={styles.iconButton} onClick={handleNextWeek}>
          <ArrowForwardIosIcon style={{ fontSize: '18px' }} />
        </IconButton>
      </Grid>




    </Grid>
  );
};

export default WeekCarousel;

