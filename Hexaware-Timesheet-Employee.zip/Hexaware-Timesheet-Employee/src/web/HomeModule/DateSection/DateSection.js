import { Grid } from '@mui/material'
import React from 'react'
import WeekCarousel from './WeekCarousel';
import SelectButtons from './SelectButtons';

function getLastSundayOfMonth(year, month) {
    const lastDayOfMonth = new Date(year, month + 1, 0);
    const lastSunday = lastDayOfMonth.getDate() - lastDayOfMonth.getDay();
    return new Date(year, month, lastSunday);
}

function getFirstSundayOfMonth(year, month) {
    const firstDayOfMonth = new Date(year, month, 1);
    const firstSundayDate = 7 - firstDayOfMonth.getDay() + 1;
    return new Date(year, month, firstSundayDate);
}

function getCurrentMonthWeeks() {
    const weeks = {};
    const now = new Date();
    const year = now.getFullYear();
    const month = now.getMonth();
    const firstDayOfMonth = new Date(year, month, 1);
    const lastDayOfMonth = new Date(year, month + 1, 0);
    let firstSunday = 1;

    if (firstDayOfMonth.getDay() !== 0) {
        firstSunday = 7 - firstDayOfMonth.getDay() + 1;
        const firstSunday1 = getLastSundayOfMonth(year, month - 1);
        const startDate1 = new Date(firstSunday1);
        const endDate1 = new Date(year, month, firstSunday - 1);
        weeks[`week1`] = { startDate: startDate1, endDate: endDate1 };
    }

    const lastDayOfMonthWeekday = lastDayOfMonth.getDay();
    const lastSundayOfMonth = getLastSundayOfMonth(year, month);

    let currentDate = getFirstSundayOfMonth(year, month);
    let weekNum = 2;
    while (currentDate < lastDayOfMonth) {
        const start = currentDate.getDate();
        const end = new Date(
            year,
            month,
            Math.min(start + 6, lastDayOfMonth.getDate())
        );
        const startDate = new Date(currentDate);
        const endDate = new Date(end);
        weeks[`week${weekNum}`] = { startDate, endDate };
        currentDate.setDate(currentDate.getDate() + 7);
        weekNum++;
    }

    if (lastDayOfMonthWeekday !== 6) {
        const startDate2 = new Date(lastSundayOfMonth);
        const firstSundayOfNextMonth = getFirstSundayOfMonth(year, month + 1);
        const endDate2 = new Date(year, month + 1, firstSundayOfNextMonth.getDate() - 1);
        weeks[`week${weekNum}`] = { startDate: startDate2, endDate: endDate2 };
    }

    // Get current date and week number
    const currentWeek = Object.keys(weeks).find(week => {
        const { startDate, endDate } = weeks[week];
        return now >= startDate && now <= endDate;
    });

    return { weeks, todayDate: now, todayWeek: currentWeek };
}

const DateSection = () => {
    const styles = {
        card: {
            backgroundColor: "rgba(8, 42, 70, 0.04)",
            borderRadius: '5px'
        },
    }
    let { weeks, todayDate, todayWeek } = getCurrentMonthWeeks();
    const [currentDate, setCurrentDate] = React.useState(todayDate);
    const [currentWeek, setCurrentWeek] = React.useState(todayWeek);
    return (
        <Grid container alignItems="flex-start" style={styles.card} >
            <Grid item xs={3.5}>
                <SelectButtons weeks={weeks} currentDate={currentDate} currentWeek={currentWeek} />
            </Grid>
            <Grid item xs={8} ml={2}>
                <WeekCarousel />
            </Grid>
        </Grid>
    )
}

export default DateSection

