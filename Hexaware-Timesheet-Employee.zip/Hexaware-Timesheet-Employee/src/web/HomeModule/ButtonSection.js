import { Grid, Typography, Box, Button, Divider, Chip } from '@mui/material'
import HistoryIcon from '@mui/icons-material/History';
import RefreshIcon from '@mui/icons-material/Refresh';
import React from 'react'
import { useNavigate } from 'react-router-dom';

const ButtonSection = () => {
    const navigate = useNavigate();

    const styles = {
        submitButton: {
            background: '#1E2F98',
            '&:hover': {
                background: '#0c1a50'
            },

            fontSize: '16px',
            padding: '8px 30px',
            textTransform: "none"

        },
        saveButton: {
            background: '#D9DDFA',
            '&:hover': {
                background: '#b0b5e3'
            },
            color: '#1E2F98',
            textTransform: "none",
            fontSize: '16px',

        },
        resetButton: {
            '&:hover': {
                background: '#e8e8e8'
            },
            fontSize: '16px',
            textTransform: "none",

        },
        historyButton: {
            '&:hover': {
                background: '#e8e8e8'
            },
            fontSize: '16px',
            textTransform: "none",

        },
        divider: {
            height: '30px',
            width: '0.5px',
            color:'#A2A2A633'
        },
        myTimesheet : {
            fontSize: '18px',
            fontWeight: 'bold',
            color: '#181D3D',

        },
        thisWeek : {
            fontSize: '16px',
            color: '#181D3D',
        },
        chip : {
            background: '#636A97',
            color: '#fff',
            fontSize: '12px',
            padding: '2px 8px',
            borderRadius: '14px'
        }


    };


    return (
        <Grid container alignItems="center" justifyContent="space-between">
            <Grid item xs={6}>
                <Grid container alignItems="flex-start" direction={'column'}>
                    <Grid item>
                        <Typography variant="h5" style={styles.myTimesheet}>My Timesheet</Typography>
                    </Grid>
                    <Grid item>
                        <Box >
                            <Typography variant="subtitle1" tyle={styles.thisWeek}>This Week</Typography>
                        </Box>
                    </Grid>
                    <Grid item>
                        <Box >
                        <Chip label="Not Submitted" style={styles.chip} />
                        </Box>
                    </Grid>
                </Grid>
            </Grid>

            <Grid item xs={6}>
                <Grid container alignItems="center" direction={'row-reverse'}>
                    <Grid item ml={2}>
                        <Button
                            variant="contained"
                            color="primary"
                            style={styles.submitButton}
                        >
                            Submit
                        </Button>
                    </Grid>
                    <Grid item>
                        <Box ml={2}>
                            <Button
                                variant="contained"
                                style={styles.saveButton}

                            >
                                Save Draft
                            </Button>
                        </Box>
                    </Grid>
                    <Grid item>
                        <Box ml={2}>
                            <Button
                                variant="text"
                                style={styles.resetButton}
                                startIcon={<RefreshIcon />}
                            >
                                Reset Hours
                            </Button>
                        </Box>
                    </Grid>
                    <Grid item>
                        <Divider orientation="vertical" flexItem style={styles.divider} />
                    </Grid>

                    <Grid item>
                        <Box mr={2}>
                            <Button
                                variant="text"
                                style={styles.historyButton}
                                startIcon={<HistoryIcon />}
                                onClick={() => navigate('/history')}
                            >
                                View History
                            </Button>
                        </Box>
                    </Grid>
                </Grid>
            </Grid>
        </Grid>
    )
}

export default ButtonSection

