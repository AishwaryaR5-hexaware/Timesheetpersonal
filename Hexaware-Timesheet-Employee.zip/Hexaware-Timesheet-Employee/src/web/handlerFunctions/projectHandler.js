import { getTaskNames } from "../../Services/Tasks";

export async function handleDropDown() {
  const projectList = [];
  const categoryList = [];
  const data = await getTaskNames();
 // console.log("data", data);

  for (var i = 0; i < data.projects.length; i++) {
    projectList.push(data.projects[i].ProjectName);
    categoryList.push(data.categories[i].CategoryName);
  }
//console.log('inside handle',projectList);
  return [projectList, categoryList];
}
