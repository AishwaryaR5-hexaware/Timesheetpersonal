import React, { useEffect, useState } from 'react'

const BackgroundWeb = () => {
  const url = "https://g60773a4804e254-paasatpdev1.adb.eu-frankfurt-1.oraclecloudapps.com/ords/dhr/hex_timesheet_header/header_info?emp_id=1000061108";
  const [quotes, setQuotes] = useState("");
  const getQuote = () => {
    fetch(url)
      .then((response) => response.json())
      .then((data) => console.log(data));
  };
  useEffect(() => {
    getQuote();
  }, []);
  return (
    <>
    <div style={{height:600, width:1200, color:"white", backgroundColor:"red"}}>{quotes}</div>
    </>
    
  )
}

export default BackgroundWeb