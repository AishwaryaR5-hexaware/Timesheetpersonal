import React from 'react';
import { AppBar, Toolbar, Typography, Avatar, Grid, Divider } from '@mui/material';
// import InitTeamsFx from '../sso/InitTeamsFx';

const styles = {
    title: {
        flexGrow: 1,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between'

    },
    logo: {
        width: '40px',
        marginRight: '10px',
    },
    divider: {
        height: '30px',
        margin: '0 10px',
        borderLeft: '1px solid #ccc'
    },
    userInfo: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'flex-end',
        marginRight:'73px'
    },
    avatar: {
        marginRight: '10px',
        width:'37px',
        height:'37px'
    },
    appName: {
        color: '#181D3D',
        fontWeight: 'bold',
        fontSize: '18px'
    },
    employeeName: {
        color: '#1E2F98',
        fontWeight: 'bold',
        fontSize: '16px',
        marginBottom:'-6px'

    },
    employeeId: {
        color: '#181D3D',
        fontSize: '12px'
    }
};

function AppHeader(props) {
    const { logo, appName, userInfo } = props;
    const { name, employeeId, avatarUrl } = userInfo;

    return (
        <AppBar position="static" style={{ backgroundColor: '#E9EFF4' }}>
            <Toolbar>
                <Grid container justifyContent="space-between" alignItems="center" ml={8}>
                    <Grid item xs={1.5} style={styles.title}>
                        <img src={logo} alt="Logo" style={styles.logo} />
                        <Divider orientation="vertical" flexItem />
                        <Typography variant="h6" style={styles.appName}>{appName}</Typography>
                    </Grid>
                    <Grid container item xs={6} sm={3} style={styles.userInfo} direction={"row"} >
                        <Grid item xs={2}>
                            <Avatar src={avatarUrl} alt="Avatar" style={styles.avatar} />
                        </Grid>
                        <Grid item container direction={'column'} xs={5.4} justifyContent={'flex-start'} alignItems={'flex-start'} style={{marginLeft:'-8px'}} >
                            {/* <Grid item xs={12}>
                                <Typography variant="subtitle1" style={styles.employeeName}>
                                    Welcome {name}!
                                </Typography>
                            </Grid> */}
                            {/* <InitTeamsFx/> */}
                            <Grid item xs={1}>
                                <Typography variant="subtitle1" style={styles.employeeId}>
                                    {employeeId}
                                </Typography>
                            </Grid>
                        </Grid>
                    </Grid>
                </Grid>
            </Toolbar>
        </AppBar>
    );
}

export default AppHeader;