import React from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Home from './HomeModule/Home';
import History from './HistorySection/History';
import Appbar from './Appbar';
import Logout from '../mobile/Logout/Logout';
import Login from '../mobile/Login/Login';

const RoutingModule = () => {
    const logo = 'https://res.cloudinary.com/rounak-dev/image/upload/v1681913510/Logo_bozp4o.png'
    const avatar = "https://res.cloudinary.com/rounak-dev/image/upload/v1679896238/MicrosoftTeams-image_29_axdv5d.jpg"
    const userInfo = {
        name: 'Rounak',
        employeeId: '1000061108',
        avatarUrl: avatar
    }
  return (
    
          <BrowserRouter>
            <Appbar logo={logo} appName={'Timesheet'} userInfo={userInfo} />
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/history" element={<History />} />
              <Route path="/logout" element={<Logout></Logout>}/>
              <Route path="/login" element ={<Login />} />
            </Routes>
          </BrowserRouter>
      
  )
}

export default RoutingModule