import { React } from "react"
import { Grid, Typography, IconButton, TextField, Avatar, styled, InputAdornment } from "@mui/material"
import { Drawer } from "@mui/material"
import CloseIcon from "@mui/icons-material/Close"
import SendIcon from '@mui/icons-material/Send';
import SelectButtons from "./SelectButtons";
const Comments = ({ open, toggleDrawer }) => {


  const styles = {
    heading: {
      fontSize: "18px",
      fontWeight: "600",
      color: "#181D3D",
    },
    closeButton: {
      color: "#1E2F98",
      fontSize: "32px",
    },
    today: {
      fontSize: "16px",
      fontWeight: "500",
      color: "#505470"
    },
    commentCard: {
      backgroundColor: "#ffffff",
      borderRadius: "8px",
      border: "1px solid rgba(0, 0, 0, 0.05)",
      boxShadow: "0px 4px 12px -4px rgba(0, 0, 0, 0.15)",
      padding: '20px'
    },
    avatarGrid: {
      width: 36,
      height: 36,
    },
    userName: {
      fontSize: "16px",
      fontWeight: "600",
      color: "#1E2F98"
    },
    userId: {
      fontSize: "12px",
      fontWeight: "400",
      color: "#181D3D"
    },
    comments: {
      fontSize: "14px",
      fontWeight: "400",
      color: "#181D3D"
    },
    time: {
      fontSize: "12px",
      fontWeight: "400",
      color: "#646A92",
      textAlign: "end"
    },
    selfCommentCard: {
      backgroundColor: "#E6EAED",
      borderRadius: "5px",
      padding: '20px'
    },
    sendIcon: {
      color: "#fff",
      fontSize: '18px'
    }
  }
  // const CssTextField = styled(TextField)({
  //   "& input:valid + fieldset": {
  //     borderColor: "white",
  //     borderWidth: 0
  //   },
  //   "& input:valid:focus + fieldset": {
  //     borderWidth: 0,
  //     borderColor: "white"
  //   },
  //   "& .MuiOutlinedInput-root": {
  //     "& fieldset": {
  //       height: "45px",
  //       backgroundColor: '#FFFFFF',
  //       borderRadius:'20pxc',
  //       border : '1px solid rgba(30, 47, 152, 0.2)',
  //       dropShadow : '0px 4px 16px rgba(0, 0, 0, 0.15)'
  //     }
  //   }
  // })

  const CssTextField = styled(TextField)({
    '& .MuiOutlinedInput-root': {
      '& fieldset': {
        textAlign: 'center',
        border: '1px solid rgba(30, 47, 152, 0.2)',
        boxShadow: '0px 4px 16px rgba(0, 0, 0, 0.15)',
        borderRadius: '40px',
        height: '45px',
      },
      '&:hover fieldset': {
        border: '1px solid rgba(30, 47, 152, 0.2)',
      },
      '&.Mui-focused fieldset': {
        border: '1px solid rgba(30, 47, 152, 0.2)',
      },
    },

  });

  return (
    <Drawer
      anchor="right"
      open={open}
      hideBackdrop={true}
      // onClose={()=>onClose()}
      // style={{background: 'rgba(0,0,0,0.1)'}}
      PaperProps={{
        sx: {
          width: "350px",
          padding: '16px'
        }
      }}>
      <Grid container direction={'column'} justifyContent={'space-between'} style={{height:'100%'}}>
        <Grid item>
        <Grid  container justifyContent={'space-between'} alignItems={'center'}>
          <Grid item >
            <Typography variant="h5" style={styles.heading}>
              Comments
            </Typography>
          </Grid>
          <Grid item >
            <IconButton aria-label="close" onClick={toggleDrawer} >
              <CloseIcon style={styles.closeButton} />
            </IconButton>
          </Grid>
        </Grid>
        <Grid container mt={1} >
          <SelectButtons />
        </Grid>
        <Grid container mt={2} >
          <Typography variant="subtitle1" style={styles.today}>
            Today
          </Typography>
        </Grid>
        <Grid container >
          <Grid item xs={12} style={styles.commentCard}>
            <Grid container>
              <Grid item xs={12} mt={1}>
                <Grid container direction="row" alignItems={'center'} justifyContent={'flex-start'}>
                  <Grid item xs={2}>
                    <Avatar
                      src="https://res.cloudinary.com/rounak-dev/image/upload/v1682593131/Girl_gbzuoy.jpg"
                      style={styles.avatarGrid}
                    >
                    </Avatar>
                  </Grid>
                  <Grid item container direction='column' xs={10} >
                    <Grid item>
                      <Typography style={styles.userName}>Bhavya</Typography>
                    </Grid>
                    <Grid item>
                      <Typography style={styles.userId}>1000075358 | Manager</Typography>
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
              <Grid item xs={12} mt={1}>
                <Typography style={styles.comments}>
                  Please add to the training hours. And split the total hours for both projects.
                </Typography>
              </Grid>
              <Grid item xs={12} mt={2} >
                <Typography style={styles.time}>
                  6 mins ago
                </Typography>
              </Grid>
            </Grid>
          </Grid>
          <Grid item xs={12} style={styles.selfCommentCard} mt={2}>
            <Grid container>
              <Grid item xs={12} mt={1}>
                <Grid container direction="row" alignItems={'center'} justifyContent={'flex-start'}>
                  <Grid item xs={2}>
                    <Avatar
                      src="https://res.cloudinary.com/rounak-dev/image/upload/v1682596128/MicrosoftTeams-image_31_gfqjdx.jpg"
                      style={styles.avatarGrid}
                    >
                    </Avatar>
                  </Grid>
                  <Grid item xs={10}>
                    <Typography style={styles.userName}>Me</Typography>
                  </Grid>
                </Grid>
              </Grid>
              <Grid item xs={12} mt={1}>
                <Typography style={styles.comments}>
                  Updated the timesheet. Please approve for hte entire week.
                </Typography>
              </Grid>
              <Grid item xs={12} mt={1} >
                <Typography style={styles.time}>
                  A min ago
                </Typography>
              </Grid>
            </Grid>
          </Grid>
        </Grid>

        </Grid>


        
        <Grid container alignItems={'center'} justifyContent={'space-between'} item alignSelf={'flex-end'}  >
          <Grid item xs={10}>
            <CssTextField
              fullWidth
              placeholder="Write a comment..."
              inputProps={{
                style: {
                  padding: '10px',
                  paddingLeft: '0px',
                  fontSize: '14px',
                }
              }}
              InputProps={{
                style: { paddingLeft: '5px', width: '100%' },
                startAdornment: (
                  <InputAdornment position="start" >
                    <Avatar style={{ width: 32, height: 32 }} src="https://res.cloudinary.com/rounak-dev/image/upload/v1679896238/MicrosoftTeams-image_29_axdv5d.jpg" />
                  </InputAdornment>
                )
              }}
            />
          </Grid>
          <Grid item xs={2} style={{ paddingLeft: '10px' }}>
            <IconButton style={{ backgroundColor: "#1E2F98" }}>
              <SendIcon style={styles.sendIcon} />
            </IconButton>
          </Grid>

        </Grid>
      </Grid>


    </Drawer>
  )
}

export default Comments
