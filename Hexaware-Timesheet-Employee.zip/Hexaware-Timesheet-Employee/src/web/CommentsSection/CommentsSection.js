import { Grid, IconButton, Typography } from "@mui/material"
import { React, useState } from "react"
import MessageIcon from "@mui/icons-material/Message"
import Comments from "./Comments"

const CommentsSection = () => {
  const styles = {
    card: {
      backgroundColor: "rgba(8, 42, 70, 0.04)",
      borderRadius: "5px",
      padding: "20px"
    },
    heading: {
      color: "#505470",
      fontSize: "16px",
      fontWeight: "500"
    },
    icon: {
      color: "#1E2F98",
      fontSize: "24px"
    }
  }
  const netHours = [0, 8.75, 8.75, 8.75, 8.75, 8.75, 0]
  const [isDrawerOpen, setIsDrawerOpen] = useState(false)

  const toggleDrawer = () => {
    setIsDrawerOpen(!isDrawerOpen)
  }

  return (
    <>
      <Grid container alignItems="center" justifyContent={"flex-start"} mb={2}>
        <Grid item xs={4}>
          <Typography style={styles.heading}>Comments</Typography>
        </Grid>
        <Grid item xs={8}>
          <Grid container direction="row" justifyContent="space-between" alignItems="center" style={{ paddingRight: "98px", paddingLeft: "58px" }}>
            {netHours.map((netHour, index) => (
              <Grid item key={index} style={{ textAlign: "center" }}>
                <IconButton onClick={toggleDrawer}>
                  <MessageIcon style={styles.icon}></MessageIcon>
                </IconButton >
              </Grid>
            ))}
          </Grid>
        </Grid>
      </Grid>
      <Comments open={isDrawerOpen} toggleDrawer={toggleDrawer} />
    </>
  )
}

export default CommentsSection
