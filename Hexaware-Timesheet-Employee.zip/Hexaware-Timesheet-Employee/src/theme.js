import { createTheme } from '@mui/material/styles';

const theme = createTheme({
  palette: {
    primary: {
      main: '#1E2F98'//royal-blue
    },
    secondary: {
      main: '#181D3D'//dark-blue
    },
    common: {
      black: '#000000',
      white: '#FFFFFF',
      divider: '#00DE66',
      rejectDivider:"F48116"
    },
    background: {
      default: '#E9EFF4',//light-greyblue
      projectType: '#5E6384',//dark-grey
      weekDuration: '#5A68C1',
      weekBackGrid: '#7381DB',
      monthlySum: '#FBFDFF',
      cancelBtn: '#E3E7FF',
      other: '#717694',//grey

    },
    status: {
      submitted: '#797EF6',
      rejected: '#ED7767',
      approved: '#1B7BEC',
    },
    slider:{
      background:'#F9FCFF',
      border:'#94A2FF'
    },
    
    chip: {
      submitted: '#17A7C7',
      autoSubmitted: '#6473CF',
      notSubmitted: '#F48116',
      approved: '#14B383',
      rejected: '#ED7767'
    },
    

  },
  typography: {
    fontFamily: 'Poppins',
    h1: {
      fontSize: '31px',
      fontWeight: '700',
    },
    h2: {
      fontSize: '31px',
      fontWeight: '400',
    },
    h3: {
      fontSize: '28px',
      fontWeight: '600',
    },
    h4: {
      fontSize: '20px',
      fontWeight: '600',
    },
    h5: {
      fontSize: '18px',
      fontWeight: '600',
    },
    h6: {
      fontSize: '24px !important',
      fontWeight: '600 !important', 
    },
    h7: {
      fontWeight: 500,
      fontSize: "28px",
    },
    body1: {
      fontSize: '18px',
      fontWeight: '500',
    },
    body2: {
      fontSize: '16px',
      fontWeight: '500',
    },
    body3: {
      fontSize: '16px',
      fontWeight: '400',
    },
    body4: {
      fontSize: '14px',
      fontWeight: '700',
    },
    body5: {
      fontSize: '14px',
      fontWeight: '500',
    },
    body6: {
      fontSize: '14px',
      fontWeight: '400',
    },
    body7: {
      fontSize: '13px',
      //fontWeight: '500',
    },
    body8: {
      fontSize: '12px',
      fontWeight: '500',
    },
    body9: {
      fontSize: '12px',
      fontWeight: '400',
    },
    body10: {
      fontSize: '10px',
      fontWeight: '400',
    },
    body11:{
      fontSize: "50px",
      fontWeight: "500",
    },
    // body12: {
    //   fontSize: '28px',
    //   fontWeight: '500',
    // },
    sliderLabel: {
      fontSize: '16px',
      fontWeight: '400',
    },
    colonText: {
      fontSize: '50px',
      fontWeight: '500',
    },
    dateText: {
      fontSize: '28px',
      fontWeight: '600',
    },
    submitText:{
      fontSize: '14px',
      fontWeight: '500',
      fontStyle: 'normal',
    }
  }
});


export default theme;