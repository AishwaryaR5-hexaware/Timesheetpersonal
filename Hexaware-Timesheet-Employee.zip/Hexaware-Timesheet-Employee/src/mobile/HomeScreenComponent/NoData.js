import {  Grid, Typography } from "@mui/material";
import React from "react";
import { makeStyles } from "@mui/styles";

const NoData = ({message}) => {
  const useStyles = makeStyles((theme) => ({
    paper: {
      background: theme.palette.background.default,
      mixBlendMode: "normal",
      borderRadius: "20px",
      padding: "50px",
    },
    awesome: {
      fontStyle: "normal",
      fontWeight: 600,
      fontSize: "20px",
      color: theme.palette.secondary.main
    },
    message: {
      fontStyle: "normal",
      lineHeight: "24px",
      textAlign: "center",
      color: theme.palette.secondary.main
    },
    img: {
      width: "56px",
      height: "50px",
    },
  }));


  const classes = useStyles();
  return (
      <Grid
        container
        direction="column"
        justifyContent="space-evenly"
        alignItems="center"
        spacing={2}
        sx={{marginTop:"50%"}}
      >
        <Grid item xs={12}>
          <img src="./Missed.png" alt='No data found'
          //  style={styles.img}
          className={classes.img}
           ></img>
        </Grid>
        <Grid item xs={12}>
          <Typography>Oops!</Typography>
        </Grid>
        <Grid item xs={12}>
          <Typography style={{textAlign:'center', paddingLeft:'5px', paddingRight:'5px'}}>{message}</Typography>
        </Grid>
      </Grid>
  );
};

export default NoData;
