import { Button, Drawer, Typography, Grid } from "@mui/material";
import React, { useState, useEffect } from "react";
import Dialog from "./SubmitDialog";
import { updateTask } from "../../Services/Tasks";
import { getProfileInfo } from "../../Services/Profile";
import Skeleton from "@mui/material/Skeleton";
import ConfirmDialog from "./ConfirmDialog";
import { getCurrentMonthWeeks } from "../HandlerFunctions/CurrentMonthWeek";
import { makeStyles } from "@mui/styles";
import log from "loglevel";
import appInsights from "../HandlerFunctions/appInsights";
import StatusChips from "../HandlerFunctions/StatusChips";
import BottomDrawerSkeleton from "../SkeletonComponent/BottomDrawerSkeleton";

const useStyles = makeStyles((theme) => ({
  drawer: {
    background: theme.palette.common.white,
    boxShadow: "0px -5px 112px rgba(0, 80, 138, 0.12)",
    borderRadius: "10px",
    overflowX: "hidden",
  },

  netHours: {
    color: theme.palette.secondary.main,
    fontWeight: 500,
    fontSize: "16px",
  },
  hours: {
    textAlign: "right !important",
    color: theme.palette.primary.main,
  },
  submitButton: {
    background: theme.palette.primary.main,
    boxShadow: "0px -5px 112px rgba(0, 80, 138, 0.12)",
    borderRadius: "5px",
    color: theme.palette.common.white,
    fontSize: "17px !important",
    textAlign: "center",
    fontStyle: "normal",
    fontWeight: "500",
    textTransform: "none !important",
    width: "100%",
  },
}));

export function timeToMinutes(timeStr) {
  const [hours, minutes] = timeStr.split(":").map(Number);
  const totalMinutes = hours * 60 + minutes;
  return totalMinutes;
}

const BottomDrawer = ({
  getAPI,
  loading,
  isSubmitted,
  handleNextWeekDisable,
}) => {
  
  const [isTimeGreater, setIsTimeGreater] = useState(false);
  const [open, setOpen] = React.useState(false);
  const [confirmDialogOpen, setConfirmDialogOpen] = React.useState(false);
  const [getTime, setGetTime] = useState("");
  const [responseMessage, setResponseMessage] = useState({
    status: "",
    reason: "",
  });
  const [errorOpen, setErrorOpen] = useState(false);
  useEffect(() => {
    const timeCalculation = async () => {
      let totalHours = 0;
      let totalMinutes = 0;
      let totalStandardHours = 0;
      let totalStandardMinutes = 0;
      Object.keys(getAPI).map((project, index) => {
        getAPI[project].map((p, index) => {
          var hours = parseInt(p.timesheet_task_hours);
          var minutes = parseInt(p.timesheet_task_minutes);
          var standardHours = parseInt(p.standard_hours);
          var standardMinutes = parseInt(p.standard_minutes);
          totalHours += hours;
          totalMinutes += minutes;
          totalStandardHours += standardHours;
          totalStandardMinutes += standardMinutes;
        });
      });
      const carryOverHours = Math.floor(totalMinutes / 60);
      const remainingMinutes = totalMinutes % 60;
      totalHours += carryOverHours;
      const totalTime = `${totalHours < 10 ? `0${totalHours}` : totalHours}:${
        remainingMinutes < 10 ? `0${remainingMinutes}` : remainingMinutes
      }`;

      const carryOverStandardHours = Math.floor(totalStandardMinutes / 60);
      const remainingStandardMinutes = totalStandardMinutes % 60;
      totalStandardHours += carryOverStandardHours;
      const totalStandardTime = `${totalStandardHours}:${remainingStandardMinutes}`;

      setGetTime(totalTime);

      const netMinutes = timeToMinutes(totalTime);
      const standardMinutes = timeToMinutes(totalStandardTime);
      if (netMinutes > standardMinutes) {
        setIsTimeGreater(true);
      } else {
        setIsTimeGreater(false);
      }
    };
    //*Not to be deleted - to be used in future*
    // const getWeekendDates = async () => {
    //   //NOTE: Code and date format parsing needed for handleDisable() function

    //   if (Object.keys(getAPI).length) {
    //     const weekEndDate = await Object.keys(getAPI).pop();
    //     //DAY:friday
    //     const newDateFriday = new Date(weekEndDate);
    //     newDateFriday.setDate(newDateFriday.getDate() - 1);
    //     const formattedDateFriday = newDateFriday.toISOString().slice(0, 10);
    //     //DAY:saturday
    //     const newDateSaturday = new Date(weekEndDate);
    //     const formattedDateSaturday = newDateSaturday
    //       .toISOString()
    //       .slice(0, 10);
    //     //DAY:monday
    //     const newDateMonday = new Date(weekEndDate);
    //     newDateMonday.setDate(newDateMonday.getDate() + 2);
    //     const formattedDateMonday = newDateMonday.toISOString().slice(0, 10);
    //     //DAY:sunday
    //     const newDateSunday = new Date(weekEndDate);
    //     newDateSunday.setDate(newDateSunday.getDate() + 1);
    //     const formattedDateSunday = newDateSunday.toISOString().slice(0, 10);
    //     setWeekEnds({
    //       friday: formattedDateFriday,
    //       satuday: formattedDateSaturday,
    //       sunday: formattedDateSunday,
    //       monday: formattedDateMonday,
    //     });
    //   }
    // };
    timeCalculation();
    // getWeekendDates();
  }, [getAPI]);

  const handleSubmit = async () => {
    setConfirmDialogOpen(false);
    // const name = await getProfileInformation();
    // const updatedAPIData = await compareData(getAPI, duplicateGetAPI);
    const result = [];
    for (const date in getAPI) {
      const tasks = getAPI[date];
      tasks.forEach((task) => {
        if (task.timesheet_tasks_id) {
          const taskValues = {
            employee_id: task.employee_id,
            project_id: task.project_id,
            project_name: task.project_name,
            timesheet_task_type: task.timesheet_task_type,
            timesheet_task_hours: task.timesheet_task_hours,
            timesheet_task_minutes: task.timesheet_task_minutes,
            timesheet_date: task.timesheet_date,
            is_wfh: task.is_wfh,
            hex_status: "Submitted",
            submitted_by: task.employee_id,
            submitted_by_name: "",
            approved_by: task.approved_by,
            approved_by_name: task.approved_by_name,
            source: "MOBILE",
            timesheet_tasks_id: task.timesheet_tasks_id,
            standard_hours: task.standard_hours,
            standard_minutes: task.standard_minutes,
          };
          result.push(taskValues);
        } else {
          const taskValues = {
            approved_by: "",
            approved_by_name: "",
            employee_id: task.employee_id,
            project_id: task.project_id,
            project_name: task.project_name,
            timesheet_task_type: task.timesheet_task_type,
            timesheet_task_hours: task.timesheet_task_hours,
            timesheet_task_minutes: task.timesheet_task_minutes,
            timesheet_date: task.timesheet_date,
            is_wfh: task.is_wfh,
            hex_status: "Submitted",
            submitted_by: task.employee_id,
            submitted_by_name: "",
            source: "MOBILE",
          };

          result.push(taskValues);
        }
      });
    }
    const putRequestData = await updateTask({ items: result });

    if (putRequestData.status === 200) {
      setResponseMessage({
        status: putRequestData.data.response[0].status,
        reason: putRequestData.data.response[0].reason,
      });
      setOpen(true);
      setTimeout(() => {
        window.location.reload();
      }, 3000);
    } else {
      setResponseMessage({
        status: "Warning",
        reason: "Something went wrong. Try again later",
      });
      setOpen(true);
      setTimeout(() => {
        window.location.reload();
      }, 3000);
    }
    // console.log(result)
  };

  // const appInsights = new ApplicationInsights({
  //   config: {
  //     //connectionString: process.env.REACT_APP_APPINSIGHTS_INSTRUMENTATIONKEY
  //     connectionString: 'InstrumentationKey=72a5a36c-ddb4-4c01-b611-a8cf420c8908;IngestionEndpoint=https://centralindia-0.in.applicationinsights.azure.com/;LiveEndpoint=https://centralindia.livediagnostics.monitor.azure.com/'
  //   }
  // });
  // appInsights.loadAppInsights();

  const handleDialog = () => {
    if (appInsights) {
      appInsights.trackEvent({
        name: "Submit",
        properties: { buttonName: "SubmitButton" },
      });
    }
    if (isTimeGreater) {
      setConfirmDialogOpen(true);
    } else {
      handleSubmit();
    }
  };
  const handleClose = () => {
    setOpen(false);
  };
  const handleConfirmDialog = () => {
    setConfirmDialogOpen(false);
  };

  //Not to be deleted - to be used in future
  // const handleDisable = () => {
  //   var isDisabled = false;
  //   const now = new Date();
  //   const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  //   const lastDayOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0);
  //   const nowFormatted = now.toISOString().split("T")[0];
  //   if (weekEnds.monday !== "" && weekEnds.sunday !== "") {
  //     if (nowFormatted === weekEnds.friday && now.getHours() >= 18) {
  //       isDisabled = true;
  //     } else if (nowFormatted === weekEnds.monday && now.getHours() < 9) {
  //       isDisabled = true;
  //     } else if (nowFormatted === weekEnds.monday && now.getHours() >= 9) {
  //       isDisabled = false;
  //     } else if (nowFormatted === weekEnds.friday && now.getHours() < 18) {
  //       isDisabled = false;
  //     } else if (nowFormatted === weekEnds.saturday) {
  //       isDisabled = true;
  //     } else if (nowFormatted === weekEnds.sunday) {
  //       isDisabled = true;
  //     } else if (today === lastDayOfMonth) {
  //       isDisabled = true;
  //     } else {
  //       isDisabled = false;
  //     }

  //     return isDisabled;
  //   }

  //   //isDisabled should be true from friday 6pm onwards till monday 9am and should be false rest of the week
  //   // if (now.getDay() === 5 && now.getHours() >= 18) {
  //   //   isDisabled = true;
  //   // } else if (now.getDay() === 1 && now.getHours() < 9) {
  //   //   isDisabled = true;
  //   // } else if (now.getDay() === 1 && now.getHours() >= 9) {
  //   //   isDisabled = false;
  //   // } else if (now.getDay() === 5 && now.getHours() < 18) {
  //   //   isDisabled = false;
  //   // } else if (now.getDay() === 6 || now.getDay() === 0) {
  //   //   isDisabled = true;
  //   // } else if (today === lastDayOfMonth) {
  //   //   isDisabled = true;
  //   // } else {
  //   //   isDisabled = false;
  //   // }

  //   return isDisabled;
  // };

  //Not to be deleted - to be used in future
  // const checkDaysForLeave = () => {
  //   let index = 1;
  //   const keys = Object.keys(getAPI);
  //   let len = keys.length - 2;
  //   for (let i = len; i > 0; i--) {
  //     const tasks = getAPI[keys[i]];
  //     const isLeave = tasks.some(
  //       (task) =>
  //         task.timesheet_task_type === "Leave" ||
  //         task.timesheet_task_type === "Customer Holiday"
  //     );
  //     if (isLeave) {
  //       continue;
  //     } else {
  //       index = i;
  //       break;
  //     }
  //   }
  //   const now = new Date();
  //   const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  //   var isDisabled = false;
  //   for (let j = index; j < keys.length - 1; j++) {
  //     let date = new Date(keys[j]);

  //     if (today.toLocaleDateString() === date.toLocaleDateString()) {
  //       isDisabled = true;
  //     }
  //   }
  //   //console.log(isDisabled);
  //   return isDisabled;
  // };

  const statusButton = () => {
    var status = ""; // Variable to store the status

    Object.keys(getAPI).some((project, index) => {
      return getAPI[project].some((item) => {
        if (item.hex_status?.toLowerCase() === "rejected") {
          status = "Rejected";
          return true; // Stop iterating if status is "Rejected"
        }
        if (
          item.hex_status?.toLowerCase() === "defaulted" 
        ) {
          status = "Defaulted";
          return true; // Stop iterating if status is "Auto Submitted"
        }  
        if (item.hex_status?.toLowerCase() === "submitted") {
          status = "Submitted";
          return true;
        }

        if (item.hex_status.toLowerCase() === "due for submission") {
          status = "Due For Submission";
          return true; // Stop iterating if status is "Not Submitted"
        }
        if (item.hex_status?.toLowerCase() === "approved") {
          status = "Approved";
          return true; // Stop iterating if status is "Approved"
        }
        // if (item.hex_status === null || "") {
        //   status = "Due For Submission";
        //   return true; // Stop iterating if status is "Not Submitted"
        // }
      });
    });
    //Return the status
    var obj = {};
    if (status === "Rejected") {
      obj.status = status;
      obj.color = "#ED7767";
      return obj;
    } else if (status === "Submitted") {
      obj.status = status;
      obj.color = "#17A7C7";
      return obj;
    } else if (status === "Defaulted") {
      obj.status = status;
      obj.color = "#6473CF";
      return obj;
    } else if (status === "Approved") {
      obj.status = status;
      obj.color = "#14B383";
      return obj;
    } else {
      obj.status = "Due For Submission";
      obj.color = "#F48116";
      return obj;
    }
  };
  const obj = statusButton();

  const classes = useStyles();
  return (
    <>
      <Drawer variant="permanent" anchor="bottom" className={classes.drawer}>
        {loading ? (
          // <Skeleton
          //   duration={2}
          //   animation="wave"
          //   variant="rectangular"
          //   height={"100px"}
          //   style={{ width: "100%"}}
          // />
          <BottomDrawerSkeleton></BottomDrawerSkeleton>
        ) : (
          <Grid
            container
            direction="row"
            justifyContent="center"
            alignItems="center"
          >
            <Grid
              container
              justifyContent={"center"}
              item
              xs={12}
              style={{
                backgroundColor: statusButton().color,
                height: "20px",
                padding: "0px",
              }}
            >
              <Typography style={{ color: "#fff" }} variant={"body8"}>
                {statusButton().status}
              </Typography>
            </Grid>

            <Grid
              item
              xs={12}
              style={{
                paddingTop: "6px",
                paddingRight: "25px",
                paddingLeft: "25px",
              }}
            >
              <Grid
                container
                direction="row"
                justifyContent="space-between"
                alignItems="center"
              >
                <Grid item xs={6}>
                  <Typography
                    // sx={styles.netHours}
                    variant="body2"
                    color="theme.palette.secondary.main"
                  >
                    Net Hours
                  </Typography>
                </Grid>

                <Grid item xs={6}>
                  <Typography
                    // sx={styles.hours}
                    className={classes.hours}
                    variant="h6"
                  >
                    {getTime} Hrs
                  </Typography>
                </Grid>
              </Grid>
            </Grid>

            <Grid
              item
              xs={12}
              style={{ paddingRight: "25px", paddingLeft: "25px" }}
              mt={1}
            >
              <Button
                className={classes.submitButton}
                disabled={isSubmitted() || handleNextWeekDisable()}
                variant="contained"
                // sx={styles.submitButton}
                onClick={() => {
                  handleDialog();
                }}
              >
                Submit
              </Button>
              <ConfirmDialog
                confirmDialogOpen={confirmDialogOpen}
                handleConfirmDialog={handleConfirmDialog}
                handleSubmit={handleSubmit}
              ></ConfirmDialog>
              <Dialog
                open={open}
                handleClose={handleClose}
                responseMessage={responseMessage}
              ></Dialog>
            </Grid>
            <Grid
              mt={2}
              container
              justifyContent={"center"}
              item
              xs={12}
              style={{
                backgroundColor: "#1E2F98",
                height: "20px",
                padding: "0px",
              }}
            >
              <Typography style={{ color: "#fff" }} variant={"body8"}>
                Any leave availed has to be applied in DHR
              </Typography>
            </Grid>
          </Grid>
        )}
      </Drawer>
    </>
  );
};

export default BottomDrawer;
