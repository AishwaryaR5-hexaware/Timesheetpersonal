import React from "react";
import Dialog from "@mui/material/Dialog";
import Typography from "@mui/material/Typography";
import Grid from "@mui/material/Grid";
import Paper from "@mui/material/Paper";
import { Button } from "@mui/material";
import { makeStyles } from "@mui/styles";


export function statusChange(status) {
  var png;
  if (status.toLowerCase() === "warning" ) {
      png = "./Missed.png";
  } else if (status.toLowerCase() === "success") {
      png = "./Approve.png";
  } else if (status.toLowerCase() === "rejected") {
      png = "./Reject.png";
  } else {
      png = "./Missed.png";
  }
  return png;
}


const SubmitDialog = ({ open, handleClose,responseMessage }) => {
  const useStyles = makeStyles((theme) => ({
    paper: {
      background: theme.palette.background.default,
      mixBlendMode: "normal",
      borderRadius: "20px !important",
      padding: "50px",
    },
    awesome: {
      fontStyle: "normal",
      color: theme.palette.secondary.main,
    },
    message: {
      fontStyle: "normal",
      lineHeight: "24px",
      textAlign: "center",
      color: theme.palette.secondary.main,
    },
    img: {
      width: "56px",
      height: "50px",
    },
    button: {
      textTransform: "none",
    },
  }));

  const classes = useStyles();

  return (
    <>
      <Dialog
        onClose={handleClose}
        open={open}
        // PaperProps={{
        //   style: styles.paper,
        // }}
        classes={{
          paper: classes.paper,
        }}
        PaperProps={{
          align: "center",
        }}
        
      >
        <Grid
          container
          direction="column"
          justifyContent="space-evenly"
          alignItems="center"
          spacing={2}
        >
          <Grid item xs={12}>
            <img src={statusChange(responseMessage.status)} alt="submit" 
           
            className={classes.img}
            ></img>
          </Grid>
          <Grid item xs={12}>
            <Typography 
            // sx={styles.awesome}
            className={classes.awesome}
            variant="h4"
            >{responseMessage.status}</Typography>
          </Grid>
          <Grid item xs={12}>
            <Typography 
            // sx={styles.message}
            className={classes.message}
            variant="body6"
            >
             {responseMessage.reason}
            </Typography>
          </Grid>
        </Grid>
      </Dialog>
    </>
  );
};

export default SubmitDialog;
