import React, { useState, useEffect } from "react";
import {
  Grid,
  Typography,
  Divider,
  Button,
  FormControlLabel,
  Switch,
} from "@mui/material";
import HomeScreenSkeleton from "../SkeletonComponent/HomeScreenSkeleton";
import { useNavigate } from "react-router-dom";
import { handleDropDown } from "../HandlerFunctions/handleDropDown";
import { makeStyles } from "@mui/styles";
import log from "loglevel";
// import { ApplicationInsights } from '@microsoft/applicationinsights-web';
import appInsights from "../HandlerFunctions/appInsights";
import { today, todayDate } from "../utils/util";

const ProjectList = ({
  getAPI,
  updateSetAPI,
  loading,
  isSubmitted,
  handleNextWeekDisable,
  timezone
}) => {
  const useStyles = makeStyles((theme) => ({
    dateImageContainer: {
      backgroundImage: "url('./Rectangle 63.png')",
      backgroundSize: "cover",
      backgroundPosition: "center",
      backgroundRepeat: "no-repeat",
      width: "130px !important",
      height: "90px !important",
    },

    hoursMinutes: {
      fontStyle: "normal",
      fontWeight: "500",
      fontSize: "18px !important",
      color: theme.palette.primary.main,
    },

    projectType: {
      fontStyle: "normal",
      color: theme.palette.background.projectType,
    },
    projectName: {
      fontStyle: "normal",
      color: theme.palette.secondary.main,
      overflowWrap: "break-word",
      wordWrap: "break-word",
      wordBreak: "break-word",
    },

    dateText: {
      fontStyle: "normal",
      fontWeight: 500,
      fontSize: "28px",
      textAlign: "left",
      color: theme.palette.secondary.main,
    },

    dayText: {
      fontStyle: "normal",
      textAlign: "left",
      color: theme.palette.background.projectType,
    },
    addNewButton: {
      fontStyle: "normal",
      fontWeight: 500,
      fontSize: "12px !important",
      color: theme.palette.primary.main,
      textTransform: "none !important",
      "&.MuiButtonBase-root:hover": {
        bgcolor: "transparent",
      },
    },
    wfhToggle: {
      "& .MuiTypography-root": {
        color: theme.palette.primary.main,
        fontWeight: "500",
        fontSize: "12px",
      },
    },
  }));

  const days = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

  const classes = useStyles();
  function hoursAndMinutesCalculation(project) {
    let totalHours = 0;
    let totalMinutes = 0;
    getAPI[project].map((task) => {
      var hours = parseInt(task.timesheet_task_hours);
      var minutes = parseInt(task.timesheet_task_minutes);
      totalHours += hours;
      totalMinutes += minutes;
    });
    const carryOverHours = Math.floor(totalMinutes / 60);
    const remainingMinutes = totalMinutes % 60;
    totalHours += carryOverHours;
    return { totalHours, remainingMinutes };
  }
  const calculateTotalTime = (project) => {
    const hrsMins = hoursAndMinutesCalculation(project);
    return hrsMins;
  };

  // const appInsights = new ApplicationInsights({
  //   config: {
  //     //connectionString: process.env.REACT_APP_APPINSIGHTS_INSTRUMENTATIONKEY
  //     connectionString: 'InstrumentationKey=72a5a36c-ddb4-4c01-b611-a8cf420c8908;IngestionEndpoint=https://centralindia-0.in.applicationinsights.azure.com/;LiveEndpoint=https://centralindia.livediagnostics.monitor.azure.com/'
  //   }
  // });
  // appInsights.loadAppInsights();

  //WFH toggle logic
  const handleToggleChange = (project) => {
    if (appInsights) {
      log.info("wfh toggle clicked");
      appInsights.trackEvent({
        name: "wfhSwitch",
        properties: { buttonName: "wfhButton" },
      });
    }
    if (getAPI.hasOwnProperty(project)) {
      const updatedProjects = getAPI[project].map((item) => {
        return { ...item, is_wfh: item.is_wfh === 0 ? 1 : 0 };
      });

      const updatedGetAPI = { ...getAPI, [project]: updatedProjects };
      updateSetAPI(updatedGetAPI);
    }
  };
  //THIS IS TO SET THE PRIMARY PROJECT DEATILS
  const handlePrimaryProject = (project) => {
    const primaryProjectData = {
      project_name: getAPI[project][0].project_name,
      project_id: getAPI[project][0].project_id,
      employee_id: getAPI[project][0].employee_id,
      is_wfh: getAPI[project][0].is_wfh,
      standard_hours: getAPI[project][0].standard_hours,
      standard_minutes: getAPI[project][0].standard_minutes,
    };
    // setPrimaryProjectId(primaryProjectData.project_id)
    return primaryProjectData;
  };

  const shouldDisable = (project) => {
    var decision = false;
    getAPI[project].map((item) => {
      if (item?.timesheet_task_type?.toLowerCase() === "leave/pto") {
        if (item?.half_day_leave?.toLowerCase() === "h") {
          decision = false;
          return false;
        } else {
          decision = true;
          return true;
        }
      }
    });
    if (decision === true) {
      return true;
    } else {
      return false;
    }
  };

  const isLeave = (p) => {
    // console.log("isProjectRejected", p);
    if (p.timesheet_task_type?.toLowerCase() === "leave/pto") {
      return true;
    } else {
      return false;
    }
  };

  const isProjectRejected = (p) => {
    // console.log("isProjectRejected", p);
    if (
      p.hex_status?.toLowerCase() === "rejected" ||
      // p.hex_status === null ||
      // p.hex_status === "" ||
      p.hex_status?.toLowerCase() === "due for submission"
    ) {
      return false;
    } else {
      return true;
    }
  };

  const isProjectRejectedAddAdditionalHours = (project) => {
    var decision = false;
    getAPI[project].map((item) => {
      if (item.hex_status?.toLowerCase() === "rejected") {
        const primaryProjectId = getAPI[project][0].project_id;
        if (item.project_id !== primaryProjectId) {
          decision = true;
          return true;
        }
      }
    });
    if (decision === true) {
      return true;
    } else {
      return false;
    }
  };
  // const [myArray, setMyArray] = useState([]);

  // useEffect(async () => {
  //   const year = new Date().getFullYear();
  //   const month = new Date().getMonth();
  //   const [myArray1, myArray2] = await handleDropDown(month + 1, year);
  //   setMyArray(myArray2);
  // }, []);

  // const exhaustedCategories = (project) => {
  //   var count = myArray.length;
  //   var decision = false;
  //   getAPI[project].map((item) => {
  //     let taskType = item.timesheet_task_type;
  //     if (myArray.includes(taskType)) {
  //       count--;
  //     }
  //   });
  //   if (count === 0) {
  //     decision = true;
  //   }
  //   return decision;
  // };

  const navigate = useNavigate();
  const handleNavigation = (
    totalHours,
    totalMinutes,
    flag,
    projectDetails,
    projectDate,
    primaryProject,
    getAPI,
    projectIndex,
    timezone
  ) => {
    navigate("/add", {
      state: {
        totalHours: totalHours,
        totalMinutes: totalMinutes,
        flag: flag,
        projectDetails: projectDetails,
        projectDate: projectDate,
        primaryProject: primaryProject,
        getAPI: getAPI,
        projectIndex: projectIndex,
        timezone: timezone,
      },
    });
    if (appInsights) {
      appInsights.trackEvent({
        name: "addAdditionalHours",
        properties: { buttonName: "additionalHrs" },
      });
    }
  };
  const nextOrPrevMonthCheck = (date) => {
    //NOTE : When we have next month dates in our current week
    // const now = new Date();
    // const targetDate = new Date(date);
    //return targetDate.getMonth() === now.getMonth();

    const now = today(timezone);
    const targetDate = todayDate(timezone, date);
    // console.log('now',now.month_num)
    // console.log('targetDate',targetDate.month_num)
    // console.log('result',parseInt(now.month_num)===parseInt(targetDate.month_num))
    return parseInt(now.month_num) === parseInt(targetDate.month_num);
  };

  // function removeUnderscore(str) {
  //   return str.replace(/_/g, " ");
  // }

  // const getDay = (date) => {

  //   const day = new Date(date);
  //   const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  //   return daysOfWeek[day.getDay()];
  // };

  // function getDay(inputDate) {
  //   // Parse the input date in UTC format (YYYY-MM-DD) and extract the components
  //   const [year, month, day] = inputDate.split("-");

  //   // Form the Date object using the UTC date components (months are 0-based, so we subtract 1 from the month)
  //   const dateObj = new Date(Date.UTC(year, month - 1, day));

  //   // Days in JavaScript are zero-based (0 - 6), so we need to get the day index and map it to the day name abbreviation
  //   const dayNames = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
  //   const dayIndex = dateObj.getUTCDay();
  //   const dayAbbreviation = dayNames[dayIndex];

  //   return dayAbbreviation;
  // }
  function getDay(inputDate) {
    const dateObj = todayDate(timezone, inputDate);
    return dateObj.day;
  }
  const handleTaskType = (p) => {
    if (p.timesheet_task_type.toLowerCase() === "billing") {
      return p.project_id;
    } else {
      if (p?.leave_type?.toLowerCase() === "optional holiday") {
        return p?.leave_type?.toUpperCase();
      } else {
        return p.timesheet_task_type.toUpperCase();
      }
    }
  };

  return (
    <>
      <Grid container direction="column" alignItems="center" mb={22}>
        <Grid
          container
          direction="row"
          alignItems="flex-start"
          justifyContent="space-between"
          mt={1}
        >
          {loading ? (
            <HomeScreenSkeleton></HomeScreenSkeleton>
          ) : (
            <>
              {getAPI !== undefined &&
                getAPI != null &&
                Object.keys(getAPI).map((project, getAPIIndex) => (
                  <React.Fragment key={getAPIIndex}>
                    <Grid item xs={2}>
                      <Grid
                        container
                        direction="row"
                        alignItems="center"
                        justifyContent="flex-start"
                        // sx={styles.dateImageContainer}
                        className={classes.dateImageContainer}
                      >
                        <Grid
                          item
                          xs={12}
                          sx={{ marginBottom: "-32px", marginLeft: "10px" }}
                        >
                          <Typography className={classes.dateText} variant="h7">
                            {project.slice(8, 10)}
                          </Typography>
                        </Grid>
                        <Grid item xs={12} sx={{ marginLeft: "12px" }}>
                          <Typography
                            // sx={styles.dayText}
                            className={classes.dayText}
                            variant="body6"
                          >
                            {getDay(project)}
                          </Typography>
                        </Grid>
                      </Grid>
                    </Grid>
                    <Grid item xs={10}>
                      <Grid container direction="column">
                        <Grid item>
                          <Grid
                            container
                            direction="row"
                            sx={{ paddingLeft: "10px", paddingRight: "15px" }}
                          >
                            {getAPI[project].map((p, index) => (
                              <React.Fragment key={index}>
                                <Grid item xs={12}>
                                  <Grid
                                    container
                                    direction="row"
                                    justifyContent="space-between"
                                    alignItems="center"
                                    mt={1}
                                  >
                                    <Grid item xs={9}>
                                      <Grid container direction="column" mb={1}>
                                        <Grid item container>
                                          <Grid item>
                                            <Typography
                                              // style={styles.projectType}
                                              className={classes.projectType}
                                              variant="body8"
                                            >
                                              {handleTaskType(p)}
                                            </Typography>
                                          </Grid>
                                          {p.primary_project === "Y" &&
                                          p.timesheet_task_type ===
                                            "BILLING" ? (
                                            <Grid item ml={1}>
                                              {/* <Typography
                                                // style={styles.projectType}
                                                className={classes.projectType}
                                                variant="body8"
                                              > */}
                                              <img
                                                alt="P"
                                                src={"./primary_project.png"}
                                                style={{
                                                  width: "15px",
                                                  height: "15px",
                                                }}
                                              ></img>
                                              {/* </Typography> */}
                                            </Grid>
                                          ) : (
                                            <></>
                                          )}
                                        </Grid>
                                        <Grid item>
                                          <Typography
                                            // style={styles.projectName}
                                            className={classes.projectName}
                                            variant="body5"
                                          >
                                            {/* {removeUnderscore(p.project_name)} */}
                                            {p.project_name}
                                          </Typography>
                                        </Grid>
                                      </Grid>
                                    </Grid>
                                    <Grid
                                      item
                                      container
                                      xs={3}
                                      justifyContent={"center"}
                                    >
                                      <Button
                                        disableElevation={true}
                                        // sx={styles.hoursMinutes}
                                        className={classes.hoursMinutes}
                                        onClick={() => {
                                          handleNavigation(
                                            calculateTotalTime(project)
                                              .totalHours,
                                            calculateTotalTime(project)
                                              .remainingMinutes,
                                            1,
                                            p,
                                            project,
                                            handlePrimaryProject(project),
                                            getAPI,
                                            index
                                          );
                                        }}
                                        disabled={
                                          isSubmitted() ||
                                          !nextOrPrevMonthCheck(project) ||
                                          // shouldDisable(project) ||
                                          handleNextWeekDisable() ||
                                          isProjectRejected(p) ||
                                          isLeave(p)
                                        }
                                      >
                                        <Typography
                                          style={{
                                            color:
                                              p?.leave_type?.toLowerCase() ===
                                                "optional holiday" &&
                                              p.timesheet_task_type.toLowerCase() ===
                                                "leave/pto"
                                                ? "green"
                                                : "inherit",
                                          }}
                                          variant="body2"
                                          align={"center"}
                                        >
                                          {p.timesheet_task_hours < 10
                                            ? `0${p.timesheet_task_hours}`
                                            : p.timesheet_task_hours}
                                          :
                                          {p.timesheet_task_minutes < 10
                                            ? `0${p.timesheet_task_minutes}`
                                            : p.timesheet_task_minutes}{" "}
                                        </Typography>
                                      </Button>
                                    </Grid>
                                  </Grid>
                                </Grid>
                                <Grid item xs={12}>
                                  {index !== p.length - 1 && (
                                    <Divider
                                      orientation="horizontal"
                                      flexItem
                                    />
                                  )}
                                </Grid>
                              </React.Fragment>
                            ))}
                          </Grid>
                        </Grid>
                        <Grid item>
                          <Grid
                            container
                            direction="row"
                            justifyContent="space-between"
                            alignItems="center"
                            sx={{ paddingLeft: "10px", paddingRight: "15px" }}
                          >
                            <Grid item sx={{ marginLeft: "-15px" }}>
                              <Button
                                disableElevation={true}
                                // sx={styles.addNewButton}
                                className={classes.addNewButton}
                                name="addAdditionalHours"
                                startIcon={
                                  <img
                                    src={"./add_icon.png"}
                                    alt="+"
                                    style={{ width: "20px", height: "20px" }}
                                  />
                                }
                                onClick={() => {
                                  handleNavigation(
                                    calculateTotalTime(project).totalHours,
                                    calculateTotalTime(project)
                                      .remainingMinutes,
                                    0,
                                    {},
                                    project,
                                    handlePrimaryProject(project),
                                    getAPI,
                                    getAPIIndex
                                  );
                                }}
                                disabled={
                                  isSubmitted() ||
                                  !nextOrPrevMonthCheck(project) ||
                                  handleNextWeekDisable() ||
                                  // shouldDisable(project) ||
                                  isProjectRejectedAddAdditionalHours(project)
                                  // ||
                                  // exhaustedCategories(project)
                                }
                              ></Button>
                            </Grid>

                            <Grid item sx={{ paddingRight: "10px" }}>
                              <FormControlLabel
                                control={
                                  <Switch
                                    checked={
                                      getAPI[project][0].is_wfh === 0
                                        ? false
                                        : true
                                    }
                                    onChange={() => handleToggleChange(project)}
                                    disabled={
                                      isSubmitted() ||
                                      !nextOrPrevMonthCheck(project) ||
                                      handleNextWeekDisable() ||
                                      shouldDisable(project)
                                    }
                                    name="wfhSwitch"
                                    color="primary"
                                  />
                                }
                                label="WFH"
                                labelPlacement="start"
                                // sx={styles.wfhToggle}
                                className={classes.wfhToggle}
                              />
                            </Grid>
                          </Grid>
                        </Grid>
                      </Grid>
                    </Grid>
                  </React.Fragment>
                ))}
            </>
          )}
        </Grid>
      </Grid>
    </>
  );
};

export default ProjectList;
