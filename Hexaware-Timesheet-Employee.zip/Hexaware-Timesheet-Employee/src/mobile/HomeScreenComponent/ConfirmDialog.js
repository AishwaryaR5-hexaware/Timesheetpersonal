import React from "react";
import Dialog from "@mui/material/Dialog";
import Typography from "@mui/material/Typography";
import Grid from "@mui/material/Grid";
import { Button } from "@mui/material";
import { makeStyles } from "@mui/styles";

const ConfirmDialog = ({
  confirmDialogOpen,
  handleSubmit,
  handleConfirmDialog,
}) => {
  const useStyles = makeStyles((theme) => ({
    paper: {
      background: theme.palette.background.default + '!important',
      mixBlendMode: "normal",
      borderRadius: "20px !important",
      padding: "50px"
    },
    awesome: {
      fontStyle: "normal",
      typography: theme.typography.h4,
      color: theme.palette.secondary.main
    },
    message: {
      fontStyle: "normal",
      lineHeight: "24px",
      textAlign: "center",
      color: theme.palette.secondary.main
    },
    img: {
      width: "56px",
      height: "50px"
    },
    button: {
      textTransform: "none !important"
    }
  }))


  const classes = useStyles();
  return (
    <Dialog
      onClose={handleConfirmDialog}
      open={confirmDialogOpen}
      // PaperProps={{
      //   style: styles.paper,
      // }}
      classes={{
        paper: classes.paper,
      }}
      PaperProps={{
        align: "center",
      }}
    >
      <Grid
        container
        direction="column"
        justifyContent="space-evenly"
        alignItems="center"
        spacing={2}
      >
        <Grid item xs={12}>
          <img src="./Missed.png" alt="submit"
          //  style={styles.img}
          className={classes.img}
           ></img>
        </Grid>
        <Grid item xs={12}>
          <Typography 
          // sx={styles.message}
          variant="body3"
          className={classes.message}

          >
            The net hours filled are greater than standard hours, do you want to
            continue?
          </Typography>
        </Grid>
        <Grid item container xs={12} justifyContent="space-around">
          <Grid item>
            <Button onClick={() => handleSubmit()}
            //  sx={styles.button}
            className={classes.button}
             >
              Yes, Submit
            </Button>
          </Grid>
          <Grid item>
            <Button onClick={handleConfirmDialog} 
            
            className={classes.button}
            >
              Cancel
            </Button>
          </Grid>
        </Grid>
      </Grid>
    </Dialog>
  );
};

export default ConfirmDialog;
