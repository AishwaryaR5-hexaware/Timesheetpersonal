import { DateTime } from "luxon";

export function today(timeZone) {
  const currentTimeInTimeZone = DateTime.now().setZone(timeZone);

  const dateInfo = {
    today: currentTimeInTimeZone.toFormat("yyyy-MM-dd"),
    date: currentTimeInTimeZone.toFormat("dd"),
    month_num: currentTimeInTimeZone.toFormat("MM"),
    month_str: currentTimeInTimeZone.toFormat("MMMM"),
    month_str_short: currentTimeInTimeZone.toFormat("LLL"),
    year: currentTimeInTimeZone.toFormat("yyyy"),
    day: currentTimeInTimeZone.toFormat("EEE"),
    dateObj: currentTimeInTimeZone,
  };

  return dateInfo;
}

export function todayDate(timeZone, dateString) {
  const dateObj = DateTime.fromFormat(dateString, "yyyy-MM-d", {
    zone: timeZone,
  });
  return {
    today: dateObj.toFormat("yyyy-MM-d"),
    date: dateObj.toFormat("dd"),
    month_num: dateObj.toFormat("MM"),
    month_str: dateObj.toFormat("MMMM"),
    month_str_short: dateObj.toFormat("LLL"),
    year: dateObj.toFormat("yyyy"),
    day: dateObj.toFormat("EEE"),
    dateObj: dateObj,
  };
}

export function getCurrentMonthWeek(timeZone) {
  const weeks = {};
  const response = today(timeZone);
  const month = parseInt(response.month_num);
  const year = parseInt(response.year);

  const firstDayOfMonth = DateTime.fromObject({ year, month, day: 1 });
  const lastDayOfMonth = firstDayOfMonth.plus({ months: 1 }).minus({ days: 1 });

  let firstSundayNum = 1;
  let weekNum = 1;
  if (firstDayOfMonth.weekday !== 7) {
    firstSundayNum = 7 - firstDayOfMonth.weekday + 1;
    let startDate = getLastSundayOfMonth(year, month, timeZone);
    var endDateOfFirstWeek = firstSundayNum - 1;
    let endDate = DateTime.fromObject(
      {
        year: year,
        month: month,
        day: endDateOfFirstWeek,
      },
      { zone: timeZone, keepCalenderTime: true }
    );
    weeks[`week1`] = {
      startDate: startDate.toFormat("yyyy-MM-dd"),
      endDate: endDate.toFormat("yyyy-MM-dd"),
    };
    weekNum++;
  }
  let currentDate = getFirstSundayOfMonth(year, month, timeZone);

  while (currentDate < lastDayOfMonth) {
    const startDate = currentDate;
    const endDate = currentDate.plus({ days: 6 });
    weeks[`week${weekNum}`] = {
      startDate: startDate.toFormat("yyyy-MM-dd"),
      endDate: endDate.toFormat("yyyy-MM-dd"),
    };
    weekNum++;
    currentDate = currentDate.plus({ days: 7 });
  }
  if (lastDayOfMonth.weekday === 7) {
    let startDate = lastDayOfMonth;
    let endDate = startDate.plus({ days: 6 });
    weeks[`week${weekNum}`] = {
      startDate: startDate.toFormat("yyyy-MM-dd"),
      endDate: endDate.toFormat("yyyy-MM-dd"),
    };
  }

  return weeks;
}

function getLastSundayOfMonth(year, month, timeZone) {
  // Get the last day of the month
  if (month === 0) {
    month = 12;
    year = year - 1;
  }
  // const lastDayOfMonth = DateTime.fromObject(
  //   { year: year, month: month },
  //   { zone: timeZone, keepCalenderTime: true }
  // ).endOf("month");
  const lastDayOfMonth = DateTime.fromObject(
    { year: year, month: month, day: 1 },
    { zone: timeZone, keepCalenderTime: true }
  ).minus({ days: 1 });

  // Check if the last day of the month is a Sunday (weekday: 7)
  if (lastDayOfMonth.weekday === 7) {
    return lastDayOfMonth;
  } else {
    // Get the date of the last Sunday in the previous week
    const lastSunday = lastDayOfMonth
      .minus({ days: lastDayOfMonth.weekday })
      .set({ weekday: 7 });
    return lastSunday;
  }
}

function getFirstSundayOfMonth(year, month, timeZone) {
  const firstDayOfMonth = DateTime.fromObject({ year, month, day: 1 }).setZone(
    timeZone
  );

  // Find the first Sunday of the month
  let firstSunday = firstDayOfMonth;
  while (firstSunday.weekday % 7 !== 0) {
    // Use modulo 7 to find Sunday
    firstSunday = firstSunday.plus({ days: 1 });
  }
  // console.log("first sunday", firstSunday.toFormat("dd-MM-yyyy HH:mm:ss"));
  return firstSunday;
}

export function getCurrentWeek(timeZone) {
  var weekName;
  let inputWeeks = getCurrentMonthWeek();
  let currentDate = today(timeZone);
  const currentDateTime = DateTime.fromFormat(currentDate.today, "yyyy-MM-dd");
  for (const week in inputWeeks) {
    const startDate = DateTime.fromISO(inputWeeks[week].startDate);
    const endDate = DateTime.fromISO(inputWeeks[week].endDate);
    if (currentDateTime >= startDate && currentDateTime <= endDate) {
      weekName = week;
      return week;
    }
    //return weekName;
  }
  // If the current date doesn't fall into any week, return null or an appropriate message
  return weekName;
}

export function lastDayOfMonthUpdated(timeZone) {
  const response = today(timeZone);
  const month = parseInt(response.month_num);
  const year = parseInt(response.year);
  const firstDayOfMonth = DateTime.fromObject({ year, month, day: 1 });
  const lastDayOfMonth = firstDayOfMonth.plus({ months: 1 }).minus({ days: 1 });
  return lastDayOfMonth.toFormat("yyyy-MM-dd");
}
