import React, { useEffect, useState } from "react";
import { Routes, Route, HashRouter as Router } from "react-router-dom";
import MobileHome from "../Screens/MobileHome";
import MonthlySummary from "../Screens/MonthlySummary";
import Login from "../Login/Login";
import { getCurrentMonthWeeks } from "../HandlerFunctions/CurrentMonthWeek";
import Add from "../Screens/Add";
import { getAllTasks } from "../HandlerFunctions/getAllTasks";
import { getTimeZone } from "../../Services/Tasks";
import { getCurrentWeek, getCurrentMonthWeek } from "../utils/util";

// function formatDate(date) {
//   const year = date.getFullYear();
//   const month = ("0" + (date.getMonth() + 1)).slice(-2);
//   const day = date.getDate();
//   return `${year}-${month}-${day}`;
// }

const MobileRoute = () => {
  // let { weeks, todayDate, todayWeek } = getCurrentMonthWeeks();
  // let weeks_array = getCurrentMonthWeeks();
  // console.log(weeks_array)
  // const [currentWeek, setCurrentWeek] = React.useState(todayWeek);
  const [getAPI, setGetAPI] = useState({});
  const [loading, setLoading] = useState(true);
  const [isDataEmpty, setIsDataEmpty] = useState(false);
  const [message, setMessage] = useState("");
  const [timezone, setTimezone] = useState("");
  const [weeksObj, setWeeksObj] = useState({
    weeks: {},
    currentWeek: "",
  });

  // useEffect(() => {
  //   const getCurrDate = async () => {
  //     const data = await getTimeZone();

  //     setTimezone(data.timezone);
  //     setWeeksObj({
  //       weeks: getCurrentMonthWeek(data.timezone),
  //       currentWeek: getCurrentWeek(data.timezone),
  //     });
  //     // console.log("time")
  //   };
  //   getCurrDate();
  // }, []);
  // console.log("weeksObj",weeksObj)

  useEffect(() => {
    setLoading(true);
    const getAPIFunc = async () => {
      // console.log("start",weeks[currentWeek].startDate)
      // const startDate = new Date(weeks[currentWeek].startDate);
      // const endDate = new Date(weeks[currentWeek].endDate);
      // const formatedStartDate = formatDate(startDate);
      // const formatedEndDate = formatDate(endDate);
      // console.log("get")
      if (weeksObj.weeks && weeksObj.currentWeek) {
        const startDate = weeksObj.weeks[weeksObj.currentWeek]?.startDate;
        const endDate = weeksObj.weeks[weeksObj.currentWeek]?.endDate;
        const total = await getAllTasks(startDate, endDate);

        if (total === "Empty") {
          setMessage("You have no task allocations for this week!");
          setIsDataEmpty(true);
          setLoading(false);
        } else if (total === "Error") {
          setMessage("Something went wrong. Try again later");
          setIsDataEmpty(true);
          setLoading(false);
        } else {
          setIsDataEmpty(false);
          //console.log("totalkeyValuePairs",total.keyValuePairs);
          setGetAPI(total.keyValuePairs);
          setLoading(false);
        }
      }
    };
    getAPIFunc();
  }, [weeksObj.currentWeek]);

  const updateSetAPI = (newValue) => {
    setGetAPI(newValue);
  };

  // const updateCurrentWeek = (newValue) => {
  //   setCurrentWeek(newValue);
  // };
  const environment = process.env.REACT_APP_ENVIRONMENT;
 
  return (
    <>
      <Router>
        {environment === "dev" ? (
          <Routes>
            <Route
              path="/home"
              element={
                <MobileHome
                  backgroundColor={"#E9EFF4"}
                  flag={"mainScreen"}
                  // weeks={weeks}
                  // currentWeek={currentWeek}
                  // updateCurrentWeek={updateCurrentWeek}
                  getAPI={getAPI}
                  updateSetAPI={updateSetAPI}
                  isDataEmpty={isDataEmpty}
                  loading={loading}
                  message={message}
                  weeksObj={weeksObj}
                  setWeeksObj={setWeeksObj}
                  timezone={timezone}
                />
              }
            />
            <Route
              path="/monthly-summary"
              element={
                <MonthlySummary
                  // weeks={weeks}
                  // currentWeek={currentWeek}
                  backgroundColor={"#FBFDFF"}
                  flag={"monthSummaryScreen"}
                  // updateCurrentWeek={updateCurrentWeek}
                  weeksObj={weeksObj}
                  setWeeksObj={setWeeksObj}
                  timezone={timezone}
                />
              }
            />
            <Route path="/add" element={<Add />} />
            <Route path="/" element={<Login></Login>}></Route>
          </Routes>
        ) : (
          <Routes>
            <Route
              path="/"
              element={
                <MobileHome
                  backgroundColor={"#E9EFF4"}
                  flag={"mainScreen"}
                  // weeks={weeks}
                  // currentWeek={currentWeek}
                  // updateCurrentWeek={updateCurrentWeek}
                  getAPI={getAPI}
                  updateSetAPI={updateSetAPI}
                  isDataEmpty={isDataEmpty}
                  loading={loading}
                  message={message}
                  weeksObj={weeksObj}
                  setWeeksObj={setWeeksObj}
                  timezone={timezone}
                />
              }
            />
            <Route
              path="/monthly-summary"
              element={
                <MonthlySummary
                  // weeks={weeks}
                  // currentWeek={currentWeek}
                  backgroundColor={"#FBFDFF"}
                  flag={"monthSummaryScreen"}
                  // updateCurrentWeek={updateCurrentWeek}
                  weeksObj={weeksObj}
                  setWeeksObj={setWeeksObj}
                  timezone={timezone}
                />
              }
            />
            <Route path="/add" element={<Add />} />
          </Routes>
        )}
      </Router>
    </>
  );
};

export default MobileRoute;
