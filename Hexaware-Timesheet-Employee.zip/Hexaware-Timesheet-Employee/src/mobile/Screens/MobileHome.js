import React, { useEffect } from "react";
import CssBaseline from "@mui/material/CssBaseline";
import Typography from "@mui/material/Typography";
import { Grid, Toolbar } from "@mui/material";
import BottomDrawer from "../HomeScreenComponent/BottomDrawer";
import Appbar from "../Appbar/Appbar";
import ProjectList from "../HomeScreenComponent/ProjectList";
import NoData from "../HomeScreenComponent/NoData";
import { useLocation } from "react-router-dom";
import theme from "../../theme";
import { today, todayDate } from "../utils/util";
import { lastDayOfMonthUpdated } from "../utils/util";

// function formatDate(date) {
//   const day = date.getDate();
//   const month = date.toLocaleString("default", { month: "short" });
//   const year = date.getFullYear();
//   return `${month} ${day} ${year}`;
// }
const MobileHome = ({
  backgroundColor,
  flag,
  // weeks,
  // currentWeek,
  // updateCurrentWeek,
  getAPI,
  updateSetAPI,
  isDataEmpty,
  loading,
  message,
  weeksObj,
  setWeeksObj,
  timezone
}) => {


  //a comment was added here
  const isSubmitted = () => {
    var count = 0;
    var itemCount = 0;
    // const now = new Date();
    // const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    // const lastDayOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    // var end_ = new Date(formatDate(weeks[currentWeek].endDate));
    // var lastDayOfMonth_ = new Date(formatDate(lastDayOfMonth));
    // var start_ = new Date(formatDate(weeks[currentWeek].startDate));
    if(weeksObj.weeks && weeksObj.currentWeek){
      const last_day = lastDayOfMonthUpdated(timezone);
    const end_of_week = weeksObj.weeks[weeksObj.currentWeek]?.endDate;
    const start_of_week = weeksObj.weeks[weeksObj.currentWeek]?.startDate;
    const today_date = today(timezone);
       //REVISED EXPRESSION
    if (last_day >= start_of_week && last_day <= end_of_week) {
      if (today_date.today === last_day) {
        Object.keys(getAPI).map((project, index) => {
          const nowFormatted = today_date.today;
         // console.log("project",project)
          if (project <= nowFormatted) {
            getAPI[project].map((item) => {
              if (
                item.hex_status?.toLowerCase() === "submitted" ||
                item.hex_status?.toLowerCase() === "approved" ||
                item.hex_status?.toLowerCase() === "defaulted"
              ) {
                count = count + 1;
              }
            });

            itemCount += getAPI[project].length;
          }
        });
        return itemCount === count;
      } else {
        // console.log("not last day");
        Object.keys(getAPI).map((project, index) => {
        //  console.log("project",project)
          getAPI[project].map((item) => {
            if (
              item.hex_status?.toLowerCase() === "submitted" ||
              item.hex_status?.toLowerCase() === "approved" ||
              item.hex_status?.toLowerCase() === "defaulted"
            ) {
              count = count + 1;
            }
          });
          itemCount += getAPI[project].length;
        });
        return itemCount === count;
      }
    } else {
      Object.keys(getAPI).map((project, index) => {
       // console.log("project",project)
        getAPI[project].map((item) => {
          if (
            item.hex_status?.toLowerCase() === "submitted" ||
            item.hex_status?.toLowerCase() === "approved" ||
            item.hex_status?.toLowerCase() === "defaulted"
          ) {
            count = count + 1;
          }
        });
        itemCount += getAPI[project].length;
      });
      return itemCount === count;
    }

    }
    
     //ORIGINAL EXPRESSION

    // if (lastDayOfMonth_ >= start_ && lastDayOfMonth_ <= end_) {
    //   if (today.toDateString() === lastDayOfMonth.toDateString()) {
    //     Object.keys(getAPI).map((project, index) => {
    //       const nowFormatted = now.toISOString().split("T")[0];
    //       console.log("nowf",nowFormatted)
    //       if (project <= nowFormatted) {
    //         getAPI[project].map((item) => {
    //           if (
    //             item.hex_status?.toLowerCase() === "submitted" ||
    //             item.hex_status?.toLowerCase() === "approved" ||
    //             item.hex_status?.toLowerCase() === "defaulted"
    //           ) {
    //             count = count + 1;
    //           }
    //         });

    //         itemCount += getAPI[project].length;
    //       }
    //     });
    //     return itemCount === count;
    //   } else {
    //     // console.log("not last day");
    //     Object.keys(getAPI).map((project, index) => {
    //       getAPI[project].map((item) => {
    //         if (
    //           item.hex_status?.toLowerCase() === "submitted" ||
    //           item.hex_status?.toLowerCase() === "approved" ||
    //           item.hex_status?.toLowerCase() === "defaulted"
    //         ) {
    //           count = count + 1;
    //         }
    //       });
    //       itemCount += getAPI[project].length;
    //     });
    //     return itemCount === count;
    //   }
    // } else {
    //   Object.keys(getAPI).map((project, index) => {
    //     getAPI[project].map((item) => {
    //       if (
    //         item.hex_status?.toLowerCase() === "submitted" ||
    //         item.hex_status?.toLowerCase() === "approved" ||
    //         item.hex_status?.toLowerCase() === "defaulted"
    //       ) {
    //         count = count + 1;
    //       }
    //     });
    //     itemCount += getAPI[project].length;
    //   });
    //   return itemCount === count;
    // }

  };

  const handleNextWeekDisable = () => {
    //NOTE: TO STORE FIRST ELEMENT OF GETAPI
    const firstDayKey = Object.keys(getAPI)[0];
    //console.log("getAPI",getAPI)
    const nowDate  = today(timezone);
    //console.log('firstDayKey',firstDayKey)
    const startDate = todayDate(timezone,firstDayKey);
     
    return nowDate.dateObj < startDate.dateObj
    // const now = new Date();
    // const nowFormatted = now.toISOString().split("T")[0];
    // const start = new Date(firstDayKey);
    // const startFormatted = start.toISOString().split("T")[0];
    // console.log(nowFormatted < startFormatted);
    // console.log(nowDate.today < startDate.today);
     };

  const { state } = useLocation();

  useEffect(() => {
    if (state != null) {
      const updatedData = updateTask();
      if (updatedData) {
        updateSetAPI(updatedData);
      }
    }
  }, []);

  //NOTE: Updates getAPI with data coming from Add.js
  const updateTask = () => {
    var updatedData = {};
    if (state.flag === 1 && Object.keys(getAPI).length !== 0) {
      const newData = { ...getAPI };
      const tasks = newData[state.projectDate];
      tasks[state.projectIndex].timesheet_task_hours = state.hrValueSlider;
      tasks[state.projectIndex].timesheet_task_minutes = state.minValueSlider;
      return newData;
    } else {
      if (state.projectDate && state.newTaskData && getAPI[state.projectDate]) {
        updatedData = {
          ...getAPI,
          [state.projectDate]: [
            ...getAPI[state.projectDate],
            state.newTaskData,
          ],
        };
        return updatedData;
      }
      return updatedData;
    }
  };
//console.log("timezone in mobile home",timezone)
  return (
    <>
      <CssBaseline />
      <Appbar
        backgroundColor={backgroundColor}
        // weeks={weeks}
        // currentWeek={currentWeek}
        // updateCurrentWeek={updateCurrentWeek}
        flag={flag}
        loading={loading}
        weeksObj={weeksObj}
        setWeeksObj={setWeeksObj}
        timezone={timezone}
      ></Appbar>
      <Toolbar />
      {isDataEmpty ? (
        <NoData message={message}></NoData>
      ) : (
        <Grid container direction="row" alignItems="center" mt={5}>
          <Grid item xs={12}>
            <Grid
              container
              direction="row"
              justifyContent="space-between"
              alignItems="center"
              sx={{ paddingLeft: "15px", paddingRight: "15px" }}
            >
              <Grid item xs={2}>
                <Typography
                  // sx={styles.headings}
                  variant="body8"
                  color={theme.palette.background.projectType}
                >
                  Date
                </Typography>
              </Grid>
              <Grid item xs={8}>
                <Typography
                  // sx={styles.headings}
                  variant="body8"
                  color={theme.palette.background.projectType}
                >
                  Project Allocations
                </Typography>
              </Grid>
              <Grid item xs={2}>
                <Typography
                  // sx={styles.headings}
                  variant="body8"
                  color={theme.palette.background.projectType}
                >
                  Hrs:Mins
                </Typography>
              </Grid>
            </Grid>
          </Grid>
          <Grid item xs={12}>
            <ProjectList
              getAPI={getAPI}
              updateSetAPI={updateSetAPI}
              loading={loading}
              isSubmitted={isSubmitted}
              handleNextWeekDisable={handleNextWeekDisable}
              timezone={timezone}
            ></ProjectList>
          </Grid>
          <Grid item xs={12}>
            <BottomDrawer
              loading={loading}
              getAPI={getAPI}
              isSubmitted={isSubmitted}
              handleNextWeekDisable={handleNextWeekDisable}
            ></BottomDrawer>
          </Grid>
        </Grid>
      )}
    </>
  );
};
export default MobileHome;
