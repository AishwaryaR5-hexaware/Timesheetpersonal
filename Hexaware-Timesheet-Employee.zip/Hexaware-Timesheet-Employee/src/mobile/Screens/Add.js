import React, { useState, useEffect } from "react";
import { useLocation } from "react-router-dom";
import {
  Button,
  IconButton,
  MenuItem,
  TextField,
  Typography,
  Slider,
  Grid,
  Select,
  Dialog,
} from "@mui/material";
import UnfoldMoreIcon from "@mui/icons-material/UnfoldMore";
import CloseIcon from "@mui/icons-material/Close";
import HrMinBox from "../DrawerComponent/HrMinBox";
import { useNavigate } from "react-router-dom";
import { handleDropDown } from "../HandlerFunctions/handleDropDown";
import { addComment } from "../../Services/Tasks";
import { makeStyles, styled } from "@mui/styles";
import theme from "../../theme";
import { ApplicationInsights } from "@microsoft/applicationinsights-web";
import log from "loglevel";
import SubmitDialog from "../HomeScreenComponent/SubmitDialog";
import appInsights from "../HandlerFunctions/appInsights";
import { today, todayDate } from "../utils/util";
//const timezone="Pacific/Kiritimati";
// export const formatHeadingDate = (input) => {
//   const date = new Date(input)
//   const options = { month: "short", day: "numeric" }
//   return date.toLocaleString("en-US", options)
// }

// function formatHeadingDate(inputDate) {

//   const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

//   const year = inputDate.slice(0, 4);

//   const month = months[Number(inputDate.slice(5, 7)) - 1];

//   const day = inputDate.slice(8);

//   const formattedDate = `${day} ${month}`;

//   return formattedDate;

// }
function formatHeadingDate(timezone,inputDate) {
  const response = todayDate(timezone, inputDate);
  return `${response.date} ${response.month_str_short}`;
}

const Add = () => {
  const useStyles = makeStyles((theme) => ({
    mainHeadingDate: {
      fontSize: "22px !important",
      fontWeight: "600 !important",
      color: theme.palette.secondary.main,
    },
    mainHeading: {
      fontSize: "20px !important",
      fontWeight: "500 !important",
      color: theme.palette.secondary.main,
    },
    chooseProject: {
      color: theme.palette.background.projectType,
    },
    selectItem: {
      color: theme.palette.secondary.main,
    },
    colonText: {
      fontSize: "50px",
      fontWeight: "500",
      color: theme.palette.background.other,
      padding: "0px 5px",
    },
    sliderLabel: {
      color: theme.palette.secondary.main,
    },
    slider: {
      "& .MuiSlider-thumb": {
        backgroundColor: theme.palette.slider.background,
        border: "3px solid #94A2FF",
      },
    },
    isExceededError: {
      color: "red",
    },

    cancelButton: {
      backgroundColor: theme.palette.background.cancelBtn,
      color: theme.palette.primary.main,
      textTransform: "none !important",
      fontSize: "17px",
      fontWeight: "500",
      borderRadius: "5px",
    },
    addButton: {
      textTransform: "none !important",
      fontSize: "17px",
      fontWeight: "500",
      borderRadius: "5px",
    },
    commentTextStyle: {
      color: theme.palette.secondary.main,
      borderRadius: "8px",
      fontSize: "14px !important",
      fontWeight: "500",
    },
    drawer: {
      "& .muiDrawer": {
        position: "relative",
        bottom: 0,
      },

      ".muiDrawerContent": {
        maxHeight: "100vh",
        overflowY: "scroll",
      },
    },
  }));

  const MyButton = styled(Button)({
    backgroundColor: theme.palette.background.cancelBtn + " !important",
    color: theme.palette.primary.main + " !important",
    textTransform: "none !important",
    fontSize: "17px",
    fontWeight: "500",
    borderRadius: "5px",
  });

  const classes = useStyles();
  const { state } = useLocation();
  const [isExceeded, setIsExceeded] = useState(false);
  const [isDisabled, setIsDisabled] = useState(true);
  const [selectedProjectValue, setSelectedProjectValue] =
    useState("Choose a Task Type");
  const [hrValueSlider, setHrValueSlider] = useState(0);
  const [minValueSlider, setMinValueSlider] = useState(0);
  const [projectDropDown, setProjectDropDown] = useState([
    "Choose a Task Type",
  ]);
  const [projectRequired, setProjectRequired] = useState(false);
  const [commentText, setCommentText] = useState("");
  const [primaryProject, setPrimaryProject] = useState({});
  const [message, setMessage] = useState("");
  const [isDataEmpty, setIsDataEmpty] = useState(false);
  const [open, setOpen] = useState(false);
  const [responseMessage, setResponseMessage] = useState({
    status: "",
    reason: "",
  });
  const environment = process.env.REACT_APP_ENVIRONMENT;
  useEffect(() => {
    handlePrimaryProject(state.projectDate);
  }, []);

  useEffect(() => {
    if (state.flag && Object.keys(state.projectDetails).length > 0) {
      if (state.flag === 1) {
        setHrValueSlider(parseInt(state.projectDetails.timesheet_task_hours));
        setMinValueSlider(
          parseInt(state.projectDetails.timesheet_task_minutes)
        );
      } else {
        setHrValueSlider(0);
        setMinValueSlider(0);
      }
    }
    handleDropDownChange();
  }, []);

  useEffect(() => {
    const hours = parseInt(handleNetHours().split(":")[0]);
    const minutes = parseInt(handleNetHours().split(":")[1]);
    // console.log("minutes", minutes);
    const totalMinutes = hours * 60 + minutes;
    if (totalMinutes > 24 * 60) {
      setIsExceeded(true);
    } else {
      setIsExceeded(false);
    }
  }, [hrValueSlider, minValueSlider]);

  const handleDropDownChange = async () => {
    // const year = new Date().getFullYear();
    // const month = new Date().getMonth();
    const {year,month_num}=today(state.timezone)
    // console.log("month", month);
    // console.log("year", year);
    // const dropDown = await handleDropDown(month + 1, year);
    const dropDown = await handleDropDown(month_num, year);
    if (dropDown === "Error") {
      //setMessage("Apex encountered an error!");
      setIsDataEmpty(true);
      setResponseMessage({
        status: "Warning",
        reason: "Something went wrong. Try again later",
      });
      setOpen(true);
      setTimeout(() => {
        handleClose();
      }, 2000);
    } else {
      //console.log("dropDown", dropDown);
      // const [project, category] = await handleDropDown(month + 1, year);
      var myArray1 = dropDown[0];
      var myArray2 = dropDown[1];
      if (
        state.flag === 1 &&
        state.projectDetails.timesheet_task_type === "BILLING"
      ) {
        setProjectDropDown([
          truncateText(state.projectDetails.project_name, 25),
        ]);
        setSelectedProjectValue(
          truncateText(state.projectDetails.project_name, 25)
        );
      } else if (
        state.flag === 1 &&
        state.projectDetails.timesheet_task_type !== "BILLING"
      ) {
        setProjectDropDown([state.projectDetails.timesheet_task_type]);
        setSelectedProjectValue(state.projectDetails.timesheet_task_type);
      } else {
        var tempArray = myArray2;
        for (let i = 0; i < state.getAPI[state.projectDate].length; i++) {
          let taskType = state.getAPI[state.projectDate][i].timesheet_task_type
            .toLowerCase()
            .split(" ");
          for (let i = 0; i < taskType.length; i++) {
            taskType[i] =
              taskType[i].charAt(0).toUpperCase() + taskType[i].slice(1);
          }
          taskType = taskType.join(" ");
          if (myArray2.includes(taskType)) {
            tempArray.splice(tempArray.indexOf(taskType), 1);
          }
        }
        setProjectDropDown(tempArray);
      }
    }
    //const [myArray1, myArray2] = await handleDropDown(month + 1, year);
  };

  const handleNetHours = () => {
    if (state.flag === 0) {
      let tempHrs = state.totalHours + hrValueSlider;
      let tempMins = state.totalMinutes + minValueSlider;
      if (tempMins < 0) {
        tempHrs = tempHrs - 1;
        tempMins = 60 + tempMins;
      } else if (tempMins > 59) {
        tempHrs = tempHrs + 1;
        tempMins = tempMins - 60;
      }
      return `${tempHrs}:${tempMins}`;
    } else {
      let tempHrs =
        state.totalHours +
        hrValueSlider -
        parseInt(state.projectDetails.timesheet_task_hours);
      let tempMins =
        state.totalMinutes +
        minValueSlider -
        parseInt(state.projectDetails.timesheet_task_minutes);
      if (tempMins < 0) {
        tempHrs = tempHrs - 1;
        tempMins = 60 + tempMins;
      } else if (tempMins > 59) {
        tempHrs = tempHrs + 1;
        tempMins = tempMins - 60;
      }
      return `${tempHrs}:${tempMins}`;
    }
  };

  const handlePrimaryProject = (project) => {
    var primaryProjectData = {};
    if (state.getAPI[project]) {
      primaryProjectData = {
        project_name: state.getAPI[project][0].project_name,
        project_id: state.getAPI[project][0].project_id,
        employee_id: state.getAPI[project][0].employee_id,
        is_wfh: state.getAPI[project][0].is_wfh,
        standard_hours: state.getAPI[project][0].standard_hours,
        standard_minutes: state.getAPI[project][0].standard_minutes,
      };
    }
    setPrimaryProject(primaryProjectData);
  };

  const handleComment = async () => {
    if (state.flag === 1) {
      const data = {
        proj_id: state.projectDetails.project_id,
        timesheet_tasks_id: state.projectDetails.timesheet_tasks_id,
        emp_id: state.projectDetails.employee_id,
        timesheet_date: state.projectDetails.timesheet_date,
        hex_comments: commentText,
      };
      const response = await addComment(data);

      if (response.status === 500) {
        //setMessage("Apex encountered an error!");
        setIsDataEmpty(true);
      }
    } else {
      const data = {
        proj_id: primaryProject.project_id,
        emp_id: primaryProject.employee_id,
        timesheet_date: state.projectDate,
        hex_comments: commentText,
      };
      const response = await addComment(data);

      if (response.status === 500) {
        //setMessage("Apex encountered an error!");
        setIsDataEmpty(true);
      }
    }
    setCommentText("");
    if (appInsights) {
      log.info("Comments added");
      appInsights.trackEvent({
        name: "commentsAdded",
        properties: { buttonName: "loginButton" },
      });
    }
  };

  const addNewTask = () => {
    if (isExceeded === false && selectedProjectValue !== "Choose a Task Type") {
      //NOTE: COMMENTED PART WILL BE TAKEN CARE OF, SO NO NEED TO POPULATE THEM
      const newTaskData = {
        employee_id: primaryProject.employee_id,
        hex_status: "due for submission",
        is_wfh: primaryProject.is_wfh,
        project_id: primaryProject.project_id,
        project_name: primaryProject.project_name,
        source: "MOBILE",
        standard_hours: 0,
        standard_minutes: 0,
        submitted_by: null,
        submitted_by_name: null,
        timesheet_date: state.projectDate,
        timesheet_task_hours: hrValueSlider,
        timesheet_task_minutes: minValueSlider,
        timesheet_task_type: selectedProjectValue,
      };
      if (!isDataEmpty) {
        if (state.flag === 0) {
          handleNavigation(
            state.projectDate,
            0,
            hrValueSlider,
            minValueSlider,
            state.flag,
            newTaskData
          );
        } else {
          handleNavigation(
            state.projectDate,
            state.projectIndex,
            hrValueSlider,
            minValueSlider,
            state.flag,
            newTaskData
          );
        }
      } else {
        setResponseMessage({
          status: "Warning",
          reason: "Something went wrong. Try again later",
        });
        setOpen(true);
        setTimeout(() => {
          handleClose();
        }, 2000);
      }
    }
  };

  const handleAddNewTask = () => {
    if (selectedProjectValue !== "Choose a Task Type") {
      if (commentText.trim().length !== 0) {
        handleComment();
      }

      addNewTask();
    } else {
      setProjectRequired(true);
    }
    if (appInsights) {
      appInsights.trackEvent({
        name: "Add",
        properties: { buttonName: "addHrs" },
      });
    }
  };

  const handleNavigation = (
    projectDate,
    projectIndex,
    hrValueSlider,
    minValueSlider,
    flag,
    newTaskData
  ) => {
    if (environment === "dev") {
      navigate("/home", {
        state: {
          projectDate: projectDate,
          projectIndex: projectIndex,
          hrValueSlider: hrValueSlider,
          minValueSlider: minValueSlider,
          flag: flag,
          newTaskData: newTaskData,
        },
      });
    } else {
      navigate("/", {
        state: {
          projectDate: projectDate,
          projectIndex: projectIndex,
          hrValueSlider: hrValueSlider,
          minValueSlider: minValueSlider,
          flag: flag,
          newTaskData: newTaskData,
        },
      });
    }
  };

  const navigate = useNavigate();
  const truncateText = (text, maxLength) => {
    if (text.length > maxLength) {
      return text.substring(0, maxLength) + "...";
    }
    return text;
  };

  const handleStandardHours = () => {
    if (state.flag === 1) {
      return `${state.projectDetails.standard_hours}:${state.projectDetails.standard_minutes}`;
    } else {
      return `${primaryProject.standard_hours}:${primaryProject.standard_minutes}`;
    }
  };
  const handleClose = () => {
    setOpen(false);
  };

  return (
    <>
      <Grid container style={{ backgroundColor: "#FBFDFF", height: "100vh" }}>
        <Grid
          container
          direction={"column"}
          justifyContent={"space-between"}
          style={{ padding: "15px", backgroundColor: "#FBFDFF" }}
        >
          <Grid item>
            <Grid
              container
              justifyContent={"space-between"}
              alignItems={"center"}
            >
              <Grid item>
                <Typography
                  // style={styles.mainHeadingDate}
                  className={classes.mainHeadingDate}
                >
                  Add Hrs
                </Typography>
              </Grid>
              <Grid item>
                <IconButton
                  onClick={() => {
                    environment === "dev" ? navigate("/home") : navigate("/");
                  }}
                >
                  <CloseIcon />
                </IconButton>
              </Grid>
            </Grid>
            <Grid container mb={1}>
              <Typography
                // style={styles.mainHeading}
                className={classes.mainHeading}
              >
                {formatHeadingDate(state.timezone,state.projectDate)}
              </Typography>
            </Grid>
            <Grid container>
              <Grid item xs={12}>
                <Typography
                  // sx={styles.chooseProject}
                  className={classes.chooseProject}
                  variant="body5"
                >
                  {state.flag === 1 &&
                  state.projectDetails.timesheet_task_type.toLowerCase() ===
                    "billing" ? (
                    <b>Choose Project</b>
                  ) : (
                    <b>Choose Task Type</b>
                  )}
                </Typography>
              </Grid>
              <Grid item xs={12} mt={1}>
                <Select
                  fullWidth
                  value={selectedProjectValue || "Choose a Task Type"}
                  onChange={(event) => {
                    setSelectedProjectValue(event.target.value);
                    setIsDisabled(false);
                    setProjectRequired(false);
                  }}
                  displayEmpty
                  style={{
                    borderRadius: "8px",
                  }}
                  IconComponent={UnfoldMoreIcon}
                  disabled={state.flag === 1}
                  onOpen={handleDropDownChange}
                >
                  <MenuItem value="Choose a Task Type" disabled>
                    Choose a Task Type
                  </MenuItem>
                  {Array.isArray(projectDropDown) &&
                    projectDropDown.map((name) => (
                      <MenuItem key={name} value={name}>
                        <Typography
                          // sx={styles.selectItem}
                          className={classes.selectItem}
                          variant="body5"
                        >
                          {name}
                        </Typography>
                      </MenuItem>
                    ))}
                </Select>
                {projectRequired && (
                  <p style={{ color: "red" }}>Field is required.</p>
                )}
              </Grid>
            </Grid>
            <Grid container direction={"column"} alignItems={"center"} mt={2}>
              <Grid item>
                <Typography
                  sx={{
                    fontSize: "14px",
                    fontWeight: "500",
                    color: "#5E6384",
                  }}
                >
                  Add Hours
                </Typography>
              </Grid>
              <Grid item mt={1}>
                <Grid container direction={"row"} alignItems={"center"}>
                  <Grid item>
                    <HrMinBox value={hrValueSlider} width={80}></HrMinBox>
                  </Grid>
                  <Grid item>
                    <Typography
                      // sx={styles.colonText}
                      className={classes.colonText}
                      variant="body11"
                    >
                      :
                    </Typography>
                  </Grid>
                  <Grid item>
                    <HrMinBox value={minValueSlider} width={80}></HrMinBox>
                  </Grid>
                </Grid>
              </Grid>
            </Grid>
            <Grid
              container
              direction={"row"}
              alignItems={"center"}
              style={{ padding: "20px" }}
            >
              <Grid item xs={12} mb={3}>
                <Grid
                  container
                  direction={"row"}
                  alignItems={"center"}
                  justifyContent={"space-between"}
                >
                  <Grid item xs={2}>
                    <Typography
                      // sx={styles.sliderLabel}
                      className={classes.sliderLabel}
                      variant="body2"
                    >
                      Hrs
                    </Typography>
                  </Grid>
                  <Grid item xs={9}>
                    <Slider
                      step={1}
                      marks={false}
                      min={0}
                      max={23}
                      value={hrValueSlider}
                      onChange={(event) => {
                        setHrValueSlider(event.target.value);
                        setIsDisabled(false);
                      }}
                      valueLabelDisplay="auto"
                      // sx={styles.slider}
                      className={classes.slider}
                    />
                  </Grid>
                </Grid>
              </Grid>
              <Grid item xs={12}>
                <Grid
                  container
                  direction={"row"}
                  alignItems={"center"}
                  justifyContent={"space-between"}
                >
                  <Grid item xs={2}>
                    <Typography
                      // sx={styles.sliderLabel}
                      className={classes.sliderLabel}
                      variant="body2"
                    >
                      Mins
                    </Typography>
                  </Grid>
                  <Grid item xs={9}>
                    <Slider
                      step={15}
                      marks={false}
                      min={0}
                      max={45}
                      value={minValueSlider}
                      onChange={(event) => {
                        setMinValueSlider(event.target.value);
                        setIsDisabled(false);
                      }}
                      valueLabelDisplay="auto"
                      // sx={styles.slider}
                      className={classes.slider}
                    />
                  </Grid>
                </Grid>
              </Grid>
            </Grid>
            <Grid
              container
              style={{ padding: "20px 0px" }}
              alignItems={"center"}
              justifyContent={"center"}
            >
              <Grid item xs={2} mr={3}>
                <Typography variant="body6">
                  <span
                  // style={styles.netHoursHeading}
                  >
                    Net Hrs
                  </span>{" "}
                </Typography>
                <Typography variant="body4">
                  <span>{handleNetHours()}</span>
                </Typography>
              </Grid>
              <Grid item xs={10}>
                <Typography variant="body6">
                  <span
                  // style={styles.netHoursHeading}
                  >
                    Standard Hrs
                  </span>{" "}
                </Typography>
                <Typography variant="body4">
                  <span
                    // style={styles.netHoursValue}
                    variant="body4"
                  >
                    {handleStandardHours()}
                  </span>
                </Typography>
              </Grid>
            </Grid>
            {isExceeded ? (
              <Grid container justifyContent={"center"}>
                <Typography
                  // sx={styles.isExceededError}
                  className={classes.isExceededError}
                  variant="body4"
                >
                  Net Hours exceeded by 24Hrs.
                </Typography>
              </Grid>
            ) : null}
            <Grid container>
              <Grid item xs={12}>
                <TextField
                  multiline
                  name="commentsAdded"
                  rows={4}
                  variant="outlined"
                  fullWidth
                  InputProps={{
                    // placeholder: "+ Add a comment",
                    // style: styles.commentTextStyle,
                    className: classes.commentTextStyle,
                    maxLength: 500,
                    // inputProps: {
                    //   maxLength: 500,
                    // }
                  }}
                  placeholder="+ Add a comment"
                  value={commentText}
                  onChange={(e) => {
                    setCommentText(e.target.value);
                    setIsDisabled(false);
                  }}
                />
              </Grid>
            </Grid>
          </Grid>
          <Grid item>
            <Grid container justifyContent={"space-between"} mt={4} mb={2}>
              <Grid item xs={4}>
                <MyButton
                  fullWidth
                  variant="contained"
                  onClick={() => {
                    environment === "dev" ? navigate("/home") : navigate("/");
                  }}
                  // sx={styles.cancelButton}
                  className={classes.cancelButton}
                >
                  Cancel
                </MyButton>
              </Grid>
              <Grid item xs={7}>
                <Button
                  fullWidth
                  disabled={isExceeded || isDisabled}
                  variant="contained"
                  // sx={styles.addButton}
                  className={classes.addButton}
                  onClick={() => {
                    handleAddNewTask();
                  }}
                >
                  Add
                </Button>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
      <SubmitDialog
        open={open}
        handleClose={handleClose}
        responseMessage={responseMessage}
      ></SubmitDialog>
    </>
  );
};

export default Add;
