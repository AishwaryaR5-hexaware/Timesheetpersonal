import {
  Grid,
  IconButton,
  MenuItem,
  Select,
  Skeleton,
  Typography,
} from "@mui/material";
import React, { useEffect } from "react";
import { useState } from "react";
import UnfoldMoreIcon from "@mui/icons-material/UnfoldMore";
import MonthlyCard from "../MonthlyScreenComponent/MonthlyCard";
import Appbar from "../Appbar/Appbar";
import { getSummaryDayWise } from "../../Services/Tasks";
import { handleDropDown } from "../HandlerFunctions/handleDropDown";
import MonthyScreenSkeleton from "../SkeletonComponent/MonthyScreenSkeleton";
import { getCurrentMonthWeeks } from "../HandlerFunctions/CurrentMonthWeek";
import { useNavigate } from "react-router-dom";
import theme from "../../theme";
import NoData from "../HomeScreenComponent/NoData";
import packageJson from "../../../package.json";
import PriorityHighRoundedIcon from "@mui/icons-material/PriorityHighRounded";
import NoWeekSummaryCard from "../MonthlyScreenComponent/NoWeekSummaryCard";
import NoMonthSummaryCard from "../MonthlyScreenComponent/NoMonthSummaryCard";
import { getCurrentMonthWeek, getCurrentWeek, today } from "../utils/util";

const MonthlySummary = ({
  // weeks,
  // currentWeek,
  backgroundColor,
  flag,
  // updateCurrentWeek,
  weeksObj,
  setWeeksObj,
  timezone,
}) => {
  const [selectedValue, setSelectedValue] = useState("");
  const [summaryData, setSummaryData] = useState([]);
  const [projectArray, setProjectArray] = useState([]);
  const [loading, setLoading] = useState(true);
  const [count, setCount] = useState(0);
  const [message, setMessage] = useState("");
  const navigate = useNavigate();
  const [isDataEmpty, setIsDataEmpty] = useState(false);
 

  useEffect(() => {
    const getProjects = async () => {
      const time = await timezone;

      if (time !== "") {
        const today_date = today(time);
       
        const dropDown = await handleDropDown(
          today_date.month_num,
          today_date.year
        );
       // console.log("dropDown", dropDown);
        if (dropDown === "Error") {
          setMessage("Something went wrong. Try again later");
          setIsDataEmpty(true);
        } else if (dropDown === "No Projects") {
          setMessage("No Projects found for this month!");
          setIsDataEmpty(true);
        } else if (dropDown === "No Projects") {
          setMessage("No Projects found for this month!");
          setIsDataEmpty(true);
        } else {
          var project = dropDown[0];
          var category = dropDown[1];
          setSelectedValue(project[0].ProjectId);
          setProjectArray(project);
        }
      }
    };
    getProjects();
  }, [timezone]);

  //NOTE: To get only the required weeks till date of the month
  function filterWeeksData() {
    // let { weeks, todayDate, todayWeek } = getCurrentMonthWeeks();
    if (timezone) {
      const weeks_array = getCurrentMonthWeek(timezone);
      const todayWeek = getCurrentWeek(timezone);
      const weekKeys = Object.keys(weeks_array);
      const currentIndex = weekKeys.indexOf(todayWeek);
      const filteredWeeks = {};
      for (let i = 0; i <= currentIndex; i++) {
        const key = weekKeys[i];
        filteredWeeks[key] = weeks_array[key];
      }
      return filteredWeeks;
    }
  }

  useEffect(() => {
    setLoading(true);
    const getSummary = async () => {
      const filteredData = filterWeeksData();
   
      if (selectedValue !== "" && selectedValue) {
        var statusCount = 0;
        const data = await getSummaryDayWise(filteredData, selectedValue);
        if (data.status === 500) {
          setMessage("Something went wrong. Try again later");
          setIsDataEmpty(true);
        } else {
          data.map((item) =>
            item.status.toLowerCase() === "defaulted" ? (statusCount += 1) : ""
          );
          setSummaryData(data);
          setCount(statusCount);
          setLoading(false);
        }
      }
    };
    getSummary();
  }, [selectedValue]);

  const handleGridClick = (data, index) => {
    const environment = process.env.REACT_APP_ENVIRONMENT;
    setWeeksObj((prevWeeksObj) => ({
      ...prevWeeksObj, // Keep the previous state properties unchanged
      currentWeek: "week" + (index + 1), // Update the currentWeek with the new value
    }));
    // updateCurrentWeek("week" + (index + 1));
    if (environment === "dev") {
      navigate("/home");
    } else {
      navigate("/");
    }
  };
  const truncateText = (text, maxLength) => {
    if (text.length > maxLength) {
      return text.substring(0, maxLength) + "...";
    }
    return text;
  };

  const checkIfNoSummary = () => {
    let count = 0;
    summaryData.map((item, index) => {
      if (
        item.status !== "" &&
        item.total_billable_hours !== "" &&
        item.total_billable_minutes !== "" &&
        item.total_billing_loss_hours !== "" &&
        item.total_billing_loss_minutes !== "" &&
        item.total_filled_hours !== "" &&
        item.total_filled_minutes !== ""
      ) {
        count = count;
      } else {
        count++;
      }
    });
    if (summaryData.length === count) {
      return false;
    } else {
      return true;
    }
  };

  return (
    <>
      <Grid
        container
        sx={{
          height: "100vh",
          background: theme.palette.background.monthlySum,
        }}
      >
        <Appbar
          // weeks={weeks}
          // currentWeek={currentWeek}
          backgroundColor={backgroundColor}
          flag={flag}
          weeksObj={weeksObj}
          setWeeksObj={setWeeksObj}
          timezone={timezone}
        ></Appbar>
        {isDataEmpty ? (
          <Grid container justifyContent="center">
            <Grid item xs={12}>
              <NoData message={message}></NoData>
            </Grid>
          </Grid>
        ) : (
          <Grid
            container
            direction="row"
            alignItems="flex-start"
            mt={9}
            sx={{
              padding: "25px",
              background: theme.palette.background.monthlySum,
            }}
          >
            <Grid item xs={12}>
              <Grid
                container
                direction="column"
                justifyContent="space-between"
                alignItems="flex-start"
              >
                <Grid item>
                  <Typography
                    // sx={{
                    //   fontFamily: "Poppins",
                    //   fontSize: "31px",
                    //   fontWeight: "700",
                    // }}
                    variant="h1"
                  >
                    Your timesheet
                  </Typography>
                </Grid>
                <Grid item>
                  <Typography
                    // sx={{
                    //   fontFamily: "Poppins",
                    //   fontSize: "31px",
                    //   fontWeight: "400",
                    // }}
                    variant="h2"
                  >
                    for this month
                  </Typography>
                </Grid>
              </Grid>
            </Grid>
            <Grid item xs={12}>
              <Grid
                container
                direction="row"
                justifyContent="center"
                alignItems="center"
              >
                <Grid item xs={12}>
                  <Typography
                    // sx={{
                    //   fontSize: "14px",
                    //   fontWeight: "500",
                    //   color: "#5E6384",
                    // }}
                    variant="body5"
                    color={theme.palette.background.projectType}
                  >
                    Choose projects
                  </Typography>
                </Grid>
                <Grid item xs={12}>
                  <Select
                    value={selectedValue}
                    onChange={(event) => setSelectedValue(event.target.value)}
                    displayEmpty
                    style={{
                      width: "100%",
                      borderRadius: "8px",
                    }}
                    IconComponent={UnfoldMoreIcon}
                  >
                    <MenuItem value="" disabled>
                      Choose a Project
                    </MenuItem>
                    {projectArray !== undefined &&
                      projectArray.map((name) => (
                        <MenuItem key={name.ProjectName} value={name.ProjectId}>
                          <Typography
                            // sx={{
                            //   fontFamily: "Poppins",
                            //   fontSize: "14px",
                            //   fontWeight: "500",
                            //   color: "#181D3D",
                            // }}
                            variant="body5"
                            color={theme.palette.secondary.main}
                          >
                            {truncateText(name.ProjectName, 35)}
                          </Typography>
                        </MenuItem>
                      ))}
                  </Select>
                </Grid>
              </Grid>
            </Grid>
            <Grid item xs={12}>
              <div style={{ overflow: "auto" }}>
                <Grid
                  container
                  spacing={2}
                  sx={{
                    flexWrap: "nowrap",
                  }}
                >
                  {loading ? (
                    <>
                      {Array(5)
                        .fill(5)
                        .map((item, index) => (
                          <Grid
                            key={index}
                            item
                            sx={{ flexDirection: "row", minWidth: "173px" }}
                          >
                            <MonthyScreenSkeleton></MonthyScreenSkeleton>
                          </Grid>
                        ))}
                    </>
                  ) : (
                    <>
                      {summaryData !== undefined && checkIfNoSummary() ? (
                        summaryData.map((item, index) => {
                          let count = 0;
                          if (
                            item.status !== "" &&
                            item.total_billable_hours !== "" &&
                            item.total_billable_minutes !== "" &&
                            item.total_billing_loss_hours !== "" &&
                            item.total_billing_loss_minutes !== "" &&
                            item.total_filled_hours !== "" &&
                            item.total_filled_minutes !== ""
                          ) {
                            return (
                              <Grid
                                key={index}
                                item
                                sx={{ flexDirection: "row", minWidth: "173px" }}
                                onClick={() => handleGridClick(item, index)}
                              >
                                <MonthlyCard
                                  week={index + 1}
                                  cardDetails={item}
                                  timezone={timezone}
                                ></MonthlyCard>
                              </Grid>
                            );
                          } else {
                            count++;
                            return <NoWeekSummaryCard />;
                          }
                        })
                      ) : (
                        <NoMonthSummaryCard />
                      )}
                    </>
                  )}
                </Grid>
              </div>
            </Grid>
            <Grid item xs={12}>
              {loading ? (
                <Skeleton duration={2} animation="wave" variant="rectangular" />
              ) : (
                <>
                  {count !== 0 ? (
                    <Typography
                      sx={{
                        fontStyle: "normal",
                        fontWeight: 500,
                        fontSize: "14px",
                        color: "#ff3333",
                      }}
                    >
                      The timesheet has been defaulted for {count} week(s).
                    </Typography>
                  ) : null}
                </>
              )}
            </Grid>
          </Grid>
        )}
        <Grid
          item
          xs={12}
          sx={{
            position: "fixed",
            bottom: "2px",
            right: "2px",
          }}
        >
          <Typography
            sx={{
              fontStyle: "normal",

              fontSize: "8px",
              color: "#5E6384",
            }}
          >
            V{packageJson.version}
          </Typography>
        </Grid>
      </Grid>
    </>
  );
};

export default MonthlySummary;
