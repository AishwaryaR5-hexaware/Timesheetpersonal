import { Avatar, Divider, Grid, IconButton, Typography } from "@mui/material";
import React from "react";
import { makeStyles } from "@mui/styles";
import theme from "../../theme";
import PriorityHighRoundedIcon from '@mui/icons-material/PriorityHighRounded';
import CloseRoundedIcon from '@mui/icons-material/CloseRounded';
import DoneRoundedIcon from '@mui/icons-material/DoneRounded';
import { todayDate } from "../utils/util";
//const timezone="Pacific/Kiritimati";
function capitalizeFirstLetterOfWords(str) {
  return str
    .split(" ")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
}
export function getNumberSuffix(number) {
  const suffixes = ["th", "st", "nd", "rd"];
  const remainder = number % 100;
  const suffix =
    suffixes[(remainder - 20) % 10] || suffixes[remainder] || suffixes[0];
  return suffix;
}
export function formatDate(timezone,inputDate) {
  const response=todayDate(timezone,inputDate);
  return `${response.date} ${response.month_str_short}`;
  }

// export function formatDate(date) {
//   const newDate = new Date(date);
//   const month = newDate.toLocaleString("default", { month: "short" });
//   const day = newDate.getDate();
//   const suffix = getNumberSuffix(day);
//   return `${day}${suffix} ${month}`;
// }
// function formatDate(inputDate) {

//   const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

//   const year = inputDate.slice(0, 4);

//   const month = months[Number(inputDate.slice(5, 7)) - 1];

//   const day = inputDate.slice(8);

//   const formattedDate = `${day} ${month}`;

//   return formattedDate;

// }

export function statusChange(weekStatus) {
   //console.log("weekStatus",weekStatus)
  const status = weekStatus.toLowerCase();
  var backgroundColor;
  var png;
  var text;
  var dividerColor;
 if (status === "due for submission") {
    backgroundColor = "#797EF6";
    png = "./Missed.png";
    text = capitalizeFirstLetterOfWords(status);
    dividerColor = "#00DE66";
  } else if (status === "submitted") {
    backgroundColor = "#1B7BEC";
    png = "./Approve.png";
    text = capitalizeFirstLetterOfWords(status);
    dividerColor = "#00DE66";
  } else if (status === "rejected") {
    backgroundColor = "#1E2F98";
    png = "./Reject.png";
    text = capitalizeFirstLetterOfWords(status);
    dividerColor = "#F48116";
  } else if (status === "approved") {
    backgroundColor = "#1B7BEC";
    png = "./Approve.png";
    text = capitalizeFirstLetterOfWords(status);
    dividerColor = "#00DE66";
  }
  else if(status === 'defaulted'){
    backgroundColor = "#797EF6";
    png = "./Missed.png";
    text = capitalizeFirstLetterOfWords(status);
    dividerColor = "#00DE66";
  } 
  // else {
  //   backgroundColor = "#797EF6";
  //   png = "./Missed.png";
  //   text = 'Due For Submission';
  //   dividerColor = "#00DE66";
  // }
  return { backgroundColor, png, text, dividerColor };
}
const styles = {
 
  approveIcon: {
    color: "#fff",
    backgroundColor: "#14B383",
    // fontSize: "10px",
    // padding: "10px",
  },
  submittedIcon: {
    color: "#fff",
    backgroundColor: "#17A7C7",
    // fontSize: "10px",
    // padding: "10px",
  },
  dueIcon: {
    color: "#fff",
    backgroundColor: "#F48116",
    // fontSize: "10px",
    // padding: "10px",
  },
  defaultedIcon: {
    color: "#fff",
    backgroundColor: "#6473CF",
    // fontSize: "10px",
    // padding: "10px",
  },
  rejectIcon: {
    color: "#fff",
    backgroundColor: "#ED7767",
    // fontSize: "10px",
    // padding: "10px",
  },
 
};
function statusIcon(weekStatus) {
  switch (weekStatus.toLowerCase()) {
    case 'submitted':
        return <IconButton
        style={styles.submittedIcon}
        
      >
        <DoneRoundedIcon style={{fontSize:'14'}} />
      </IconButton>   
    case 'due for submission':
        return <IconButton
        style={styles.dueIcon}
        
      >
        <PriorityHighRoundedIcon style={{fontSize:'14'}} />
      </IconButton>
    case 'defaulted':
        return <IconButton
        style={styles.defaultedIcon}
        
      >
        <PriorityHighRoundedIcon style={{fontSize:'14'}} />
      </IconButton>
    case 'approved':
        return <IconButton
        style={styles.approveIcon}
        
      >
        <DoneRoundedIcon style={{fontSize:'14'}} />
      </IconButton>
    case 'rejected':
        return <IconButton
        style={styles.rejectIcon}
        
      >
        <CloseRoundedIcon style={{fontSize:'14'}} />
      </IconButton>
    default:
        return <IconButton
        style={styles.dueIcon}
        
      >
        <PriorityHighRoundedIcon style={{fontSize:'14'}} />
      </IconButton>
}
}
const MonthlyCard = ({ week, cardDetails,timezone }) => {
  const useStyles = makeStyles((theme) => ({
    container: {
      height: "300px",
      display: "grid !important",
      gridTemplateRows: "70% 20%",
      gridTemplateColumns: "100%",
    },
    grid: {
      borderRadius: "20px",
      gridRowStart: 1,
      gridRowEnd: 2,
      gridColumnStart: 1,
      gridColumnEnd: 2,
      zIndex: 1,
    },
    gridContainer: {
      height: "-webkit-fill-available",
      paddingLeft: "40px",
    },
    itemGrid: {
      borderRadius: "20px",
      gridRowStart: 2,
      gridRowEnd: 3,
      gridColumnStart: 1,
      gridColumnEnd: 2,
      marginTop: "-50px !important",
      zIndex: 0,
      background: "#FFFFFF",
      border: "1px solid #CCCDD2",
      boxShadow: "0px 10px 20px rgba(30, 48, 152, 0.16)",
    },
  }));
  const classes = useStyles();
  let { backgroundColor, png, text, dividerColor } = statusChange(
    cardDetails.status
  );
  const formatTotalBillableHours = (hours) => {
    if (hours < 10) {
      return "0" + hours;
    }
    return hours;
  };
  

  return (
    <>
      <Grid
        container
        direction="column"
        // sx={{
        //   // width: "173px",
        //   height: "300px",
        //   display: "grid",
        //   gridTemplateRows: "70% 20%",
        //   gridTemplateColumns: "100%",
        //   // gridGap: "20px",
        // }}
        className={classes.container}
      >
        <Grid
          item
          xs={9}
          sx={{
            backgroundColor: { backgroundColor },
            // borderRadius: "20px",
            // gridRowStart: 1,
            // gridRowEnd: 2,
            // gridColumnStart: 1,
            // gridColumnEnd: 2,
            // zIndex: 1,
          }}
          className={classes.grid}
        >
          <Grid
            container
            direction="column"
            justifyContent="space-evenly"
            alignItems="flex-start"
            className={classes.gridContainer}
            columnSpacing={2}
            // sx={{ height: "-webkit-fill-available", paddingLeft: "40px" }}
          >
            <Grid item sx={{ paddingLeft: "0px !important" }}>
              <Grid container direction="row">
                <Grid item xs={12}>
                  <Typography
                    // sx={{
                    //   fontStyle: "normal",
                    //   fontWeight: 500,
                    //   fontSize: "14px",
                    //   color: "#FBFDFF",
                    // }}
                    variant="body5"
                    color={theme.palette.background.monthlySum}
                  >
                    Week {week}
                  </Typography>
                </Grid>

                <Grid item xs={12}>
                  <Typography
                    // sx={{
                    //   fontStyle: "normal",
                    //   fontWeight: 500,
                    //   fontSize: "12px",
                    //   color: "#FFFFFF",
                    // }}
                    variant="body8"
                    color={theme.palette.common.white}
                  >
                    {formatDate(timezone,cardDetails.start_date)} -{" "}
                    {formatDate(timezone,cardDetails.end_date)}
                  </Typography>
                </Grid>
              </Grid>
            </Grid>
            <Grid item>
              <Grid
                container
                direction="row"
                justifyContent="space-between"
                alignItems="center"
                spacing={2}
              >
                <Grid item sx={{ paddingLeft: "0px !important" }}>
                  <Divider
                    orientation="vertical"
                    variant="middle"
                    flexItem
                    sx={{ border: "2px solid " + dividerColor, height: "40px" }}
                  />
                </Grid>
                <Grid
                  item
                  sx={{ paddingLeft: "10px !important", alignSelf: "center" }}
                >
                  <Typography
                    // sx={{
                    //   fontStyle: "normal",
                    //   fontWeight: 600,
                    //   fontSize: "28px",
                    //   color: "#FBFDFF",
                    // }}
                    variant="h3"
                    color={theme.palette.background.monthlySum}
                  >
                    {cardDetails.total_filled_hours === ""
                      ? "00"
                      : formatTotalBillableHours(
                          cardDetails.total_filled_hours
                        )}
                    :
                    {cardDetails.total_filled_minutes === ""
                      ? "00"
                      : formatTotalBillableHours(
                          cardDetails.total_filled_minutes
                        )}
                  </Typography>
                </Grid>
              </Grid>
            </Grid>
            <Grid item sx={{ paddingLeft: "0px !important" }}>
              <Grid container direction="column">
                <Grid item>
                  <Typography
                    // sx={{
                    //   fontStyle: "normal",
                    //   fontWeight: 400,
                    //   fontSize: "12px",
                    //   color: "#FFFFFF",
                    // }}
                    variant="body9"
                    color={theme.palette.common.white}
                  >
                    Filled Hrs
                  </Typography>
                </Grid>
                <Grid item>
                  <Typography
                    // sx={{
                    //   fontStyle: "normal",
                    //   fontWeight: 400,
                    //   fontSize: "12px",
                    //   color: "#FFFFFF",
                    // }}
                    variant="body9"
                    color={theme.palette.common.white}
                  >
                    out of{" "}
                    {cardDetails.total_billable_hours === ""
                      ? "00"
                      : formatTotalBillableHours(
                          cardDetails.total_billable_hours
                        )}
                    :
                    {cardDetails.total_billable_minutes === ""
                      ? "00"
                      : formatTotalBillableHours(
                          cardDetails.total_billable_minutes
                        )}
                  </Typography>
                </Grid>
                {/* <Grid item>
                  <Typography
                    sx={{
                      fontStyle: "normal",
                      fontWeight: 400,
                      fontSize: "12px",
                      color: "#FFFFFF",
                    }}
                  >
                    Billing Loss :{" "}
                    {Math.abs(cardDetails.total_billing_loss_hours)}:
                    {Math.abs(cardDetails.total_billing_loss_minutes)}
                  </Typography>
                </Grid> */}
              </Grid>
            </Grid>
          </Grid>
        </Grid>
        <Grid
          item
          xs={3}
          // sx={{
          //   borderRadius: "20px",
          //   gridRowStart: 2,
          //   gridRowEnd: 3,
          //   gridColumnStart: 1,
          //   gridColumnEnd: 2,
          //   marginTop: "-50px",
          //   zIndex: 0,
          //   background: "#FFFFFF",
          //   border: "1px solid #CCCDD2",
          //   boxShadow: "0px 10px 20px rgba(30, 48, 152, 0.16)",
          // }}
          className={classes.itemGrid}
        >
          <Grid
            container
            direction="row"
            spacing={1}
            justifyContent="center"
            alignItems="center"
            mt={7}
          >
            <Grid item>
              {/* <Avatar
                alt="Profile Picture"
                src={png}
                sx={{ width: "30px", height: "29px" }}
              /> */}
              {statusIcon(cardDetails.status)}
            </Grid>
            <Grid item>
              <Typography
                sx={{ fontStyle: "normal", fontWeight: 500, fontSize: "14px",whiteSpace: "wrap", 
                maxWidth: "100px", 
                lineHeight: "18px", }}
              >
                {text}
              </Typography>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    </>
  );
};

export default MonthlyCard;
