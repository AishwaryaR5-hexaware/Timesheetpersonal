import React from "react";
import { ChevronLeft, ChevronRight } from "@mui/icons-material";
import { Grid, Typography, IconButton } from "@mui/material";
import { makeStyles } from "@mui/styles";
import { todayDate } from "../utils/util";
//const timezone="Pacific/Kiritimati";


const useStyles = makeStyles((theme) => ({
  gridContainer: {
    background: theme.palette.background.weekDuration,
    borderRadius: "20px",
    width: "206px",
  },
  gridContainerMonthlySummary: {
    background: theme.palette.background.weekDuration,
    borderRadius: "20px",
    width: "206px",
    height: "30px",
  },
  gridItem: {
    background: theme.palette.background.weekBackGrid,
    borderRadius: "20px",
    width: "166px",
  },
  iconButton: {
    fontSize: "14px !important",
    color: theme.palette.common.white
  },
  iconDisable: {
    fontSize: "14px !important" ,
    color: "grey",
  },
  textInside: {
    fontSize: "13px !important",
    color: theme.palette.common.white,
    textAlign: "center",
  },
}));



// export function formatDate(date) {
//   const day = date.getDate();
//   const month = date.toLocaleString("default", { month: "short" });
//   console.log("hi",`${month} ${day}`)
//   return `${month} ${day}`;
// }
//Note: the below code is to be used
export function formatDate(timezone,date) {
  
 const response=todayDate(timezone,date);
 return `${response.month_str_short} ${response.date} `;
}
// export function formatDateMonthlySummary(date) {
//   const month = date.toLocaleString("default", { month: "long" });
//   const year = date.getFullYear().toString();
//   return `${month} ${year}`;
// }
export function formatDateMonthlySummary(timezone,date) {
  const response=todayDate(timezone,date);
  return `${response.month_str_short} ${response.year} `;
  
}

function WeekDuration({
  flag,
  // weeks,
  // currentWeek,
  // updateCurrentWeek,
  loading,
  weeksObj,
  setWeeksObj,
  timezone,
}) {
  // const weekKeys = Object.keys(weeks);
  const weekKeys = Object.keys(weeksObj.weeks);
  const currentWeekIndex = weekKeys.indexOf(weeksObj.currentWeek);
  // console.log("weeksObj",weeksObj)

  const nextWeekChange = () => {
    if (currentWeekIndex < weekKeys.length - 1) {
      const nextWeekKey = weekKeys[currentWeekIndex + 1];
      setWeeksObj((prevWeeksObj) => ({
        ...prevWeeksObj, // Keep the previous state properties unchanged
        currentWeek: nextWeekKey // Update the currentWeek with the new value
      }));
      // updateCurrentWeek(nextWeekKey);
    }
  };

  const previousWeekChange = () => {
    if (currentWeekIndex > 0) {
      const nextWeekKey = weekKeys[currentWeekIndex - 1];
      setWeeksObj((prevWeeksObj) => ({
        ...prevWeeksObj, // Keep the previous state properties unchanged
        currentWeek: nextWeekKey // Update the currentWeek with the new value
      }));
      // updateCurrentWeek(nextWeekKey);
    }
  };


  const currentWeekDate = () => {
    if(weeksObj.weeks && weeksObj.currentWeek)
    {
    return `${formatDate(timezone,weeksObj.weeks[weeksObj.currentWeek]?.startDate)} - ${formatDate(timezone,
      (weeksObj.weeks[weeksObj.currentWeek]?.endDate))}`;
    }
    // return `${formatDate(weeks[currentWeek].startDate)} - ${formatDate( weeks[currentWeek].endDate)}`;
  };

  const currentMonthDate = () => {
    return formatDateMonthlySummary(timezone,weeksObj.weeks["week2"]?.startDate);
  };

  const previousButton = () => {
    if (flag === "mainScreen") {
      previousWeekChange();
    }
  };

  const nextButton = () => {
    if (flag === "mainScreen") {
      nextWeekChange();
    }
  };
  
  const classes=useStyles();

  return (
    <>
      {flag === "mainScreen" ? (
        <Grid
          container
          direction="row"
          justifyContent="space-between"
          alignItems="center"
          // sx={styles.gridContainer}
          className={classes.gridContainer}
        >
          <Grid item xs={2}>
            <IconButton
              onClick={previousButton}
              disabled={currentWeekIndex === 0 || loading}
            >
              <ChevronLeft
                // sx={
                //   currentWeekIndex === 0
                //     ? styles.iconDisable
                //     : styles.iconButton
                // }
                className={
                  (currentWeekIndex === 0 || loading)
                    ? classes.iconDisable 
                    : classes.iconButton
                }
              />
            </IconButton>
          </Grid>
          <Grid item xs={8} 
          // sx={styles.gridItem}
          className={classes.gridItem}
          >
            <Typography 
            // sx={styles.textInside}
            className={classes.textInside}
            >{currentWeekDate()}</Typography>
          </Grid>
          <Grid item xs={2}>
            <IconButton
              onClick={nextButton}
              disabled={currentWeekIndex === weekKeys.length - 1 || loading}
            >
              <ChevronRight
                // sx={
                //   currentWeekIndex === weekKeys.length - 1
                //     ? styles.iconDisable
                //     : styles.iconButton
                // }
                className={
                  (currentWeekIndex === weekKeys.length - 1 || loading)
                    ? classes.iconDisable
                    : classes.iconButton
                }
              />
            </IconButton>
          </Grid>
        </Grid>
      ) : (
        <Grid
          container
          direction="row"
          justifyContent="space-between"
          alignItems="center"
          // sx={styles.gridContainerMonthlySummary}
          className={classes.gridContainerMonthlySummary}
        >
          <Grid item xs={2}>
            <Grid sx={{ width: "16%" }}></Grid>
          </Grid>
          <Grid item xs={8} 
          // sx={styles.gridItem}
          className={classes.gridItem}
          >
            <Typography 
            // sx={styles.textInside}
            className={classes.textInside}
            >{currentMonthDate()}</Typography>
          </Grid>
          <Grid item xs={2}>
            <Grid sx={{ width: "16%" }}></Grid>
          </Grid>
        </Grid>
      )}
    </>
  );
}

export default WeekDuration;
