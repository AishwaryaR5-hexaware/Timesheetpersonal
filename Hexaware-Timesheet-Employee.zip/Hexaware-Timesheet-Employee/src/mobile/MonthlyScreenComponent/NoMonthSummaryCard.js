import { Grid, Typography } from "@mui/material";
import React from "react";
import PriorityHighRoundedIcon from "@mui/icons-material/PriorityHighRounded";

const NoMonthSummaryCard = () => {
  const styles = {
    icon: {
      fontSize: "48",
      color: "#fff",
      backgroundColor: "ED7767",
      borderRadius: "50%",
      padding: "10px",
    },
  };
  return (
    <Grid  item sx={{ flexDirection: "row" }}>
      <Grid container >
        <Grid item container justifyContent={"center"} mt={4}>
          <PriorityHighRoundedIcon style={styles.icon} />
        </Grid>
        <Grid item container justifyContent={"center"} mt={2}>
          <Typography style={{ textAlign: "center", color: "#000" }}>
            No data
          </Typography>
          <Typography
            style={{ textAlign: "center", margin: "5px", color: "#000" }}
          >
            Failed to fetch summary for this project
          </Typography>
        </Grid>
      </Grid>
    </Grid>
  );
};



export default NoMonthSummaryCard