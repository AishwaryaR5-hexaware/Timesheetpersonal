import { Grid, Typography } from "@mui/material";
import React from "react";
import PriorityHighRoundedIcon from "@mui/icons-material/PriorityHighRounded";

const NoWeekSummaryCard = () => {
  const styles = {
    card: {
      backgroundColor: "#fff",
      borderRadius: "20px",
      height: "270px",
      width: "157px",
      boxShadow: "0px 10px 20px rgba(30, 48, 152, 0.16)",
    },
    icon: {
      fontSize: "48",
      color: "#fff",
      backgroundColor: "ED7767",
      borderRadius: "50%",
      padding: "10px",
    },
  };
  return (
    <Grid  item sx={{ flexDirection: "row", minWidth: "173px" }}>
      <Grid container style={styles.card}>
        <Grid item container justifyContent={"center"} mt={4}>
          <PriorityHighRoundedIcon style={styles.icon} />
        </Grid>
        <Grid item container justifyContent={"center"}>
          <Typography style={{ textAlign: "center", color: "#000", fontSize:"28px"  }}>
            No data
          </Typography>
          <Typography
            style={{ textAlign: "center", margin: "5px", color: "#000", fontSize:"14px" }}
          >
            Failed to fetch summary for this week
          </Typography>
        </Grid>
      </Grid>
    </Grid>
  );
};

export default NoWeekSummaryCard;
