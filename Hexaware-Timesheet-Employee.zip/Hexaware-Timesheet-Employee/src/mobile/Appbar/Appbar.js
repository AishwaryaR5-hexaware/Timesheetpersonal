import { Grid, Typography, AppBar, Toolbar, IconButton } from "@mui/material";
import CalendarMonthOutlinedIcon from "@mui/icons-material/CalendarMonthOutlined";
import WeekDuration from "../MonthlyScreenComponent/WeekDuration";
import { useNavigate } from "react-router-dom";
import { ChevronLeft } from "@mui/icons-material";
import { makeStyles } from "@mui/styles";
import theme from "../../theme";
// import { ApplicationInsights } from '@microsoft/applicationinsights-web';
import appInsights from "../HandlerFunctions/appInsights";
import log from "loglevel";

const Appbar = ({
  backgroundColor,
  flag,
  // weeks,
  // currentWeek,
  // updateCurrentWeek,
  loading,
  weeksObj,
  setWeeksObj,
  timezone,
}) => {
  const useStyles = makeStyles((theme) => ({
    icon: {
      borderRadius: "0px",
      color: theme.palette.primary.main,
      fontSize: "24px",
      textAlign: "center",
    },
  }));
  const classes = useStyles();
  const navigate = useNavigate();

  const handleCalenderClick = () => {
    if (appInsights) {
      appInsights.trackEvent({
        name: "monthlySummary",
        properties: { buttonName: "calendarButton" },
      });
    }
    navigate("/monthly-summary");
  };
  const handleChevronClick = () => {
    const environment = process.env.REACT_APP_ENVIRONMENT;
    if (environment === "dev") {
      navigate("/home");
    } else {
      navigate("/");
    }
  };
  return (
    <AppBar
      position="fixed"
      sx={{
        backgroundColor: { backgroundColor },
        boxShadow: "none",
      }}
    >
      <Toolbar>
        <Grid
          container
          direction="row"
          alignItems="center"
          justifyContent="space-between"
          sx={{ padding: "10px", paddingBottom: "10px" }}
        >
          <Grid item>
            {flag === "mainScreen" ? (
              <img alt="hexaware" src={"./timelogo.png"}></img>
            ) : flag === "monthSummaryScreen" ? (
              <IconButton
                onClick={() => {
                  handleChevronClick();
                }}
              >
                <ChevronLeft
                  sx={{
                    fontSize: "25px",
                    color: "#000000",
                  }}
                />
              </IconButton>
            ) : (
              <></>
            )}
          </Grid>
          <Grid item>
            <Grid container direction="column">
              <Grid item>
                <Typography
                  variant="h5"
                  align="center"
                  // sx={styles.appName}
                  className={classes.appName}
                  color={theme.palette.secondary.main}
                >
                  Time
                </Typography>
              </Grid>
              <Grid item mt={1}>
                <WeekDuration
                  flag={flag}
                  // currentWeek={currentWeek}
                  // weeks={weeks}
                  // updateCurrentWeek={updateCurrentWeek}
                  loading={loading}
                  weeksObj={weeksObj}
                  setWeeksObj={setWeeksObj}
                  timezone={timezone}
                ></WeekDuration>
              </Grid>
            </Grid>
          </Grid>
          {flag === "mainScreen" ? (
            <Grid
              item
              onClick={() => {
                handleCalenderClick();
              }}
              name="monthlySummary"
            >
              <CalendarMonthOutlinedIcon
                // sx={styles.icon}
                className={classes.icon}
              ></CalendarMonthOutlinedIcon>
            </Grid>
          ) : (
            <Grid item xs={0.6}>
              <></>
            </Grid>
          )}
        </Grid>
      </Toolbar>
    </AppBar>
  );
};

export default Appbar;
