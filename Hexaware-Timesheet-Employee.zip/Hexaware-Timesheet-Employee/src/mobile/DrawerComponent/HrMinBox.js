import React from "react";

const HrMinBox = ({ value,width }) => {
  const formattedValue = value < 10 ? `0${value}` : value;
  return (
    <div
      style={{
        width: `${width}px`,
        height: "79px",
        backgroundColor: "white",
        color: "black",
        border: "1px solid #A4B1E5",
        borderRadius: "6px",
        //marginBottom: "10px",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        fontSize: "50px",
        fontWeight: "500",
      }}
    >
      {formattedValue}
    </div>
  );
};

export default HrMinBox;
