import React from "react";
import Skeleton from "@mui/material/Skeleton";
import { Drawer, Grid, Typography } from "@mui/material";
const BottomDrawerSkeleton = () => {
  return (
    <>
      <Grid
        container
        direction="row"
        justifyContent="center"
        alignItems="center"
      >
        <Grid
          item
          xs={12}
          style={{
            paddingTop: "15px",
            paddingRight: "25px",
            paddingLeft: "25px",
          }}
        >
          <Grid
            container
            direction="row"
            justifyContent="space-between"
            alignItems="center"
            mb={2}
          >
            <Grid item xs={6}>
            <Skeleton
                duration={2}
                animation="wave"
                variant="rounded"
                height={"30px"}
                style={{ width: "50%"}}
              />
            </Grid>

            <Grid item xs={6}>
              <Skeleton
                duration={2}
                animation="wave"
                variant="rounded"
                height={"30px"}
                style={{ width: "70%", marginLeft: "50px" }}
              />
            </Grid>
          </Grid>
        </Grid>

        <Grid container item xs={12} justifyContent='center' mb={2}>
          <Skeleton
            duration={2}
            animation="wave"
            variant="rounded"
            height={"40px"}
            style={{ width: "90%" }}
          />
        </Grid>

        <Grid container item xs={12} justifyContent={"flex-end"}>
          <Skeleton
            duration={2}
            animation="wave"
            variant="rectangular"
            height={"10px"}
            style={{ width: "100%", marginTop: "3px"}}
          />
        </Grid>
      </Grid>
    </>
  );
};

export default BottomDrawerSkeleton;
