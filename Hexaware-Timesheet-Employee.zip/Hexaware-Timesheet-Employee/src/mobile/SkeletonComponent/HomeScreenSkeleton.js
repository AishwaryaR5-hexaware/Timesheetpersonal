import React from "react";
import Skeleton from "@mui/material/Skeleton";
import { Grid } from "@mui/material";

const HomeScreenSkeleton = () => {
  return (
    <>
      {Array(10)
        .fill()
        .map((item, index) => (
          <React.Fragment key={index}>
            <Grid item xs={2} key={index}>
              <Grid
                container
                direction="row"
                alignItems="center"
                justifyContent="flex-start"
                key={index+1}
              >
                <Skeleton
                  duration={2}
                  animation="wave"
                  variant="rectangular"
                  width={"75px"}
                  height={"90px"}
                  style={{ marginBottom: "20px", marginLeft: "10px" }}
                />
              </Grid>
            </Grid>
            <Grid item xs={10} key={index+1}>
              <Grid container direction="column">
                <Grid item>
                  <Grid
                    container
                    direction="row"
                    mt={1}
                    sx={{ paddingLeft: "10px", paddingRight: "15px" }}
                  >
                    {Array(2)
                      .fill()
                      .map((p, index) => (
                        <React.Fragment key={index}>
                          <Grid item xs={12} mb={1} key={index}>
                            <Skeleton
                              duration={2}
                              animation="wave"
                              variant="rectangular"
                              // width={"70px"}
                              // height={"20px"}
                            />
                          </Grid>
                        </React.Fragment>
                      ))}
                  </Grid>
                </Grid>
                <Grid item>
                  <Grid
                    container
                    direction="row"
                    justifyContent="space-between"
                    alignItems="center"
                    mt={4}
                    sx={{ paddingLeft: "10px", paddingRight: "15px" }}
                  >
                    <Grid item>
                      <Skeleton
                        duration={2}
                        animation="wave"
                        variant="rectangular"
                        width={"70px"}
                        height={"20px"}
                      />
                    </Grid>

                    <Grid item>
                      <Skeleton
                        duration={2}
                        animation="wave"
                        variant="rectangular"
                        width={"70px"}
                        height={"20px"}
                      />
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </Grid>
          </React.Fragment>
        ))}
    </>
  );
};

export default HomeScreenSkeleton;
