import React from "react";
import { Grid} from "@mui/material";
import Skeleton from "@mui/material/Skeleton";

const MonthyScreenSkeleton = () => {
  return (
    <>
      <Grid
        container
        direction="column"
        sx={{
          height: "300px",
          display: "grid",
        }}
      >
        <Skeleton
          duration={2}
          animation="wave"
          variant="rounded"
          width={"100%"}
          height={"250px"}
          style={{ borderRadius: "20px" }}
        />
      </Grid>
    </>
  );
};

export default MonthyScreenSkeleton;
