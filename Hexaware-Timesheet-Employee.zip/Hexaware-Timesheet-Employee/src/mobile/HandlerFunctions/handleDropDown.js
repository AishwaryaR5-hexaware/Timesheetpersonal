import { getTaskNames } from "../../Services/Tasks";

export async function handleDropDown(month,year) {
  const projectDropDownList = [];
  const categoryDropDownList = [];
  const data = await getTaskNames(month,year);
  if(data.status === 500){
    return 'Error'
  }
  if(data.projects.length === 0){
    return 'No Projects'
  }
  for (var i = 0; i < data.projects.length; i++) {
    projectDropDownList.push(data.projects[i]);
  }
  for (var j = 0; j < data.categories.length; j++) {
    categoryDropDownList.push(data.categories[j].CategoryName);
  }
  return [projectDropDownList, categoryDropDownList];
  
}
