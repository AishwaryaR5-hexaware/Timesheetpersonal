import { ApplicationInsights } from "@microsoft/applicationinsights-web"

let appInsights = null

if (process.env.REACT_APP_APPINSIGHTS === "true") {
  const appInsights = new ApplicationInsights({
    config: {
      connectionString: process.env.REACT_APP_APPINSIGHTS_INSTRUMENTATIONKEY
    }
  })

  appInsights.loadAppInsights()
}

export default appInsights

