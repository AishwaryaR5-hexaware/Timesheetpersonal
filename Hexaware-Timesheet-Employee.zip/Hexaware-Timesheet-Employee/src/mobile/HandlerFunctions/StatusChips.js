import { Chip } from '@mui/material'
import React from 'react'
import { makeStyles } from "@mui/styles";
import theme from '../../theme'

const StatusChips = ({status}) => {
    const useStyles = makeStyles((theme) => ({
        chip:{
            color: theme.palette.common.white+'!important',
            fontSize: '12px',
            padding: '2px 8px',
            borderRadius: '14px' 
        },
    }))

    const classes = useStyles();
    //create a switch case for the status which returns jsx
    switch (status) {
        case 'Submitted':
            return <Chip label="Submitted" style={{ backgroundColor: theme.palette.chip.submitted }} className={classes.chip}/>   
        case 'Not Submitted':
            return <Chip label="Not-Submitted" style={{ backgroundColor: theme.palette.chip.notSubmitted }} className={classes.chip} />
        case 'Auto Submitted':
            return <Chip label="Auto-Submitted" style={{ backgroundColor: theme.palette.chip.autoSubmitted }} className={classes.chip} />
        case 'Approved':
            return <Chip label="Approved" style={{ backgroundColor: theme.palette.chip.approved }} className={classes.chip} />
        case 'Rejected':
            return <Chip label="Rejected" style={{ backgroundColor: theme.palette.chip.rejected }} className={classes.chip} />
        default:
            return <Chip label="Not-Submitted" style={{ backgroundColor: theme.palette.chip.notSubmitted }} className={classes.chip} />
    }
}

export default StatusChips