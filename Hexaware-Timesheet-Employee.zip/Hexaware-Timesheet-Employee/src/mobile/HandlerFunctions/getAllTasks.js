import { getWeeklyTasks } from "../../Services/Tasks";

export async function getAllTasks(startDate, endDate) {
  const data = await getWeeklyTasks(startDate, endDate);

  
  if (data.status === 500) {
    return "Error";
  }
  const jsonData = await data.items;
  if (!jsonData || jsonData.length === 0) {
    return "Empty";
  }
  const keyValuePairs = {};
  jsonData.forEach((item) => {
    const date = item.timesheet_date;
    if (!keyValuePairs[date]) {
      keyValuePairs[date] = [];
    }
    keyValuePairs[date].push(item);
  });
  return {
    keyValuePairs: keyValuePairs,
  };
}
