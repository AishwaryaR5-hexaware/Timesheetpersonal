export function getLastSundayOfMonth(year, month) {
    const lastDayOfMonth = new Date(year, month + 1, 0);
    const lastSunday = lastDayOfMonth.getDate() - lastDayOfMonth.getDay();
    return new Date(year, month, lastSunday);
  }
  
export  function getFirstSundayOfMonth(year, month) {
    const firstDayOfMonth = new Date(year, month, 1);
    var firstSundayDate;
    if (firstDayOfMonth.getDay() !== 0) {
      firstSundayDate = 7 - firstDayOfMonth.getDay() + 1;
    } else {
      firstSundayDate = 1;
    }
  
    return new Date(year, month, firstSundayDate);
  }
  
export  function formatDate(date) {
    const day = date.getDate();
    const month = date.toLocaleString("default", { month: "short" });
    const year = date.getFullYear();
    return `${month} ${day} ${year}`;
  }

export function getCurrentMonthWeeks() {
    const weeks = {};
    const now = new Date();
    const year = now.getFullYear();
    const month = now.getMonth();
    const firstDayOfMonth = new Date(year, month, 1);
    const lastDayOfMonth = new Date(year, month + 1, 0);
    let firstSunday = 1;
    let weekNum = 1;

    if (firstDayOfMonth.getDay() !== 0) {
      firstSunday = 7 - firstDayOfMonth.getDay() + 1;
      const firstSunday1 = getLastSundayOfMonth(year, month - 1);
      const startDate1 = new Date(firstSunday1);
      const endDate1 = new Date(year, month, firstSunday - 1);
      weeks[`week1`] = { startDate: startDate1, endDate: endDate1 };
      weekNum++;
    }

    const lastDayOfMonthWeekday = lastDayOfMonth.getDay();
    const lastSundayOfMonth = getLastSundayOfMonth(year, month);

    let currentDate = getFirstSundayOfMonth(year, month);
    while (currentDate < lastSundayOfMonth) {
      const start = currentDate.getDate();
      const end = new Date(
        year,
        month,
        Math.min(start + 6, lastDayOfMonth.getDate())
      );
      const startDate = new Date(currentDate);
      const endDate = new Date(end);
      weeks[`week${weekNum}`] = { startDate, endDate };
      currentDate.setDate(currentDate.getDate() + 7);
      weekNum++;
    }

    if (lastDayOfMonthWeekday !== 6) {
      const startDate2 = new Date(lastSundayOfMonth);
      const firstSundayOfNextMonth = getFirstSundayOfMonth(year, month + 1);
      const endDate2 = new Date(
        year,
        month + 1,
        firstSundayOfNextMonth.getDate() - 1
      );
      weeks[`week${weekNum}`] = { startDate: startDate2, endDate: endDate2 };
    } else {
      const startDate = lastSundayOfMonth;
      const endDate = lastDayOfMonth;

      weeks[`week${weekNum}`] = { startDate: startDate, endDate: endDate };
    }
    // Get current date and week number
    const currentWeek = Object.keys(weeks).find((week) => {
      // console.log("week",week)

      const { startDate, endDate } = weeks[week];
      var end = new Date(formatDate(endDate)); //Year, Month, Date
      var today = new Date(formatDate(now)); //Year, Month, Date
      var start = new Date(formatDate(startDate)); //Year, Month, Date
      return today >= start && today <= end;
    });

    // console.log("currentWeek from", currentWeek);

    return { weeks, todayDate: now, todayWeek: currentWeek };
  }