import React from "react";
import { loginRequest } from "../../authConfig";
import { useMsal } from "@azure/msal-react";
import { Box, Button, Grid, TextField, Typography } from "@mui/material";
import { useNavigate } from "react-router-dom";
const AuthLogin = () => {
  const { instance } = useMsal();

  return (
    <Box
      sx={{
        height: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "#FFFFFF",
      }}
    >
      <Grid
        container
        sx={{ width: "90%" }}
        justifyContent="space-between"
        alignItems="center"
      >
        <Grid item xs={12}>
          <img
            src="/splash screen illustration.png"
            style={{ width: "280px", height: "185px" }}
            alt="login"
          />
        </Grid>
        <Grid item xs={12} sx={{ marginBottom: "30px", marginTop: "30px" }}>
          <Typography
            sx={{
              fontFamily: "Poppins",
              fontSize: "28px",
              color: "#312E49",
              fontWeight: "600",
              textAlign: "center",
            }}
          >
            Organise your timesheet from anywhere
          </Typography>
        </Grid>

        <Grid item xs={12}>
          <Button
            onClick={() => {
              instance
                .loginRedirect(loginRequest)
                .catch((error) => console.log(error));
            }}
            variant="contained"
            color="primary"
            sx={{
              width: "100%",
              borderRadius: "6px",
              backgroundColor: "#1E2F98",
              fontFamily: "Poppins",
              fontSize: "14px",
              color: "#FFFFFF",
              fontWeight: "600",
              textTransform: "none",
            }}
          >
            Get Started
          </Button>
        </Grid>
      </Grid>
    </Box>
  );
};

export default AuthLogin;
