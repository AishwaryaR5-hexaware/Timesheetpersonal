import React, { useContext } from "react"
import { useMsal } from "@azure/msal-react"
import { Box, Button, Grid, TextField, Typography } from "@mui/material"
import { useNavigate } from "react-router-dom"
import { UserContext } from "../../App"
import { makeStyles } from "@mui/styles"
// import { ApplicationInsights } from "@microsoft/applicationinsights-web"
import log from "loglevel"
import appInsights from "../HandlerFunctions/appInsights"

const useStyles = makeStyles((theme) => ({
  background: {
    height: "100vh",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: theme.palette.common.white
  },
  loginButton: {
    width: "100%",
    borderRadius: "6px",
    backgroundColor: theme.palette.primary.color,
    fontFamily: "Poppins",
    fontSize: "14px",
    color: theme.palette.common.white,
    fontWeight: "600",
    textTransform: "none !important"
  },
  image: {
    width: "280px",
    height: "185px",
    align: "center"
  },
  container: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center"
  },
  container2: {
    display: "flex",
    justifyContent: "center",
    textAlign: "center",
    marginBottom: "30px",
    marginTop: "30px"
  },
  margin: {
    marginBottom: "30px",
    marginTop: "30px"
  }
}))

const Login = () => {
  const classes = useStyles()
  const navigate = useNavigate()
  const { empId, setEmpId } = useContext(UserContext)

  // const appInsights = new ApplicationInsights({
  //   config: {
  //     connectionString: process.env.REACT_APP_APPINSIGHTS_INSTRUMENTATIONKEY
  //   }
  // });
  // appInsights.loadAppInsights();

  const handleButtonClick = () => {
    localStorage.setItem("empId", empId)
    navigate("/home")
    if (appInsights) {
      appInsights.trackEvent({ name: "GetStarted", properties: { buttonName: "loginButton" } })
    }
  }

  return (
    <Box
      // sx={{
      //   height: "100vh",
      //   display: "flex",
      //   alignItems: "center",
      //   justifyContent: "center",
      //   backgroundColor: "#FFFFFF",
      // }}
      className={classes.background}>
      <Grid container sx={{ width: "90%" }} justifyContent="space-between" alignItems="center">
        <Grid item xs={12} className={classes.container}>
          <img
            src="/splash screen illustration.png"
            // style={{ width: "280px", height: "185px" }}
            className={classes.image}
            alt="login"
          />
        </Grid>
        <Grid
          item
          xs={12}
          // sx={{ marginBottom: "30px", marginTop: "30px" }}
        >
          <div className={classes.container2}>
            <Typography
              variant="h3"
              // sx={{
              //   fontFamily: "Poppins",
              //   fontSize: "28px",
              //   color: "#312E49",
              //   fontWeight: "600",
              //   textAlign: "center",
              // }}
            >
              Organise your timesheet from anywhere
            </Typography>
          </div>
        </Grid>
        <Grid item xs={12} sx={{ marginBottom: "30px", marginTop: "10px" }}>
          <TextField label="Employee Id" id="outlined-basic" variant="outlined" sx={{  color :"#000", width: "100%" }} inputProps={{
            style: { color: '#000' },
          }} onChange={(e) => setEmpId(e.target.value)} />
        </Grid>
        <Grid item xs={12}>
          <Button
            // onClick={() => {
            //   instance
            //     .loginRedirect(loginRequest)
            //     .catch((error) => console.log(error));
            // }}
            onClick={() => {
              // instance
              //   .loginRedirect(loginRequest)
              //   .catch((error) => console.log(error));
              handleButtonClick()
            }}
            variant="contained"
            // color="primary"
            // sx={{
            //   width: "100%",
            //   borderRadius: "6px",
            //   backgroundColor: "#1E2F98",
            //   fontFamily: "Poppins",
            //   fontSize: "14px",
            //   color: "#FFFFFF",
            //   fontWeight: "600",
            //   textTransform: "none",
            // }}
            className={classes.loginButton}>
            Get Started
          </Button>
        </Grid>
      </Grid>
    </Box>
  )
}

export default Login
