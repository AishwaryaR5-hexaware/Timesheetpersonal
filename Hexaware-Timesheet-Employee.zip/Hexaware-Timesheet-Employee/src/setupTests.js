// jest-dom adds custom jest matchers for asserting on DOM nodes.
// allows you to do things like:
// expect(element).toHaveTextContent(/react/i)
// learn more: https://github.com/testing-library/jest-dom
import '@testing-library/jest-dom';

// const nodeCrypto = require("crypto");
// window.crypto = {
//   getRandomValues: function (buffer) {
//     return nodeCrypto.randomFillSync(buffer);
//   },
// };
// //require('dotenv').config();

// // jest.mock('./authConfig', () => ({
// //     getActiveAccount: () => ({}),
// //     protectedResources: () => ({
// //         apiAsset: {
// //             endpoint: "",
// //             scopes: ""
// //         }
// //     }),

// // }));

// jest.mock('./Services/MsalConfig', () => ({
//     getActiveAccount: () => ({}),
//     acquireTokenSilent: () => Promise.resolve({ accessToken: '' }),
// }));

// jest.mock('./index', () => ({
//     getActiveAccount: () => ({}),
//     acquireTokenSilent: () => Promise.resolve({ accessToken: '' }),
// }));

jest.mock('./Services/MsalConfig', () => ({
    msalInstance: {
      getActiveAccount: jest.fn(),
      acquireTokenSilent: jest.fn().mockResolvedValue({ accessToken: 'Xebra3DV_ugCUP6CBrYc8g' }),
    },
  }));

  jest.mock('./index', () => ({
        getActiveAccount: jest.fn(),
        getAllAccounts: jest.fn(),
        setActiveAccount: jest.fn(),
        enableAccountStorageEvents: jest.fn(),
        addEventCallback: jest.fn(),
        acquireTokenSilent: jest.fn().mockResolvedValue({ accessToken: 'Xebra3DV_ugCUP6CBrYc8g' }),
  }));