import { createTheme } from '@mui/material/styles';

const theme2 = createTheme({
  palette: {
    mode: "dark",
    primary: {
      main: '#2F46D6',
      contrastText: "#FFFFFF"
    },
    secondary: {
      main: "#FFFFFF",
      contrastText: "#2F46D6"
    },
    accent:{
      main: '#717694'
    },
    error: {
      main: "#d32f2f"
    },
    success: {
      main: "#137558",
      contrastText: "#FFFFFF"
    },
    info: {
      main:"#0288d1"
    },
    common:{
      black: '#000000',
      white: '#FFFFFF',
      note: '#1E2F98',
      card: "#292929",
      faintGreen: "#29C999",
      overlayColor: "#323232",
      lightblack: '#252626',
      colonColor: '#FCFDFE',
      commentCard: "#2929291A",
      faintGrey: '#E9EFF4',
    },
    text:{
      dropdown: "#696969"
    },
    icon:{
      add: "#1E2F98"
    },
    background: {
     paper: '#121212',
     default: '#121212',
     dropdown:"#292929",
     bottomDrawer2: "#2E3133",
     commentCard: "#363636",
     hrMinBox: '#1B1B1C'
    },
    projectAndTime: {
      main: "#BDC6FF",
    },
    slider:{
      background: "#FFFFFF"
    }
  },
  typography: {
    fontFamily: 'Poppins',
    body1: {
      fontSize: "0.813rem",
    },
    h5: {
      fontSize: "1rem",
      fontWeight: "600",
    },
    subtitle1: {
      fontSize: "0.875rem",
      lineHeight: "21px"
    },
    body2: {
      fontSize: "1rem",
      fontWeight: "500",
    },
    body3: {
      fontSize: "0.75rem",
      fontWeight: "500",
    },
    h7: {
      fontWeight: "500",
      fontSize: "1.75rem",
    },
    body4: {
      fontWeight: "500",
      fontSize: "0.813rem",
    },
    body5: {
      fontSize: "0.75rem",
      fontWeight: "500",
    },
    body6: {
      fontSize: "0.75rem",
      fontWeight: "400",
    },
    body7: {
      fontSize: "0.75rem",
      fontWeight: "700",
    },
    body8: {
      fontSize: "1.125rem",
      fontWeight: "400",
    },
    primaryProject: {
      fontSize: "0.563rem",
      fontWeight: "700",
    },
    toggleDate: {
      fontWeight: "500",
      fontSize: "1.3rem",
    },
    toggleDay: {
      fontWeight: "400",
      fontSize: "0.8rem",
    },
    colonText: {
      fontSize: "3.125rem",
      fontWeight: "500",
    },
    addTime: {
      fontSize: "0.875rem",
      fontWeight: "500",
    }
  },
  components: {
    MuiAppBar: {
      styleOverrides: {
        root: {
          backgroundImage: "none",
          boxShadow: "none"
        },
      },
    },
    MuiSelect: {
      styleOverrides: {
        root: {
          background: "#292929",
          borderRadius: "8px",
          border: "1px solid #434343",
          color: "#696969",
          fontSize: "13px",
          '.MuiSelect-icon': {
            color: "#5E6384"
          },
        },
      },
    },
    MuiPaper: {
      styleOverrides: {
        popOver: {
          width: 204,
          maxWidth: "100%",
          backgroundColor: "#252626",
          border: "1px solid #FFF",
          position: "relative",
         
          '.MuiPopover-paper': {
            backgroundImage: "none",
            boxShadow: "none",
          },
          "&::before": {
            backgroundColor: "#252626",
            content: '""',
            display: "block",
            position: "absolute",
            width: 14,
            height: 14,
            top: 140,
            transform: "rotate(45deg)",
            left: "calc(90% - 4px)",
            borderRight: "1px solid #FFF",
            borderBottom: "1px solid #FFF"
          },
        },
      },
    },
    MuiDivider: {
      styleOverrides: {
        root: {
          backgroundColor: "#FFF",
        },
      },
    },
    MuiBackdrop: {
      styleOverrides: {
        root: {
          backgroundColor: "rgba(50, 50, 50, 0.50)",
        }
      }
    },
    MuiSlider: {
      styleOverrides: {
        root: {
          color: "#FFFFFF",
        }
      }
    },
    MuiButton: {
      styleOverrides: {
        drawerButton: {
          fontWeight: '600',
          fontSize: '17px',
          color: '#1E2F98',
          backgroundColor:"white",
          borderRadius: "5px",
          height: '44px'
        },
        modifyButton: {
          width: '205px',
          backgroundColor: '#2F46D6',
          fontWeight: '500',
          fontSize: '17px',
          borderRadius: "5px",
          height: '48px',
          maxWidth: '100%'
        },
        removeButton: {
          fontWeight: '500',
          width: '112px',
          height: '48px',
          fontSize: '17px',
          color: '#1E2F98',
          backgroundColor:"white",
          borderRadius: "5px",
        },
      }
    },
    MuiToggleButton: {
      styleOverrides: {
        root: {
          backgroundColor: "#292929",
          padding: "0px",
          borderRadius: "5px",
          margin: "5px",
         
        }
      }
    },
    MuiToggleButtonGroup: {
      styleOverrides: {
        grouped: {
          '&:not(:last-of-type)': {
            borderTopRightRadius: '5px',
            borderBottomRightRadius: '5px',
          },
          '&:not(:first-of-type)': {
            marginLeft: '-1px',
            borderLeft: '1px solid rgba(255, 255, 255, 0.12)',
            borderTopLeftRadius: '5px',
            borderBottomLeftRadius: '5px',
          },
        },
      },
    },
  }
});


export default theme2;