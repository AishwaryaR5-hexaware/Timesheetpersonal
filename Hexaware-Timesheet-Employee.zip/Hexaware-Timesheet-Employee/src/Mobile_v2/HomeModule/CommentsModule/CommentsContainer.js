import React, { useState } from "react";
import { Grid, Select, MenuItem, Typography, Box } from '@mui/material';
import CalendarMonthOutlinedIcon from "@mui/icons-material/CalendarMonthOutlined";
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import CommentsCard from "./CommentsCard";

const CommentsContainer = () => {
    const styles = {
        gridItemSelect: {
            width: "100%",
            height: "40px",
            color: "common.white"
        },
        gridItemSelectBox: {
            display: "flex",
            gap: 1
        }
    }
    const commentsData = [
        {
            "id": "1000059162",
            "name": "Bhavya",
            "designation": "Manager",
            "comment": " Please add to training hours. And split the total hours for both the projects.",
            "time": "6 Mins ago",
            "profilePhoto":"https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=880&q=80"
        },
        {
            "id": "1000059163",
            "name": "Me",
            "designation": " ",
            "comment": "Updated the timesheet. Please approve for hte entire week.",
            "time": "A Min ago",
            "profilePhoto": ""
        },
        {
            "id": "1000059162",
            "name": "Bhavya",
            "designation": "Manager",
            "comment": " Please add to training hours. And split the total hours for both the projects.",
            "time": "6 Mins ago",
            "profilePhoto":"https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=880&q=80"
        },
    ]
    const [selectedValue, setSelectedValue] = useState('6th January, 2023');
    return (
        <>
            <Grid
                container
                direction="row"
                justifyContent="flex-start"
                alignItems="center"
                mt={4}
            >
                <Grid item xs={8} mb={1}>
                    <Select
                        value={selectedValue}
                        onChange={(event) => setSelectedValue(event.target.value)}
                        sx={styles.gridItemSelect}
                        IconComponent={ExpandMoreIcon}
                        renderValue={(value) => {
                            return (
                                <Box sx={styles.gridItemSelectBox}>
                                    <CalendarMonthOutlinedIcon fontSize="medium" />
                                    <Typography
                                        variant="subtitle2"
                                        mt={"3px"}
                                    >
                                        {value}
                                    </Typography>
                                </Box>
                            );
                        }}
                    >

                        <MenuItem value={"6th January, 2023"}>
                            6th January, 2023
                    </MenuItem>
                        <MenuItem value={"7th January, 2023"}>
                            7th January, 2023
                    </MenuItem>
                        <MenuItem value={"8th January, 2023"}>
                            8th January, 2023
                    </MenuItem>
                    </Select>
                </Grid>
                {
                    commentsData && commentsData.map((item, i) => {
                        return (
                            <>
                                <Grid item xs={12} my={"15px"} key={i}  >
                                    <CommentsCard commentData= { item }></CommentsCard>
                                </Grid>
                            </>
                        )
                    })
                }
            </Grid>
        </>
    )
}

export default CommentsContainer;