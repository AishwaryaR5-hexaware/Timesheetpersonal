import React from "react";
import Grid from '@mui/material/Grid';
import Drawer from '@mui/material/Drawer';
import TextField from '@mui/material/TextField';
import Avatar from '@mui/material/Avatar';
import InputAdornment from '@mui/material/InputAdornment';

const CommentsFooter = () => {
    const styles = {
        avatar: {
            width: "50px", 
            height: "50px"
        },
        avatarProfile: {
            width: "37px", 
            height: "37px"
        },
        textField: {
            "& .MuiOutlinedInput-root": {
                "& > fieldset": {
                    borderRadius: "50px",
                    border: "1px solid rgba(227, 231, 255, 0.69)",
                    width: "269px",
                },
            },
        },
    }
    return (
        <>
           <Drawer PaperProps={{style: {border: 'none'}}} variant="permanent" anchor="bottom" overflowX= "hidden">
                 < Grid 
                    container
                    direction="row"
                    justifyContent="center"
                    alignItems="center"
                    
                >
                    <Grid item my={2}>
                        <TextField
                            id="outlined-basic"
                            placeholder="Write a comment..."
                            variant="outlined"
                            sx= { styles.textField }
                            InputProps={{
                                startAdornment: 
                                    <InputAdornment position="start"> 
                                        <Avatar 
                                            sx={ styles.avatarProfile }
                                            src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=880&q=80" 
                                            aria-label="profile"
                                        >
                                        </Avatar> 
                                    </InputAdornment>
                            }}
                        />
                    </Grid>
                    <Grid item my={3} ml={5}>
                        <Avatar 
                            sx= { styles.avatar } 
                            src="./AddComment.svg" 
                            aria-label="addComment" 
                        />
                    </Grid>
                </Grid>
            </Drawer>
        </>
    )
}

export default CommentsFooter;