import React from "react";
import { Typography } from '@mui/material';
import Card from '@mui/material/Card';
import CardHeader from '@mui/material/CardHeader';
import CardContent from '@mui/material/CardContent';
import CardActions from '@mui/material/CardActions';
import Avatar from '@mui/material/Avatar';
import { red } from '@mui/material/colors';


const CommentsCard = ({ commentData }) => {
    var cardColor = "background.commentCard";
    var borderradius =  "5px";
    var borderStyle = "2px solid #E3E7FF1A";
    if(commentData.name != "Me"){
        cardColor = "background.commentCard";
        borderradius = "8px";
        borderStyle = "1px solid rgba(0, 0, 0, 0.05)"
    }
    else{
        cardColor = "common.commentCard";
        borderradius = "5px";
        borderStyle= "2px solid #E3E7FF1A";
    }

    const styles = {
        card: { 
            borderRadius: borderradius,
            border: borderStyle,
            "&.MuiPaper-root": {
                backgroundImage: "none",
                backgroundColor: cardColor,
                boxShadow: "0px 4px 12px -4px rgba(0, 0, 0, 0.15)"
              }
        },
        cardHeader: {
            display: "flex", 
            flex: "1",
            paddingBottom: "10px"
        },
        avatarProfile: {
            width: "37px", 
            height: "37px",
            border: "1px solid #FFF"
        },
        cardActions: {
            display: "flex",
            justifyContent: "flex-end",
            alignItems: "flex-start",
            p: "0px 16px 16px 8px"
        }
    }

    return (
        <>
            <Card  mb={2} sx={ styles.card }>
                <CardHeader 
                    sx={ styles.cardHeader }
                    avatar={
                        <Avatar 
                            sx= { styles.avatarProfile } 
                            src= { commentData.profilePhoto }
                            aria-label="profile"
                        >
                        </Avatar>
                    }
                    title= {
                        <Typography variant="h5">
                           { commentData.name }
                        </Typography>
                     } 
                     subheader= {
                        commentData.name != "Me" && <Typography variant="caption">
                            { commentData.id } |  { commentData.designation }
                        </Typography>
                     } 
                />
                <CardContent sx={{paddingTop: "0px"}}>
                    <Typography variant="subtitle1" color="common.white">
                         { commentData.comment }
                    </Typography>
                </CardContent>
                <CardActions disableSpacing
                    sx= { styles.cardActions }
                >
                    <Typography variant="caption" >
                        { commentData.time }
                    </Typography>
                </CardActions>
            </Card>
        </>
    )
}

export default CommentsCard;