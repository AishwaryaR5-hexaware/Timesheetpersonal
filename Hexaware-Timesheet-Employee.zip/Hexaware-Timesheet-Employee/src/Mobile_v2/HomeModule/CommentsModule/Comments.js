import React from "react";
import { Grid } from '@mui/material';
import Appbar from "../CommonModule/Appbar";
import { constantsConfig } from "../Constants/ConstantsConfig";
import CommentsContainer from "../CommentsModule/CommentsContainer";
import CommentsFooter from "../CommentsModule/CommentsFooter";

const Comments = () => {
    const styles = {
        commentContainer:{
            overflow: "auto", 
            maxHeight: "calc(100vh - 170px)", 
            paddingTop: "15px"
        }
    }
    return(
        <>
             <Grid 
                container 
                columns={1}   
            >
                <Grid item xs={8} my={2}>
                   <Appbar title= { constantsConfig.comments }></Appbar>
                </Grid>
                <Grid item mt={5}   px={3}  sx= { styles.commentContainer }>
                    <CommentsContainer></CommentsContainer>
                </Grid>
                <Grid item  >
                     <CommentsFooter></CommentsFooter>
                </Grid>
            </Grid>
            
        </>
    )
}

export default Comments;