import React from "react"
import { ChevronLeft } from "@mui/icons-material";
import WeekDuration from "../AppbarModule/WeekDuration";
import { Grid, Typography, AppBar } from '@mui/material';
import { useNavigate } from "react-router-dom";
import { constantsConfig } from "../Constants/ConstantsConfig";
const MonthlySummaryAppbar = () => {
    const styles = {
        appbar: {
            height: "100px"
        }
    }
    const navigate = useNavigate();
    const handleRedirectToHome = () => {
        navigate("/home");
    }
    return (
        <>
        <AppBar
            position="fixed"
            sx= { styles.appbar }
        >
            <Grid
                container
                direction="row"
                alignItems="center"
                justifyContent="flex-start"
                mt={2}
            >
                <Grid item onClick= { handleRedirectToHome }>
                    <ChevronLeft></ChevronLeft>
                </Grid>
                <Grid item >
                    <Typography variant="h6">
                        { constantsConfig.monthlySummary }
                    </Typography>
                </Grid>
            </Grid>
            <Grid 
                container 
                direction="row" 
                justifyContent="center" 
                alignItems="center" 
                mt={2}
            >
                <WeekDuration flag={"monthlySummary"}></WeekDuration>
            </Grid>
        </AppBar>
        </>
    )
}

export default MonthlySummaryAppbar;