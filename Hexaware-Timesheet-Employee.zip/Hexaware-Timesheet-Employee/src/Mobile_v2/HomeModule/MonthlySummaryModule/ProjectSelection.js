import React from "react";
import { useState } from "react";
import { Grid, Select, MenuItem, Typography } from '@mui/material';
import UnfoldMoreIcon from "@mui/icons-material/UnfoldMore";
import { constantsConfig } from "../Constants/ConstantsConfig"
import theme2 from "../../../theme2";

const ProjectSelection = () => {
  const styles = {
    gridItemSelect: {
      width: "100%",
      height: "40px",
    },
   
  }
  const [selectedValue, setSelectedValue] = useState("");
  return (
    <>
      <Grid
        container
        direction="row"
        justifyContent="center"
        alignItems="center"
      >
        <Grid item xs={10}>
          <Typography
            variant="subtitle2"
          >
            {constantsConfig.chooseProject}
          </Typography>
        </Grid>
        <Grid item
          xs={10}
          mt={1}
        >
          <Select
            value={selectedValue}
            onChange={(event) => setSelectedValue(event.target.value)}
            displayEmpty
            sx={styles.gridItemSelect}
            IconComponent={UnfoldMoreIcon}
          >
            <MenuItem value="" disabled>
              {constantsConfig.chooseProject}
            </MenuItem>
            <MenuItem >TimeSheet-STEP</MenuItem>
          </Select>
        </Grid>
      </Grid>
    </>
  )
}

export default ProjectSelection;