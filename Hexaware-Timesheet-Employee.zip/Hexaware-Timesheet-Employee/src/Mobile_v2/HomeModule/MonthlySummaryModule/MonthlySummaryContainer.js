import React from "react";
import { Grid } from '@mui/material';
import ProjectSelection from '../MonthlySummaryModule/ProjectSelection';
import MonthlySummaryCard from '../MonthlySummaryModule/MonthlySummaryCard';

const MonthlySummaryContainer = () => {
    const monthlySummaryData = [
        {
            week: "Jul 30 - Aug 5",
            totalHrs: "08:45",
            status: "Rejected"
        },
        {
            week: "Aug 6 - Aug 12",
            totalHrs: "35:15",
            status: "Approved"
        },
        {
            week: "Aug 13 - Aug 19",
            totalHrs: "43:45",
            status: "Defaulted"
        },
        {
            week: "Aug 20 - Aug 26",
            totalHrs: "08:45",
            status: "Submitted"
        },
        {
            week: "Aug 27 - Sep 2",
            totalHrs: "43:45",
            status: "Due For Submission"
        }
    ]
    return(
        <>
            <Grid 
                container 
                direction="row" 
                justifyContent="center" 
                alignItems="center" 
                mt={4}
            >
                <Grid item xs={12} mb={1}>
                    <ProjectSelection></ProjectSelection>
                </Grid>
                {monthlySummaryData && monthlySummaryData.map((item, i) => {
                    return(
                        <>
                            <Grid  item xs={12} m={1} key={i} >
                                <MonthlySummaryCard monthlySummaryCardData= {item} index={i}></MonthlySummaryCard>
                            </Grid>
                        </>
                    )
                })}
            </Grid>
        </>
    )
}
export default MonthlySummaryContainer;