import React from "react";
import { Grid } from '@mui/material';
import MonthlySummaryAppbar from "../MonthlySummaryModule/MonthlySummaryAppbar";
import MonthlySummaryContainer from "../MonthlySummaryModule/MonthlySummaryContainer";

const MonthlySummry = () => {
    return (
        <>
            <Grid 
                container 
                columns={1}    
            >
                <Grid item xs={8} my={2}>
                   <MonthlySummaryAppbar></MonthlySummaryAppbar>
                </Grid>
                <Grid mt={5} item >
                    <MonthlySummaryContainer></MonthlySummaryContainer>
                </Grid>
            </Grid>
        </>
    )
}
export default MonthlySummry;