import React from "react";
import { Grid } from '@mui/material';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';
import { constantsConfig } from "../Constants/ConstantsConfig";
import { statusConfig } from "../Constants/StatusConfig";

const MonthlySummaryCard = ({ monthlySummaryCardData, index}) => {
  var statusColor = statusConfig.statusColor.dueForSubmission;
  if(monthlySummaryCardData.status.toLowerCase() === "rejected"){
    statusColor = statusConfig.statusColor.rejected;
  }
  else if(monthlySummaryCardData.status.toLowerCase() === "approved"){
    statusColor = statusConfig.statusColor.approved;
  }
  else if(monthlySummaryCardData.status.toLowerCase() === "submitted"){
    statusColor = statusConfig.statusColor.submitted;
  }
  else if(monthlySummaryCardData.status.toLowerCase() === "due for submission"){
    statusColor = statusConfig.statusColor.dueForSubmission;
  }
  else if(monthlySummaryCardData.status.toLowerCase() === "defaulted"){
    statusColor = statusConfig.statusColor.defaulted;
  }
  const styles = {
    card: {
      height: "115px",
      background: statusColor,
      borderRadius: "0px 8px 8px 0px",
      borderLeft: "8px solid white"
    }
  }
  return (
    <>
      <Card sx= { styles.card } >
        <CardContent>
          <Grid
            container
            direction="column"
            justifyContent="flex-start"
            alignItems="flext-start"
          >
            <Grid item xs={12}>
              <Grid 
                container 
                direction="row" 
                alignItems="center" 
                justifyContent="space-between"
              >
                <Grid item>
                  <Typography variant="subtitle1" >
                    {constantsConfig.week} {index+1}
                  </Typography>
                </Grid>
                <Grid item>
                  <Typography variant="overline" align="right">
                    {monthlySummaryCardData.status}
                  </Typography>
                </Grid>
              </Grid>
            </Grid>
            <Grid item xs={4}>
              <Typography variant="caption">
                {monthlySummaryCardData.week}
              </Typography>
            </Grid>
          </Grid>
          <Grid
            container
            direction="row"
            justifyContent="flex-start"
            alignItems="flext-start"
          >
            <Grid item  xs={4}>
              <Typography variant="h4" >
                {monthlySummaryCardData.totalHrs}
              </Typography>
            </Grid>
            <Grid item >
              <Grid 
                container 
                direction="column" 
                alignItems="flex-start"
              >
                <Grid item>
                  <Typography variant="caption" >
                    {constantsConfig.filledHrs}
                  </Typography>
                </Grid>
                <Grid item >
                  <Typography variant="caption" >
                    {constantsConfig.outOf} {monthlySummaryCardData.totalHrs}
                  </Typography>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </CardContent>
      </Card>
    </>
  )
}

export default MonthlySummaryCard;