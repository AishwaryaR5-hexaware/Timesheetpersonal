import React from "react"
import { Grid, Typography, AppBar } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import { useNavigate } from "react-router-dom";
import { constantsConfig } from "../Constants/ConstantsConfig";
const Appbar = ({ title }) => {
    const styles = {
        appbar: {
            height: "100px"
        }
    }
    const navigate = useNavigate();
   
    const handleClose = () => {
        navigate("/home");
    }

    return (
        <>
        <AppBar
            position="fixed"
            sx= { styles.appbar }
        >
            <Grid
                container
                direction="row"
                alignItems="center"
                justifyContent="space-between"
                mt={4}
                px={4}
            >
                <Grid item >
                    <Typography variant="h6">
                     { title }
                    </Typography>
                </Grid>
                <Grid item >
                    <CloseIcon 
                        color="accent" 
                        fontSize="medium" 
                        onClick = { handleClose }
                    ></CloseIcon>
                </Grid>
            </Grid>
        </AppBar>
        </>
    )
}

export default Appbar;