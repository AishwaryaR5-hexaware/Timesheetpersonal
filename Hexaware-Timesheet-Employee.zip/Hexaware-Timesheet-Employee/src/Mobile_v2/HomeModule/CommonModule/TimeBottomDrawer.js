import React from "react";
import { Button, Drawer, Grid } from "@mui/material";

function TimeBottomDrawer({ value }) {
  const styles = {
    drawer: {
      ".MuiDrawer-paper": {
        backgroundColor: "background.bottomDrawer2",
        padding: "30px",
      },
    },
    button: {},
  };
  return (
    <>
      <Drawer
        sx={styles.drawer}
        variant="permanent"
        anchor="bottom"
        overflowX="hidden"
      >
        {value === "Modify Time" || value === "Apply WFH" ? (
          <Grid container direction={"row"}>
            <Grid item xs={4.8}>
              <Button variant="removeButton">Remove</Button>
            </Grid>
            <Grid item xs={7.2}>
              <Button variant="modifyButton">Modify</Button>
            </Grid>
          </Grid>
        ) : (
          <Button variant="drawerButton">
            {value === "Add Time" ? "Add" : "Modify"}
          </Button>
        )}
      </Drawer>
    </>
  );
}

export default TimeBottomDrawer;
