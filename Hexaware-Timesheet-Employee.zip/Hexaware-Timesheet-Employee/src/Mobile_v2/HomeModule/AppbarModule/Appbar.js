import { Grid, Typography, AppBar } from "@mui/material";
import CalendarMonthOutlinedIcon from "@mui/icons-material/CalendarMonthOutlined";
import WeekDuration from "./WeekDuration";
import { constantsConfig } from "../Constants/ConstantsConfig";
import { useNavigate } from "react-router-dom";
const Appbar = ({weeksObj,
  setWeeksObj,
  timezone,isLoading}) => {
  const styles = {
    gridItemImage: {
      height: "40px",
      width: "40px",
    },
    gridCalenderMonthOutlinedIcon: {
      textAlign: "right",
    },
    appbar: {
      height: "100px",
    },
  };
  const navigate = useNavigate();
  const handleCalenderClick = () => {
    navigate("/monthly-summary");
  };
  return (
    <>
      <AppBar position="fixed" sx={styles.appbar}>
        <Grid
          container
          direction="row"
          alignItems="flex-start"
          justifyContent="space-between"
          mt={2}
          px={3}
        >
          <Grid item>
            <img src="./timelogo.png" alt="logo" style={styles.gridItemImage} />
          </Grid>
          <Grid item>
            <Grid container direction="column" alignItems="center">
              <Grid item>
                <Typography variant="h6" align="center">
                  {constantsConfig.time}
                </Typography>
              </Grid>
              <Grid item mt={1}>
                <WeekDuration
                  flag={"home"}
                  weeksObj={weeksObj}
                  setWeeksObj={setWeeksObj}
                  timezone={timezone}
                  isLoading={isLoading}
                ></WeekDuration>
              </Grid>
            </Grid>
          </Grid>
          <Grid
            item
            sx={styles.gridCalenderMonthOutlinedIcon}
            onClick={handleCalenderClick}
          >
            <CalendarMonthOutlinedIcon></CalendarMonthOutlinedIcon>
          </Grid>
        </Grid>
      </AppBar>
    </>
  );
};

export default Appbar;
