import { Grid, IconButton, Typography } from '@mui/material';
import { ChevronLeft, ChevronRight } from "@mui/icons-material";
import { todayDate } from '../../utils/utils';

 
export function formatDate(timezone,date) {
  
  const response=todayDate(timezone,date);
  return `${response.month_str_short} ${response.date} `;
 }

const WeekDuration = ({ flag, weeksObj,
  setWeeksObj, timezone ,isLoading}) => {
  const styles = {
    gridContainer: {
      width: "200px",
      height: "26px",
      padding: "0px 6px 0px 6px",
      borderRadius: "20px",
      background: "linear-gradient(#393939 100%, #848484 0%)"
    },
    gridItem: {
      width: "180px",
      height: "26px",
      borderRadius: "20px",
      background: "linear-gradient(185.81deg, #393939 11.6%, rgba(57, 57, 57, 0) 133.23%),linear-gradient(0deg, #3E3F3F, #3E3F3F)",
      border: "2px solid #3E3F3F",
      textAlign: "center",
      paddingTop: "2px",
    },
    disabledchevron: {
      display: 'none',
      pointerEvents: 'none', 
    },
    enablechevron: {
      display: 'inline-block', 
      pointerEvents: 'auto',
    }
    

  }

  const weekKeys = Object.keys(weeksObj.weeks);
  const currentWeekIndex = weekKeys.indexOf(weeksObj.currentWeek);
 

  const currentWeekDate = () => {
    if (weeksObj.weeks && weeksObj.currentWeek) {
      return `${formatDate(timezone, weeksObj.weeks[weeksObj.currentWeek]?.startDate)} - ${formatDate(timezone,
        (weeksObj.weeks[weeksObj.currentWeek]?.endDate))}`;
    }
    // return `${formatDate(weeks[currentWeek].startDate)} - ${formatDate( weeks[currentWeek].endDate)}`;
  };

  const previousWeekChange = () => {
    if (currentWeekIndex > 0) {
      const nextWeekKey = weekKeys[currentWeekIndex - 1];
      setWeeksObj((prevWeeksObj) => ({
        ...prevWeeksObj, // Keep the previous state properties unchanged
        currentWeek: nextWeekKey // Update the currentWeek with the new value
      }));
      // updateCurrentWeek(nextWeekKey);
    }
  };

  const nextWeekChange = () => {
    if (currentWeekIndex < weekKeys.length - 1) {
      const nextWeekKey = weekKeys[currentWeekIndex + 1];
      setWeeksObj((prevWeeksObj) => ({
        ...prevWeeksObj, // Keep the previous state properties unchanged
        currentWeek: nextWeekKey // Update the currentWeek with the new value
      }));
      // updateCurrentWeek(nextWeekKey);
    }
  };


  const previousButton = () => {
    if (flag === "home") {
      previousWeekChange();
    }
  };

  const nextButton = () => {
    if (flag === "home") {
      nextWeekChange();
    }
  };
// console.log("loadd",isLoading)
  return (
    <>
      <Grid
        container
        direction="row"
        alignItems="center"
        justifyContent="space-between"
        sx={styles.gridContainer}
        columns={16}
      >
        <Grid item xs={2} >
          {/* <IconButton
            onClick={previousButton}
            disabled={currentWeekIndex === 0}
          > */}
            <ChevronLeft
            onClick={previousButton}
            disabled={currentWeekIndex === 0}
              style={
                (currentWeekIndex === 0 || isLoading)?styles.disabledchevron:styles.enablechevron
              }
            />
          {/* </IconButton> */}
        </Grid>
        {flag === "home" ?
          <Grid item xs={12} sx={styles.gridItem}  >
            <Typography variant="body1">{currentWeekDate()}</Typography>
          </Grid>
          :
          <Grid item xs={12} sx={styles.gridItem}  >
            <Typography variant="body1" >August 2023</Typography>
          </Grid>
        }
        <Grid item xs={2} >
          {/* <IconButton ** might need to implement icon button in future 
            onClick={nextButton}
            disabled={currentWeekIndex === weekKeys.length - 1}
          > */}
            <ChevronRight
            onClick={nextButton}
            disabled={currentWeekIndex === weekKeys.length - 1}

              style={
                (currentWeekIndex === weekKeys.length - 1 ||isLoading)?styles.disabledchevron:styles.enablechevron

              }
            />
          {/* </IconButton> */}
        </Grid>
      </Grid>
    </>
  )
}

export default WeekDuration;