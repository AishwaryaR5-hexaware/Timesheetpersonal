import React from 'react';
import { Typography, Grid } from "@mui/material";
import {statusConfig} from "../Constants/StatusConfig";
const StatusBar = ({ status }) => {
    const styles = {
        gridItemContainer: {
            height: "20px",
        }
    }
    return (
        <Grid
            justifyContent="center"
            container
            direction="row"
            sx= { styles.gridItemContainer }
            alignItems="center"
            backgroundColor = {statusConfig.statusColor.dueForSubmission}
        >
            <Typography variant="caption">
                {status}
              </Typography>
        </Grid>
    )
}

export default StatusBar;