import { Button, Drawer, Typography, Grid } from "@mui/material";
import React, { useContext, useState, useEffect } from "react";
import StatusBar from "./StatusBar";
import {statusConfig} from "../Constants/StatusConfig";
import {constantsConfig} from "../Constants/ConstantsConfig";
import theme2 from "../../../theme2";
import TasksContext from "../../Context/TasksContext";
import BottomDrawerSkeleton from "../../SkeletonComponent/BottomDrawerSkeleton";

const BottomDrawer = ({isLoading}) => {
  const styles = {
    gridItemSaveDraftButton: {
      padding: "12px 35px 12px 35px",
      borderRadius: "5px",
      textTransform: "capitalize",
    },
    gridItemSubmitButton: {
      padding: "12px 50px 12px 50px",
      borderRadius: "5px",
      textTransform: "capitalize",
    },
    gridItemBottomMsg: {
      height: "20px",
      backgroundColor: theme2.palette.common.white
    },
   
  }

  const tasksData = useContext(TasksContext); 
  const getAPI = tasksData.state;
  const [getTime, setGetTime] = useState("");

  const timeToMinutes = (hours, minutes) => {
    const totalMinutes = hours * 60 + minutes;
    return totalMinutes;
  }

  const formatTime = (totalMinutes) => {
    const hours = Math.floor(totalMinutes / 60);
    const minutes = totalMinutes % 60;
    return `${hours}:${minutes}`;
  };

  const timeCalculation = () => {
    let totalHours = 0;
    let totalMinutes = 0;
    let totalStandardHours = 0;
    let totalStandardMinutes = 0;

    for (const date in getAPI) {
      if (getAPI.hasOwnProperty(date)) {
        const tasks = getAPI[date];
        for (const p of tasks) {
          totalHours += p.timesheet_task_hours;
          totalMinutes += p.timesheet_task_minutes;
          totalStandardHours += p.standard_hours;
          totalStandardMinutes += p.standard_minutes;
        }
      }
    }

    const totalTaskTime = timeToMinutes(totalHours, totalMinutes);
    const totalStandardTime = timeToMinutes(totalStandardHours, totalStandardMinutes);
    return {totalTaskTime:totalTaskTime, totalStandardTime:totalStandardTime};
  };

  useEffect(() => {
    const { totalTaskTime, totalStandardTime } = timeCalculation();
    setGetTime(formatTime(totalTaskTime));
  },[])

  return (
    <>
    {isLoading?<BottomDrawerSkeleton/>:
      <Drawer  variant="permanent" anchor="bottom" overflowX= "hidden">
        <Grid
          container
          direction="row"
          justifyContent="center"
          alignItems="center"
        >
          <StatusBar status= {statusConfig.statusMessage.dueForSubmission} ></StatusBar>
          <Grid
            container
            direction="row"
            justifyContent="space-between"
            alignItems="center"
            px={2}
            mt={1}
          >
            <Grid item >
              <Typography
                variant="body2"
              >
                {constantsConfig.netHours}
              </Typography>
            </Grid>
            <Grid item >
              <Typography
                variant="h6"
              >
                 {getTime} Hrs
              </Typography>
            </Grid>
          </Grid>
          <Grid
            container
            direction="row"
            justifyContent="space-evenly"
            alignItems="center"
            mt={1}
          >
            <Grid item>
              <Button
                variant="contained"
                sx={styles.gridItemSaveDraftButton}
                color="secondary"
              >
                {constantsConfig.saveDraft}
              </Button>
            </Grid>
            <Grid item>
              <Button
                variant="contained"
                sx={styles.gridItemSubmitButton}
              >
                {constantsConfig.submit}
              </Button>
            </Grid>
          </Grid>
          <Grid
            container
            justifyContent="center"
            alignItems="center"
            sx= { styles.gridItemBottomMsg }
            mt={2}
          >
            <Typography variant="caption" color= "primary">
              {constantsConfig.dhrMessage}
            </Typography>
          </Grid>
        </Grid>
      </Drawer>
}
    </>
  );
};

export default BottomDrawer;
