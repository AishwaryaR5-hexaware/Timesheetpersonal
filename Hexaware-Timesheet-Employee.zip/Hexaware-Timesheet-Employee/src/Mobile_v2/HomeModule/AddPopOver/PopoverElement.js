import React from "react";
import {
  Grid,
  Box,
  Typography,
  Button,
  Popover,
  Fab,
  Divider,
  MenuList,
  MenuItem,
  ListItemText,
  ListItemIcon,
  Paper,
  Backdrop,
} from "@mui/material";
import AddRoundedIcon from "@mui/icons-material/AddRounded";
import ControlPointRoundedIcon from '@mui/icons-material/ControlPointRounded';
import theme2 from "../../../theme2";
import { useNavigate } from "react-router-dom";

function PopoverElement() {
  const styles = {
    circle: {
      width: "45px",
      height: "45px",
      position: "fixed",
      right: "20",
      bottom: "190",
    },
    
  };
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [showBackdrop, setShowBackdrop] = React.useState(false);
  const [fabColor, setFabColor] = React.useState("primary");
  const navigate = useNavigate();

  const handleMenuClick = (Menu) =>{
    navigate(`/${Menu}`)
  };

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
    setShowBackdrop(true); // Show the backdrop when the popover is opened
    setFabColor("primary")
  };

  const handleClose = () => {
    setAnchorEl(null);
    setShowBackdrop(false); // Hide the backdrop when the popover is closed
    setFabColor("common.black")
  };
  
  /**START of Redirect to comments page function */
  const handleClickComments = () => {
    navigate("/comments");
  }
  /**END of Redirect to comments page function */

  const open = Boolean(anchorEl);
  const id = open ? "simple-popover" : undefined;
  return (
    <>
      {/* {showBackdrop && <div style={styles.backdrop}></div>} */}
      <Backdrop
        sx={{  opacity:'0.5', zIndex: (theme) => theme.zIndex.drawer + 1 }}
        open={showBackdrop}
        onClick={handleClose}
       
      ></Backdrop>

      <Box style={styles.circle}>
       
        <Fab color={'common.white'}>
          <Typography onClick={handleClick}>
            <AddRoundedIcon
              fontSize="large"
              sx={{ color: "icon.add" }}
            ></AddRoundedIcon>
          </Typography>
        </Fab>
        
        <Popover
          id={id}
          open={open}
          anchorEl={anchorEl}
          onClose={handleClose}
          PaperProps={{
            style: {
              backgroundColor: "transparent",
              boxShadow: "none",
              display: "flex",
              flexDirection: "row-reverse",
              justifyContent: "right",
              alignItems: "center",
              borderRadius: "2px",
              paddingBottom: "9px",
              height: "158px",
              backgroundImage: "none",
            },
          }}
          anchorOrigin={{
            vertical: "top",
            horizontal: "right",
          }}
          transformOrigin={{
            vertical: "bottom",
            horizontal: "right",
          }}
        >
          <Paper variant="popOver">
            <MenuList disablePadding={true}>
              <MenuItem onClick={() => handleMenuClick("add-time")}>
                <ListItemIcon>
                  <img src="./AddTime.svg"></img>
                </ListItemIcon>
                <ListItemText
                  primary="Add Time"
                  primaryTypographyProps={{ variant: "body13" }}
                />
              </MenuItem>
            </MenuList>
            <Divider></Divider>
            <MenuList disablePadding={true}>
              <MenuItem onClick={() => handleMenuClick("apply-wfh")}>
                <ListItemIcon>
                  <img src="./wfh.png" height={29}></img>
                </ListItemIcon>
                <ListItemText
                  primary="WFH"
                  primaryTypographyProps={{ variant: "body13" }}
                />
              </MenuItem>
            </MenuList>
            <Divider></Divider>
            <MenuList disablePadding={true}>
              <MenuItem onClick= { handleClickComments }>
                <ListItemIcon>
                  <img src="./Comments.svg"></img>
                </ListItemIcon>
                <ListItemText
                  primary="Comments"
                  primaryTypographyProps={{ variant: "body13" }}
                />
              </MenuItem>
            </MenuList>
          </Paper>
        </Popover>
      </Box>
    </>
  );
}

export default PopoverElement;
