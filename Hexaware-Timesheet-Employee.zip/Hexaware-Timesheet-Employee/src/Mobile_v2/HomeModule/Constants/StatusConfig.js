export const statusConfig = {
    statusMessage:{
        dueForSubmission:"DUE FOR SUBMISSION",
        rejected: "REJECTED",
        approved: "APPROVED",
        defaulted: "DEFAULTED",
        submitted: "SUBMITTED",
        adjApproved: "ADJ-APPROVED",
        adjRejected: "ADJ-REJECTED",
        lateSubmission: "LATE SUBMISSION",
    },
    statusColor:{
        dueForSubmission:"#CE740A",
        rejected: "#83352A",
        approved: "#137558",
        defaulted: "#812E9E",
        submitted: "#515FB4",
        adjApproved: "#137558",
        adjRejected: "#83352A",
        lateSubmission: "#CE970A",
    }
};