import React from 'react'
import { Grid, Typography, Slider } from "@mui/material";

function HrMinSliders({ onHrSliderChange, onMinSliderChange }) {
    const [hrValueSlider, setHrValueSlider] = React.useState(0);
    const [minValueSlider, setMinValueSlider] = React.useState(0);

    const handleHrSliderChange = (event, newValue) => {
        setHrValueSlider(newValue);
        onHrSliderChange(newValue); // Call the hour callback with the new value
    };

    const handleMinSliderChange = (event, newValue) => {
        setMinValueSlider(newValue);
        onMinSliderChange(newValue); // Call the minute callback with the new value
    };

  return (
    <Grid
    container
    direction={"column"}
    px={3}
    pt={3}
  >
    <Grid item >
      <Grid
        container
        direction={"row"}
        alignItems={"center"}
      >
        <Grid item xs={2.5}>
          <Typography
            color='common.colonColor'
            variant="body2"
          >
            Hrs
          </Typography>
        </Grid>
        <Grid item xs={9.5}>
          <Slider
            step={1}
            marks={false}
            min={0}
            max={23}
            value={hrValueSlider}
            onChange={handleHrSliderChange}
            valueLabelDisplay="auto"
          />
        </Grid>
      </Grid>
    </Grid>
    <Grid item >
      <Grid
        container
        direction={"row"}
        alignItems={"center"}
      >
        <Grid item xs={2.5}>
          <Typography
             color='common.colonColor'
            variant="body2"
          >
            Mins
          </Typography>
        </Grid>
        <Grid item xs={9.5}>
          <Slider
            step={15}
            marks={false}
            min={0}
            max={45}
            value={minValueSlider}
            onChange={handleMinSliderChange}
            valueLabelDisplay="auto"
          />
        </Grid>
      </Grid>
    </Grid>
  </Grid>
  )
}

export default HrMinSliders