import { Box } from '@mui/material';
import React from 'react'

const HrMinBox = ({ value }) => {

  const styles ={
    boxStyle: {
      width: `80px`,
      height: "79px",
      backgroundColor: "background.hrMinBox",
      color: "common.white",
      border: "1px solid #A4B1E5",
      borderRadius: "6px",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      fontSize: "50px",
      fontWeight: "500",
    }
  }
    const formattedValue = value < 10 ? `0${value}` : value;

  return (
  
  <Box sx={styles.boxStyle}>
    {formattedValue}
  </Box>
    
  )
}

export default HrMinBox