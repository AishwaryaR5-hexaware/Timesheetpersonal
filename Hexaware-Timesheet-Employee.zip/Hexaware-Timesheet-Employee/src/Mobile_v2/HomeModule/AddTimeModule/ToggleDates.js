import React from "react";
import ToggleButton from "@mui/material/ToggleButton";
import ToggleButtonGroup from "@mui/material/ToggleButtonGroup";
import { Box, Grid, Typography} from "@mui/material";

function ToggleDates() {
  const styles = {
    toggleButtonGroup: {
      borderRadius: "5px",
      display: 'flex',
      justifyContent: 'space-between',
    },
    toggleButton: {
      "&:hover": {
        backgroundColor: "common.card",
      },
      "&:hover.Mui-selected": {
        backgroundColor: "common.white", 
      },
      "&.Mui-selected": {
        backgroundColor: "common.white",
      },
    },
    box: {
      width: 40,
      height: 55,
      borderRadius: "5px",
    },
  }
  const [index, setIndex] = React.useState(() => []);
  const dates = ["1", "2", "3", "4", "31", "23", "16"];

  const handleIndex = (event, newIndex) => {
    console.log("newindex", newIndex);
    setIndex(newIndex);
  };
  return (
    <>
      <Typography >Choose one or more dates</Typography>
      <ToggleButtonGroup
        value={index}
        onChange={handleIndex}
        spacing={1}
        sx={styles.toggleButtonGroup}
      >
        {dates.map((date) => (
          <ToggleButton
            value={date}
            aria-label="text formatting"
            sx={styles.toggleButton}
          >
            <Box
              sx={styles.box}
            >
              <Grid container direction={"column"} >
                <Grid item > 
                  <Typography variant="toggleDate" color={'text.dropdown'}>{date}</Typography>
                </Grid>
                <Grid item >
                  <Typography variant="toggleDay" color={'text.dropdown'}>sun</Typography>
                </Grid>
              </Grid>
            </Box>
          </ToggleButton>
        ))}
      </ToggleButtonGroup>
    </>
  );
}

export default ToggleDates;
