import { Card, CardContent, Grid, Toolbar, Typography } from '@mui/material';
import { Container } from '@mui/system';
import React from 'react'
import Appbar from '../CommonModule/Appbar';
import TimeBottomDrawer from '../CommonModule/TimeBottomDrawer';
import { constantsConfig } from '../Constants/ConstantsConfig';
import ToggleDates from './ToggleDates';

function ApplyWfh() {
    const styles = {
        card: {
            backgroundColor: 'common.card',
            borderRadius: '7px',
        },
        quotes1: {
            paddingBottom:'6px', 
            paddingRight: '2px',
        },
        qoutes2: {
            position:'absolute', 
            paddingTop:'11px', 
            paddingLeft: '4px'
        }
    }
    const title = constantsConfig.applyWFH;
  return (
    <Container>
        <Appbar title={title}></Appbar>
        <Toolbar></Toolbar>
        <Grid 
            container 
            direction={'column'}
            my={5}
        >
            <Grid item mb={4}>
                <ToggleDates></ToggleDates>
            </Grid>
            <Grid item textAlign={'center'}>
                <Card sx={styles.card} >
                    <CardContent >
                    <img style={styles.quotes1} src='quotes1.png' alt='"'></img>
                        <Typography variant='body8'>
                        Distance is no match for 
                        <br />
                        determination when you work 
                        <br />from the heart of your home.
                        </Typography>
                        <img style={styles.qoutes2} src='quotes2.png' alt='"'></img>
                        
                    </CardContent>
                </Card>
            </Grid>
            <Grid item textAlign={'center'}>
                <img src="./wfhimage.png"></img>
            </Grid>
        </Grid>
        <TimeBottomDrawer value={title}></TimeBottomDrawer>
    </Container>
  )
}

export default ApplyWfh
