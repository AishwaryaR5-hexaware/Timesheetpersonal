import React, { useState } from "react";
import { Grid, Typography, Select, MenuItem,Toolbar } from "@mui/material";
import Appbar from "../CommonModule/Appbar";
import { constantsConfig } from "../Constants/ConstantsConfig";
import UnfoldMoreIcon from "@mui/icons-material/UnfoldMore";
import ToggleDates from "./ToggleDates";
import HrMinBox from "./HrMinBox";
import HrMinSliders from "./HrMinSliders";
import { Container } from "@mui/system";
import TimeBottomDrawer from "../CommonModule/TimeBottomDrawer";

function AddTime() {
  const styles = {
    gridItemSelect: {
      width: "100%",
      height: "40px",
    },
  
  };

  const [selectedValue, setSelectedValue] = useState("");
  const [hrValue, setHrValue] = useState(0); // State for hours
  const [minValue, setMinValue] = useState(0); // State for minutes
  const title = constantsConfig.addTime;
  const handleHrSliderChange = (value) => {
    setHrValue(value);
  };

  const handleMinSliderChange = (value) => {
    setMinValue(value);
  };

  return (
    <Container >
     
      <Appbar title={title}></Appbar>
      <Toolbar></Toolbar>
      <Grid
        container
        direction="column"
        my={5}
      >
        <Grid item mb={3} >
          <ToggleDates></ToggleDates>
        </Grid>

        <Grid item
          container
          direction="column"      
        >
          <Grid item >
            <Typography variant="subtitle2">
              {constantsConfig.chooseTask}
            </Typography>
          </Grid>
          <Grid item  mt={1}>
            <Select
              value={selectedValue}
              onChange={(event) => setSelectedValue(event.target.value)}
              displayEmpty
              sx={styles.gridItemSelect}
              IconComponent={UnfoldMoreIcon}
            >
              <MenuItem value="" disabled>
                {constantsConfig.chooseTask}
              </MenuItem>
              <MenuItem></MenuItem>
            </Select>
          </Grid>
        </Grid>

        <Grid container direction={"column"} alignItems={"center"} mt={2}>
          <Grid item>
            <Typography
               variant='addTime'
                color= "common.colonColor"
            >
              {constantsConfig.addTime}
            </Typography>
          </Grid>
          <Grid item mt={1}>
            <Grid container direction={"row"}
            justifyContent={'center'} 
            alignItems={'center'}>
              <Grid item  >
                <HrMinBox value={hrValue} ></HrMinBox>
              </Grid>
              <Grid item mx={1}  >
                <Typography
                  variant="colonText"
                  color={'common.colonColor'}
                >
                  :
                </Typography>
              </Grid>
              <Grid item  >
                <HrMinBox value={minValue} ></HrMinBox>
              </Grid>
            </Grid>
          </Grid>

          <HrMinSliders
            onHrSliderChange={handleHrSliderChange}
            onMinSliderChange={handleMinSliderChange}
          ></HrMinSliders>

          <Grid item>
            <Grid
              container
              pt={2.5}
            >
              <Grid item mr={3}>
                <Typography variant="body6" color={'common.colonColor'}>
                  <span>Net Hrs</span>{" "}
                </Typography>
                <Typography variant="body7" color={'common.colonColor'}>
                  <span>{"9.15"}</span>
                </Typography>
              </Grid>

              <Grid item>
                <Typography variant="body6" color={'common.colonColor'}>
                  <span>Standard Hrs</span>{" "}
                </Typography>
                <Typography variant="body7" color={'common.colonColor'}>
                  <span>{"9.15"}</span>
                </Typography>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
      <TimeBottomDrawer value={title}></TimeBottomDrawer>
    </Container>
  );
}

export default AddTime;
