import React, { useContext } from "react";
import Appbar from "./AppbarModule/Appbar";
import { Grid, Box, Typography, Button, Popover, Fab, Divider, Container } from "@mui/material";
import BottomDrawer from "./BottomDrawerModule/BottomDrawer";
import ProjectListModule from "./ProjectListModule/ProjectListModule";
import AddRoundedIcon from "@mui/icons-material/AddRounded";
import PopoverElement from "./AddPopOver/PopoverElement";
import { useGetEmployeeId } from "../services/Profile";
import {  useTimeZone } from "../services/Tasks";
import { useAllTasks } from "../utils/useAllTasks";

const Home = ({weeksObj,
  setWeeksObj,
  timezone,isLoading}) => {

  return (
    <>
      <Grid container spacing={1} columns={1}  >
        <Grid item xs={2} m={5}>
          <Appbar 
           weeksObj={weeksObj}
           setWeeksObj={setWeeksObj}
           timezone={timezone}
           isLoading={isLoading}
          ></Appbar>
        </Grid>
        <Grid
          item
          xs={8}
          style={{ overflow: "auto", maxHeight: "calc(100vh - 240px)", paddingTop: "15px"}}
        >
          <ProjectListModule  timezone={timezone} isLoading={isLoading}></ProjectListModule>
        </Grid>

        <Grid item xs={2} style={{paddingTop: "15px"}}>
          <BottomDrawer isLoading={isLoading}></BottomDrawer>
        </Grid>
      </Grid>
     <PopoverElement></PopoverElement>
    </>
  );
};

export default Home;
