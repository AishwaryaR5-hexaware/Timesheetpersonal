import React, { useState, useContext } from "react";
import { Grid, Typography } from "@mui/material";
import DateTask from "./DateTask";
import { constantsConfig } from "../Constants/ConstantsConfig";
import TasksContext from "../../Context/TasksContext";
import HomeScreenSkeleton from "../../SkeletonComponent/HomeScreenSkeleton"

function ProjectListModule({ timezone ,isLoading}) {
  const tasksData = useContext(TasksContext); 
  const getAPI = tasksData.state;
 
  const transformedData = Object.keys(getAPI).map((date) => ({
    date,
    tasks: getAPI[date],
  }));

  return (
    <>
    {isLoading?<HomeScreenSkeleton/>:
    <Grid container direction="row" alignItems="center" mt={1}>
      <Grid item xs={12}>
        <Grid
          container
          direction="row"
          justifyContent="space-between"
          alignItems="center"
          px={2}
          columns={16}
        >
          <Grid item xs={3}>
            <Typography variant="body5" color={"common.faintGrey"}>
              {constantsConfig.date}
            </Typography>
          </Grid>

          <Grid item xs={9.2}>
            <Typography variant="body5" color={"common.faintGrey"}>
              {constantsConfig.projectAllocations}
            </Typography>
          </Grid>
          <Grid item xs={2.6}>
            <Typography variant="body5" color={"common.faintGrey"}>
              {constantsConfig.hrsMins}
            </Typography>
          </Grid>
        </Grid>
      </Grid>
      <Grid
        container
        direction="row"
        alignItems="flex-start"
        justifyContent="space-between"
      >
        {transformedData.map((dateItem, getAPIIndex) => (
          <React.Fragment key={getAPIIndex}>
            <DateTask
              date={dateItem.date}
              tasks={dateItem.tasks}
              timezone={timezone}
            ></DateTask>
          </React.Fragment>
        ))}
      </Grid>
    </Grid>
}
    </>
  );
}

export default ProjectListModule;
