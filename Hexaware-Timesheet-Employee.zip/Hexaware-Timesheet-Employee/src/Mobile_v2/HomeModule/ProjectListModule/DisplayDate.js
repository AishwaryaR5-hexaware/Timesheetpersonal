import React from "react";
import { Grid, Typography } from "@mui/material";
import { todayDate } from '../../utils/utils'

function DisplayDate({ date, timezone }) {

  function getDay(inputDate) {
    const dateObj = todayDate(timezone, inputDate);
    return dateObj.day;
    
  }

  return (
    <Grid
      container
      direction="column"
      alignItems="center"
      justifyContent="center"
    >
      <Grid item
       height={28}
      >
        <Typography  variant="h7">
          {date.slice(8,10)}
        </Typography>
      </Grid>
      <Grid item mt={'3px'}>
        <Typography variant="subtitle2">{getDay(date)}</Typography>
      </Grid>
    </Grid>
  );
}

export default DisplayDate;
