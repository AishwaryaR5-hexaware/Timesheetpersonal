import React from "react";
import { Grid, Typography, Button } from "@mui/material";
import PrimaryProject from "./PrimaryProject";
import Holiday from "./Holiday";

function TaskCard({ task, taskIndex }) {
  const truncateText = (text, maxLength) => {
    if (text.length > maxLength) {
      return text.substring(0, maxLength) + "..";
    }
    return text;
  };

  const isLeave = (task) => {
    // console.log("isProjectRejected", p);
    if (task.timesheet_task_type?.toLowerCase() === "leave/pto") {
      return true;
    } else {
      return false;
    }
  };

  const handleTaskType = (task) => {
    if (task.timesheet_task_type.toLowerCase() === "billing") {
      return task.project_id;
    } else {
      if (task?.leave_type?.toLowerCase() === "optional holiday") {
        return task?.leave_type?.toUpperCase();
      } else {
        return task.timesheet_task_type.toUpperCase();
      }
    }
  };

  return (
    <React.Fragment>
      <Grid
        container
        direction="row"
        justifyContent="center"
        mb={1}
        pl={2}
        pr={1}
        py={1}
        backgroundColor={"common.card"}
        borderRadius={"8px"}
        key={taskIndex}
      >
        <Grid item xs={9.5}>
          <Grid container direction="column" justifyContent="space-evenly">
            <Grid item container direction="row" alignContent="end">
              <Grid item>
                <Typography color={"projectAndTime.main"} variant="body3">
                  {handleTaskType(task)}
                </Typography>
              </Grid>
              {task.primary_project === "Y" ? (
                <Grid item ml={"0.375rem"}>
                  <PrimaryProject></PrimaryProject>
                </Grid>
              ) : (
                <></>
              )}
              {task.is_holiday === 1 ? (
                <Grid item ml={"0.375rem"}>
                  <Holiday></Holiday>
                </Grid>
              ) : (
                <></>
              )}
            </Grid>
            <Grid item>
              <Typography variant="body4">
                {truncateText(task.project_name, 25)}
              </Typography>
            </Grid>
          </Grid>
        </Grid>
        <Grid
          item
          container
          xs={2.5}
          justifyContent="right"
          alignItems="flex-end"
        >
          <Button disabled={isLeave(task)}>
            <Typography
              variant="body2"
              align={"center"}
              color={"projectAndTime.main"}
            >
              {task.timesheet_task_hours < 10
                ? `0${task.timesheet_task_hours}`
                : task.timesheet_task_hours}
              :
              {task.timesheet_task_minutes < 10
                ? `0${task.timesheet_task_minutes}`
                : task.timesheet_task_minutes}{" "}
            </Typography>
          </Button>
        </Grid>
      </Grid>
    </React.Fragment>
  );
}

export default TaskCard;
