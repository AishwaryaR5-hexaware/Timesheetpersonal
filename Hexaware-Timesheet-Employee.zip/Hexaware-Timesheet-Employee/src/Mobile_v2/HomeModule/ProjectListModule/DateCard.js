import React from "react";
import { Box } from "@mui/material";
import DisplayDate from "./DisplayDate";
import theme2 from "../../../theme2";
function DateCard({ date, tasks, timezone }) {
  const styles = {
    trapezoid: {
      width: "69px",
      height: "80px",
      background: theme2.palette.common.card,
      clipPath: "polygon(0% 0%, 100% 11%, 100% 89%, 0% 100%)",
      display: "flex",
      justifyContent: "center",
      alignItems: "center",
      fontWeight: "bold",
      borderRadius: "0 18px 18px 0",
    },
    overriddenPentagon: {
      position: "relative",
      width: "55%",
      height: "60%",
      backgroundImage: "url('./Vector25.svg')",
      backgroundSize: "cover",
    },
    noWorkFromHome: {
      position: "relative",
      width: "53%",
      height: "58%",
    },
    
  };
  return (
    <Box style={styles.trapezoid}>
      {tasks[0].is_wfh === 1 ? (
        <Box sx={styles.overriddenPentagon}>
          <DisplayDate date={date} timezone={timezone}/>
        </Box>
      ) : (
        <Box sx={styles.noWorkFromHome}>
          <DisplayDate date={date} timezone={timezone}/>
        </Box>
      )}
      
    </Box>
  );
}

export default DateCard;
