import React from 'react'
import { Box, Typography } from "@mui/material";
import theme2 from '../../../theme2';
function Holiday() {

    const styles = {
        circle: {

            width: '14px',
            height: '14px',
            backgroundColor: theme2.palette.secondary.contrastText,
            borderRadius: '50%', /* Create a circular shape */
            marginTop: '2px',
            paddingTop: '1px',
        },
       
    }
    return (
        <>
            <Box style={styles.circle}>
                <Typography variant="primaryProject"
                color={'common.white'}
                paddingLeft= "0.25rem"
                >H</Typography>
            </Box>
        </>
    )
}

export default Holiday