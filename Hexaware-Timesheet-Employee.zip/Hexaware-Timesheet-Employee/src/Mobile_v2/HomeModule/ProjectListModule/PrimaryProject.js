import React from "react";
import { Box, Typography } from "@mui/material";
import theme2 from "../../../theme2";
function PrimaryProject() {
  const styles = {
    circle: {
      width: "14px",
      height: "14px",
      backgroundColor: theme2.palette.common.faintGreen,
      borderRadius: "50%" /* Create a circular shape */,
      marginTop: "2px",
      paddingTop: "1px",
    },
  };
  return (
    <>
      <Box style={styles.circle}>
        <Typography
          variant="primaryProject"
          paddingLeft="0.25rem"
          color="common.black"
        >
          P
        </Typography>
      </Box>
    </>
  );
}

export default PrimaryProject;
