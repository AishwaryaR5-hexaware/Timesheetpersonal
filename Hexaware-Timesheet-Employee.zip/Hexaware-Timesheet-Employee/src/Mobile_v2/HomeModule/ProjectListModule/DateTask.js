import React from "react";
import { Grid } from "@mui/material";
import DateCard from "./DateCard";
import TaskCard from "./TaskCard";

function DateTask({ date, tasks, timezone }) {
  return (
    <Grid
      item
      container
      direction="row"
      justifyContent="space-between"
      alignItems="self-start"
      my={1}
    >
      <Grid item xs={2.6}>
        <DateCard date={date} tasks={tasks} timezone={timezone}></DateCard>
      </Grid>

      <Grid item xs={9.4} container direction="column" mt={0.5} pr={1}>
        {tasks.map((task, taskIndex) => (
          <TaskCard task={task} taskIndex={taskIndex}></TaskCard>
        ))}
      </Grid>
    </Grid>
  );
}

export default DateTask;
