import { useState, useEffect } from "react";
import TasksContext from "./TasksContext";

const TasksState = (props) => {
    const [ state, setState ] = useState({});
    useEffect(() => {
        setState(props.data)
    }, [props.data])
   
    const update = (newValue) => {
        setState( (prevState) => ({...prevState, ...newValue}))
    };
    
    return (
        <TasksContext.Provider value= {{ state, update }}>
            { props.children }
        </TasksContext.Provider>
    )
 }

 export default TasksState;