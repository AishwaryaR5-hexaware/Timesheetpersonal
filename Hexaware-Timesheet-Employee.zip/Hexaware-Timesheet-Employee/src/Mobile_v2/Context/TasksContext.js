import React from 'react';
const TasksContext = React.createContext();
export default TasksContext;