import React from "react";
import Skeleton from "@mui/material/Skeleton";
import { Grid } from "@mui/material";

const HomeScreenSkeleton = () => {
  return (
    <>
      <Grid container direction="row" alignItems="center" mt={1} >
        {Array(7)
          .fill()
          .map((item, index) => (
            <React.Fragment key={index}>
              <Grid item xs={2.6} key={index}>
                <Grid
                  container
                  direction="row"
                  justifyContent="space-between"
                  alignItems="center"
                  px={2}
                  columns={16}
                >

                  <Skeleton
                    duration={2}
                    animation="wave"
                    variant="rectangular"
                    width={"200px"}
                    height={"70px"}
                    style={{ marginBottom: "20px", width: '150% ' }}
                  />

                </Grid>
              </Grid>
              <Grid xs={9.4}>
                <React.Fragment>
                  <Grid
                    container
                    direction="row"
                    justifyContent="center"
                    mb={1}
                    pl={2}
                    pr={1}
                    py={1}
                    backgroundColor={"common.card"}
                    borderRadius={"8px"}
                    key={index}
                  >

                    <Grid container direction="column" justifyContent="space-evenly">
                      <Grid item container direction="row" alignContent="end">
                        <Skeleton
                          duration={2}
                          animation="wave"
                          variant="rectangular"
                          // width={"75px"}
                          height={"30px"}
                          style={{ width: "70%", marginTop: "3px" }}
                        />
                      </Grid>

                    </Grid>


                  </Grid>
                </React.Fragment>
              </Grid>
            </React.Fragment>
          ))}
      </Grid>
    </>
  );
};

export default HomeScreenSkeleton;
