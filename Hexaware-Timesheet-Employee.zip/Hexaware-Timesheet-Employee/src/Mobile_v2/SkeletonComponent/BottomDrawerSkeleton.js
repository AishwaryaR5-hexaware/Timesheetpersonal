import React from "react";
import Skeleton from "@mui/material/Skeleton";
import {  Grid } from "@mui/material";
const BottomDrawerSkeleton = () => {
  return (
    <>
    

      <Grid
          container
          direction="row"
          justifyContent="center"
          alignItems="center"
        >
            {/* <Grid container item xs={12} justifyContent='center' mb={2}>
          <Skeleton
            duration={2}
            animation="wave"
            variant="rounded"
            height={"40px"}
            style={{ width: "90%" }}
          />
        </Grid> */}

        <Grid container item xs={12} justifyContent={"flex-end"}>
          <Skeleton
            duration={2}
            animation="wave"
            variant="rectangular"
            height={"20px"}
            style={{ width: "100%", marginTop: "3px"}}
          />
        </Grid>
          <Grid
            container
            direction="row"
            justifyContent="space-between"
            alignItems="center"
            px={2}
            mt={4}
          >
           
          </Grid>
          <Grid
            container
            direction="row"
            justifyContent="space-evenly"
            alignItems="center"
            mt={2}
          >
            <Grid item xs={6}>
            <Skeleton
                duration={2}
                animation="wave"
                variant="rounded"
                height={"40px"}
                style={{ width: "70%", marginLeft: "30px" }}
              />
            </Grid>
            <Grid item xs={6}>
            <Skeleton
                duration={2}
                animation="wave"
                variant="rounded"
                height={"40px"}
                style={{ width: "70%", marginLeft: "30px" }}
              />
            </Grid>
          </Grid>
          <Grid
            container
            justifyContent="center"
            alignItems="center"
           // sx= { styles.gridItemBottomMsg }
            mt={2}
          >
            <Grid
          container
          direction="row"
          justifyContent="center"
          alignItems="center"
        >
         
        </Grid>
          </Grid>
          <Grid container item xs={12} justifyContent={"flex-end"}>
          <Skeleton
            duration={2}
            animation="wave"
            variant="rectangular"
            height={"20px"}
            style={{ width: "100%", marginTop: "3px"}}
          />
        </Grid>
        </Grid>
    </>
  );
};

export default BottomDrawerSkeleton;
