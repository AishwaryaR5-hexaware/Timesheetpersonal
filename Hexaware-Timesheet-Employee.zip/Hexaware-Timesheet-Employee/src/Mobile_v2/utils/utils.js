import { DateTime } from "luxon";

export function today(timeZone) {
    const currentTimeInTimeZone = DateTime.now().setZone(timeZone);

    const dateInfo = {
        today: currentTimeInTimeZone.toFormat("yyyy-MM-dd"),
        date: currentTimeInTimeZone.toFormat("dd"),
        month_num: currentTimeInTimeZone.toFormat("MM"),
        month_str: currentTimeInTimeZone.toFormat("MMMM"),
        month_str_short: currentTimeInTimeZone.toFormat("LLL"),
        year: currentTimeInTimeZone.toFormat("yyyy"),
        day: currentTimeInTimeZone.toFormat("EEE"),
        dateObj: currentTimeInTimeZone,
    };
    return dateInfo;
}

export function todayDate(timeZone, dateString) {
    const dateObj = DateTime.fromFormat(dateString, "yyyy-MM-d", {
      zone: timeZone,
    });
    return {
      today: dateObj.toFormat("yyyy-MM-d"),
      date: dateObj.toFormat("dd"),
      month_num: dateObj.toFormat("MM"),
      month_str: dateObj.toFormat("MMMM"),
      month_str_short: dateObj.toFormat("LLL"),
      year: dateObj.toFormat("yyyy"),
      day: dateObj.toFormat("EEE"),
      dateObj: dateObj,
    };
  }

export function getWeeksBasedOnRole(userType, timeZone) {
    const weeks = {};
    const response = today(timeZone);
    const month = parseInt(response.month_num);
    const year = parseInt(response.year);

    let numMonths = 1; // default to current month
    if (userType === 'manager') {
        numMonths = 2; // current and last month
    } else if (userType === 'contractor') {
        numMonths = 3; // current, last, and last 2 months
    }

    let weekNum = 1; // Initialize the week number

    for (let monthIndex = numMonths - 1; monthIndex >= 0; monthIndex--) {
        let currentMonth = month - monthIndex;
        let currentYear = year;

        if (currentMonth <= 0) {
            currentYear--;
            currentMonth += 12;
        }

        const firstDayOfMonth = DateTime.fromObject({ year: currentYear, month: currentMonth, day: 1 });
        const lastDayOfMonth = firstDayOfMonth.plus({ months: 1 }).minus({ days: 1 });

        // Calculate the start date of the first week of the current month
        let firstSundayNum = 1;
        if (firstDayOfMonth.weekday !== 7) {
            firstSundayNum = 7 - firstDayOfMonth.weekday + 1;
            let startDate = getLastSundayOfMonth(currentYear, currentMonth, timeZone);
            let endDateOfFirstWeek = firstSundayNum - 1;
            let endDate = DateTime.fromObject(
                {
                    year: currentYear,
                    month: currentMonth,
                    day: endDateOfFirstWeek,
                },
                { zone: timeZone, keepCalendarTime: true }
            );
            if (!(Object.values(weeks).some((week) => week.startDate === startDate.toFormat("yyyy-MM-dd")))) {
                weeks[`week${weekNum}`] = {
                    startDate: startDate.toFormat("yyyy-MM-dd"),
                    endDate: endDate.toFormat("yyyy-MM-dd"),
                };
                weekNum++;
            }
        }

        let currentDate = getFirstSundayOfMonth(currentYear, currentMonth, timeZone);

        while (currentDate <= lastDayOfMonth) {
            const startDate = currentDate;
            const endDate = currentDate.plus({ days: 6 });
            weeks[`week${weekNum}`] = {
                startDate: startDate.toFormat("yyyy-MM-dd"),
                endDate: endDate.toFormat("yyyy-MM-dd"),
            };
            weekNum++;

            currentDate = currentDate.plus({ days: 7 });
        }
    }
    return weeks;
}

function getLastSundayOfMonth(year, month, timeZone) {
    // Get the last day of the month
    if (month === 0) {
        month = 12;
        year = year - 1;
    }
    const lastDayOfMonth = DateTime.fromObject(
        { year: year, month: month, day: 1 },
        { zone: timeZone, keepCalenderTime: true }
    ).minus({ days: 1 });
    // Check if the last day of the month is a Sunday (weekday: 7)
    if (lastDayOfMonth.weekday === 7) {
        return lastDayOfMonth;
    } else {
        // Get the date of the last Sunday in the previous week
        const lastSunday = lastDayOfMonth
            .minus({ days: lastDayOfMonth.weekday })
            .set({ weekday: 7 });
        return lastSunday;
    }
}

function getFirstSundayOfMonth(year, month, timeZone) {
    const firstDayOfMonth = DateTime.fromObject({ year, month, day: 1 }).setZone(
        timeZone
    );

    let firstSunday = firstDayOfMonth;
    while (firstSunday.weekday % 7 !== 0) {
        // Use modulo 7 to find Sunday
        firstSunday = firstSunday.plus({ days: 1 });
    }
    return firstSunday;
}

export function getCurrentWeek(userType, timeZone) {
    var weekName;
    let inputWeeks = getWeeksBasedOnRole(userType, timeZone);
    let currentDate = today(timeZone);
    const currentDateTime = DateTime.fromFormat(currentDate.today, "yyyy-MM-dd");
    for (const week in inputWeeks) {
        const startDate = DateTime.fromISO(inputWeeks[week].startDate);
        const endDate = DateTime.fromISO(inputWeeks[week].endDate);
        if (currentDateTime >= startDate && currentDateTime <= endDate) {
            weekName = week;
            return week;
        }
        //return weekName;
    }
    // If the current date doesn't fall into any week, return null or an appropriate message
    return weekName;
}
