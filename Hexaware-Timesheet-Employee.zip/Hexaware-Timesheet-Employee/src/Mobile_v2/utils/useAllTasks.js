import { useEffect } from "react";
import { getAuthToken } from "../services/AuthToken";
import { useState } from "react";
import axios from "axios";
import useSWR from 'swr';
import { useGetEmployeeId } from '../services/Profile';
import { serviceConfig } from '../services/serviceConfig';

const GET_WEEKLY_TASKS_URL = serviceConfig.routes.weeklyTasksUrl;

async function fetchWeeklyTasks(urlString, empId, weekStartDate, weekEndDate) {
  const { access_token: accessToken } = await getAuthToken(); // Get access token
  const url = new URL(urlString)
  const config = {
    method: 'get',
    url: url.toString(),
    headers: { Authorization: `Bearer ${accessToken}` },
    params: {
      emp_id: empId,
      week_start_date: weekStartDate,
      week_end_date: weekEndDate,
    },
  };
  try {
    const response = await axios(config);
    return response.data;
  } catch (error) {
    throw error;
  }
}

export function useAllTasks({ currentWeek, weeks }) {
  const startDate = weeks[currentWeek]?.startDate;
  const endDate = weeks[currentWeek]?.endDate;
  const [status, setStatus] = useState("");
  // const [shouldFetch, setshouldFetch] = useState( weeks && currentWeek)

  const empId = useGetEmployeeId(); // Get employee ID

  const { data, isLoading ,error } = useSWR(
    [ GET_WEEKLY_TASKS_URL, empId, startDate, endDate], ([url, empId, startDate, endDate]) =>
    fetchWeeklyTasks(url, empId, startDate, endDate)
  );

  const [tasksByDate, setTasksByDate] = useState({});

  useEffect(() => {
    if (!error && !data) {
      setStatus("Loading");
    } else if (!data || data?.items.length === 0) {
      setStatus("Empty");
    } else {
      const tasksMap = data.items.reduce((acc, task) => {
        const { timesheet_date: date } = task;
        if (!acc[date]) {
          acc[date] = [];
        }
        acc[date].push(task);
        return acc;
      }, {});
      setTasksByDate(tasksMap);
    }
  }, [data, error]);

  return {
    status,
    data: tasksByDate,
    isLoading,
  };
}
