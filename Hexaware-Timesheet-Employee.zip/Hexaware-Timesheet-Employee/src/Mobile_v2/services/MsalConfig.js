import React from "react";
import { msalInstance } from "../../index";
import log from 'loglevel';

log.setLevel('info');


export const getToken = async (scopes) => {

  log.info('getToken called');
  const account = msalInstance.getActiveAccount();
  const accessTokenRequest = { account: account, scopes: scopes };
  if (!account) {
    log.error(
      'No active account! Verify a user has been signed in and setActiveAccount has been called.'
    );
    throw Error(
      "No active account! Verify a user has been signed in and setActiveAccount has been called."
    );
  }
  try {
    log.info('Acquiring token silently...');
    const response = await msalInstance.acquireTokenSilent(accessTokenRequest);
    log.info('Token acquired successfully');
    return response.accessToken;
  } catch (error) {
    log.error('Error occurred while acquiring token silently:', error);
    if (error) {
      log.info('Acquiring token using redirect...');
      msalInstance.acquireTokenRedirect(accessTokenRequest);
    }
  }
};
