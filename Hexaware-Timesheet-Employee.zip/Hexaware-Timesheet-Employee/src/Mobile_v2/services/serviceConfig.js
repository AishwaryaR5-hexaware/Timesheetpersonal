export const serviceConfig = {
    routes:{
        weeklyTasksUrl:process.env.REACT_APP_API_URL+'/hex_timesheet_task/task_info',
        taskNamesUrl:process.env.REACT_APP_API_URL+'/hex_timesheet_headers/empProjects',
        summaryTasksUrl:process.env.REACT_APP_API_URL+'/hex_timesheet_summary/summaryInfo',
        commentUrl:process.env.REACT_APP_API_URL+'/hex_timesheet_comments/',
        authUrl:process.env.REACT_APP_API_URL+'/hexordstoken/generateToken',
        updateTaskUrl:process.env.REACT_APP_API_URL+'/hex_tasks_update',
        timezoneUrl:process.env.REACT_APP_API_URL+'/hex_timesheet_headers/timezone'
    },
   
    profile:{
        profileInfo:process.env.REACT_APP_PROFILE_INFO,
        profilePhoto:process.env.REACT_APP_PROFILE_INFO+'/photo/',
    },
};