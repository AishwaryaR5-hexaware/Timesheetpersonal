import useSWR from 'swr';
import axios from "axios";
import { serviceConfig } from './serviceConfig';
import { getAuthToken } from './AuthToken';
import { useGetEmployeeId } from './Profile';

const GET_TIMEZONE_URL = serviceConfig.routes.timezoneUrl;
const GET_TASK_NAMES_URL = serviceConfig.routes.taskNamesUrl;
const GET_WEEKLY_TASKS_URL = serviceConfig.routes.weeklyTasksUrl;


export const getAccessToken = async () => {

    const token = await getAuthToken();
    return token.access_token;
};

async function fetchTimeZone(urlString, empId) {
    const url = new URL(urlString)
    url.searchParams.set("emp_id", empId)
    const { access_token } = await getAuthToken(); // Get access token
    const config = {
        method: 'get',
        url: url.toString(),
        headers: { Authorization: `Bearer ${access_token}` },
        params: {
            emp_id: empId,
        },
    };
    try {
        const response = await axios(config);
        return response.data;
    } catch (error) {
        throw error;
    }
}

export function useTimeZone() {
    const empId = useGetEmployeeId();
    const { data, error } = useSWR([GET_TIMEZONE_URL, empId], ([url, empId]) => fetchTimeZone(url, empId));
    // console.log("data",data);
    // console.log("error",error);
    if (error) {
        console.error('Error occurred while retrieving timezone:', error);
        return 'Asia/Calcutta';
    }

    return data;
}

async function fetchTaskNames(url, empId, month, year) {
    const { access_token: accessToken } = await getAuthToken(); // Get access token
    const config = {
        method: 'get',
        url: url,
        headers: { Authorization: `Bearer ${accessToken}` },
        params: {
            emp_id: empId,
            ts_month: month,
            ts_year: year,
        },
    };
    try {
        const response = await axios(config);
        return response.data;
    } catch (error) {
        throw error;
    }
}

export function useTaskNames(month, year) {
    const empId = useGetEmployeeId(); // Get employee ID
    const { data, error } = useSWR(
        [GET_TASK_NAMES_URL, empId, month, year], 
        ([url, empId, month, year]) => fetchTaskNames(url, empId, month, year)
    );
    if (error) {
        console.error('Error occurred while retrieving task names:', error);
        return null;
    }
    return data; // Return the task names data
}

// async function fetchWeeklyTasks(urlString,empId, weekStartDate, weekEndDate) {
//     const { access_token: accessToken } = await getAuthToken(); // Get access token
//     const url = new URL(urlString)
//     const config = {
//     method: 'get',
//     url: url.toString(),
//     headers: { Authorization: `Bearer ${accessToken}` },
//     params: {
//       emp_id: empId,
//       week_start_date: weekStartDate,
//       week_end_date: weekEndDate,
//     },
//   };
//   try {
//     const response = await axios(config);
//     return response.data;
//   } catch (error) {
//     throw error;
//   }
// }

// export function useWeeklyTasks(weekStartDate, weekEndDate) {
//   const empId = useGetEmployeeId(); // Get employee ID

//   const { data, error } = useSWR(
//     [GET_WEEKLY_TASKS_URL, empId, weekStartDate, weekEndDate],([url,empId,weekStartDate,weekEndDate])=>
//     fetchWeeklyTasks(url,empId,weekStartDate,weekEndDate)
//   );

//   return {
//     data,
//     isLoading: !error && !data,
//     isError: error,
//   };
// }

