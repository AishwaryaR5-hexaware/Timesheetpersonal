import axios from "axios";
import { getToken } from './MsalConfig';
import { loginRequest } from "../../authConfig";
import useSWR from 'swr';
import { serviceConfig } from './serviceConfig';

const PROFILE_INFO = serviceConfig.profile.profileInfo;

async function fetchProfileInfo(url) {
    const accessToken = await getToken(loginRequest.scopes);
    const config = {
        method: 'get',
        url: url,
        headers: { Authorization: `Bearer ${accessToken}` },
    };
    try {
        const response = await axios(config);
        return response.data;
    } catch (error) {
        throw error;
    }
}

export function useGetEmployeeId() {
    const environment = process.env.REACT_APP_ENVIRONMENT;
    const isDevEnvironment = environment === "dev"
    const { data, error } = useSWR(!isDevEnvironment ? PROFILE_INFO : null, fetchProfileInfo);

    if (isDevEnvironment) {
        return localStorage.getItem("empId");
    }

    if (error) {
        console.error('Error occurred while retrieving profile info:', error);
    }
    if (!data) return null;
    return data.userPrincipalName.split("@")[0];
}

