import log from 'loglevel';
import axios from "axios";
import { serviceConfig } from './serviceConfig';

export const getAuthToken = async () => {
    var data = JSON.stringify({
      client_id: process.env.REACT_APP_ORACLE_CLIENT_ID,
      client_secret: process.env.REACT_APP_ORACLE_CLIENT_SECRET,
      grant_type: "client_credentials",
    });
  
    var config = {
      method: "post",
      url:serviceConfig.routes.authUrl,
      headers: {
        Authorization: `Basic ${process.env.REACT_APP_ORACLE_AUTH_TOKEN}`,
        "Content-Type": "application/json",
      },
      data: data,
    };
    try {
      log.info('Sending authentication request...');
      const response = await axios(config);
      log.info('Authentication request successful');
      return response.data;
    } catch (error) {
      log.error('Error occurred during authentication:', error);
    }
  
  };
  
  