import React, { useEffect, useState } from "react";
import { Routes, Route, HashRouter as Router } from "react-router-dom";
// import MobileHome from "../Screens/MobileHome";
// import MonthlySummary from "../Screens/MonthlySummary";
// import Login from "../Login/Login";
// import { getCurrentMonthWeeks } from "../HandlerFunctions/CurrentMonthWeek";
// import Add from "../Screens/Add";
// import { getAllTasks } from "../HandlerFunctions/getAllTasks";
// import { getTimeZone } from "../../Services/Tasks";
//import { getCurrentWeek, getCurrentMonthWeek } from "../utils/util";
import Home from "../HomeModule/Home";
import Login from "../../mobile/Login/Login";
import Add from "../../mobile/Screens/Add";
import MonthlySummry from "../HomeModule/MonthlySummaryModule/MonthlySummry";
import AddTime from "../HomeModule/AddTimeModule/AddTime";
import Comments from "../HomeModule/CommentsModule/Comments";
import { getWeeksBasedOnRole, getCurrentWeek } from "../utils/utils";
import { useTimeZone } from "../services/Tasks";
import { useAllTasks } from "../utils/useAllTasks";
import ApplyWfh from "../HomeModule/AddTimeModule/ApplyWfh";

import TasksState from "../Context/TasksState";

const MobileRoute2 = () => {
  console.log("MobileRoute2")

  // const [timezone, setTimezone] = useState(() => { "" });
  const [weeksObj, setWeeksObj] = useState(() => {
    return ({
      weeks: {},
      currentWeek: "",
    })
  });


  const timezoneData = useTimeZone();
  // console.log("weeksobj",weeksObj);
  const { status,isLoading, data } = useAllTasks(weeksObj);
  // console.log("loading",isLoading)

  
  useEffect(() => {
    const getCurrDate = async () => {
      if (timezoneData) {
        const data = timezoneData;
  
        // setTimezone(data.timezone);
        setWeeksObj({
          weeks: getWeeksBasedOnRole('manager', data.timezone),
          currentWeek: getCurrentWeek("manager", data.timezone),
        });
      }//else {
      //   // console.error('Error occurred while retrieving timezone:', timezoneError);
      //   setTimezone('Asia/Calcutta');
      // }
    };
    
    getCurrDate();

  }, [timezoneData]);

  const environment = process.env.REACT_APP_ENVIRONMENT;
  const timeZone = timezoneData ? timezoneData.timezone : ""

  return (
    <>
    <TasksState data={data}>
      <Router>
        {environment === "dev" ? (
          <Routes>
            <Route
              path="/home"
              element={
                <Home
                  // getAPI={getAPI}
                  isLoading={isLoading}
                  weeksObj={weeksObj}
                  setWeeksObj={setWeeksObj}
                  timezone={timeZone}
                  timezoneData={timezoneData}
                />
              }
            />
            <Route
              path="/monthly-summary"
              element={

                <MonthlySummry></MonthlySummry>
              }
            />
             <Route path="/add-time" element={ <AddTime />} />
             <Route path="/apply-wfh" element={ <ApplyWfh />} />
            <Route path="/add-time" element={<AddTime />} />
            <Route path="/add" element={<Add />} />
            <Route path="/comments" element={<Comments />} />
            <Route path="/" element={<Login></Login>}></Route>
          </Routes>
        ) : (
          <Routes>
            {/* <Route
              path="/"
              element={
                <MobileHome
                  backgroundColor={"#E9EFF4"}
                  flag={"mainScreen"}
                  // weeks={weeks}
                  // currentWeek={currentWeek}
                  // updateCurrentWeek={updateCurrentWeek}
                  getAPI={getAPI}
                  updateSetAPI={updateSetAPI}
                  isDataEmpty={isDataEmpty}
                  loading={loading}
                  message={message}
                  weeksObj={weeksObj}
                  setWeeksObj={setWeeksObj}
                  timezone={timezone}
                />
              }
            /> */}
            {/* <Route
              path="/monthly-summary"
              element={
                <MonthlySummary
                  // weeks={weeks}
                  // currentWeek={currentWeek}
                  backgroundColor={"#FBFDFF"}
                  flag={"monthSummaryScreen"}
                  // updateCurrentWeek={updateCurrentWeek}
                  weeksObj={weeksObj}
                  setWeeksObj={setWeeksObj}
                  timezone={timezone}
                />
              }
            />
            <Route path="/add" element={<Add />} /> */}
          </Routes>
        )}
      </Router>
    </TasksState>
    </>
  );
};

export default MobileRoute2;
