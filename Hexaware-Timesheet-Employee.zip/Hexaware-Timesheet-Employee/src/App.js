//import "./App.css"
import React, { useState, useEffect } from "react"
import { CssBaseline, ThemeProvider } from "@mui/material"
import theme from "./theme"

import { BrowserView, MobileView } from "react-device-detect";
import MobileRoute from "./mobile/Routes/MobileRoute";
import {
  AuthenticatedTemplate,
  MsalProvider,
  UnauthenticatedTemplate,
} from "@azure/msal-react";
import Login from "./mobile/Login/Login";
import { Route, HashRouter  as Router, Routes } from "react-router-dom";
import TestButton from "./web/TestButton";

import { ApplicationInsights } from "@microsoft/applicationinsights-web"
import appInsights from "./mobile/HandlerFunctions/appInsights"
import { ReactPlugin, withAITracking } from "@microsoft/applicationinsights-react-js"
//import { createBrowserHistory } from "history"
import theme2 from './theme2';
import log from "loglevel"
import AuthLogin from "./mobile/Login/AuthLogin"
import MobileRoute2 from "./Mobile_v2/Router/MobileRoute2";
log.setLevel(process.env.REACT_APP_LOG_LEVEL)
//log.setLevel("info")
//In dev environment, 'info', In stating environment 'warn', In production 'error'

export const UserContext = React.createContext("");
function App({ msalInstance }) {
  const [empId, setEmpId] = useState("");
  const environment = process.env.REACT_APP_ENVIRONMENT;

  const appInsightsEnv = process.env.REACT_APP_APPINSIGHTS;

  useEffect(() => {
    if (appInsights && appInsightsEnv === "true") {
      const reactPlugin = new ReactPlugin()
      //const browserHistory = createBrowserHistory({ basename: "/" })
      const appInsightsInstance = new ApplicationInsights({
        config: {
          connectionString:
            process.env.REACT_APP_APPINSIGHTS_INSTRUMENTATIONKEY,
          extensions: [reactPlugin],
          //history: browserHistory
        }
      })
      appInsightsInstance.loadAppInsights();

      return () => {
        appInsightsInstance.flush();
      }
    }
  }, []);

  let appInsights = null;

  const handleClick = () => {
    if(appInsights){
      log.info("Button clicked")
    appInsights.trackEvent({ name: "ButtonClicked", properties: { buttonName: "TestButton" } })
    }
    
  }

  return (
    <>
      {environment === "dev" ? (
        <>
          <ThemeProvider theme={theme2}>
            <CssBaseline />
            <div className="App">
              <BrowserView>
                <TestButton onClick={handleClick}></TestButton>
              </BrowserView>
              <MobileView>
                <UserContext.Provider
                  value={{ empId: empId, setEmpId: setEmpId }}
                >
                  <MobileRoute2 />
                </UserContext.Provider>
              </MobileView>
            </div>
          </ThemeProvider>
        </>
      ) : (
        <>
          <MsalProvider instance={msalInstance}>
            <ThemeProvider theme={theme}>
              <CssBaseline />
              <BrowserView>
                <TestButton onClick={handleClick}></TestButton>
              </BrowserView>
              <AuthenticatedTemplate>
                <div className="App">
                  <MobileView>
                    <MobileRoute />
                  </MobileView>
                </div>
              </AuthenticatedTemplate>
              <UnauthenticatedTemplate>
                <MobileView>
                  <Router>
                    <Routes>
                      <Route path="/" element={<AuthLogin />}></Route>
                    </Routes>
                  </Router>
                </MobileView>
              </UnauthenticatedTemplate>
            </ThemeProvider>
          </MsalProvider>
        </>
      )}
    </>
  );
}

export default withAITracking(MsalProvider, App);
