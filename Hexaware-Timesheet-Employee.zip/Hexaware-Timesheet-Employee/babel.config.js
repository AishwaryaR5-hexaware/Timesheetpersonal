module.exports = (api) => {
    const presets = ["react-app", "@babel/preset-env"];
    const plugins = [
      "@babel/plugin-transform-modules-commonjs",
      "inline-react-svg",
      // ["@babel/plugin-proposal-private-methods", { "loose": true }],
      // ["@babel/plugin-proposal-class-properties", { "loose": true }],
      // ["@babel/plugin-proposal-private-property-in-object", { "loose": true }]
    ]; 
    
    api.cache(false); 
     
    return {
      presets,
      plugins
    };
  };
  