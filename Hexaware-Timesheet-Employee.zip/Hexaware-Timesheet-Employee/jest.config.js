module.exports = {
    //setupFiles: ["<rootDir>/src/mobile/Screens/Add.js"],
    setupFiles:["dotenv/config"],
  testEnvironment: "jsdom",

  };