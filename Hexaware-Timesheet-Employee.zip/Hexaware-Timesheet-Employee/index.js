// Generate boilerplate nodejs code to serve the build folder as a static website

const express = require('express');
const path = require('path');
const app = express();
const cors = require('cors');
const helmet = require('helmet')
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.static(path.join(__dirname, 'build')));

app.use(helmet.frameguard({ action: "SAMEORIGIN" }))
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'build', 'index.html'));
    }
);

app.listen(PORT, () => {
    console.log(`Server listening on ${PORT}`);
});